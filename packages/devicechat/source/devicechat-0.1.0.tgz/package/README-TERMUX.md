# devicechat — Termux / Linux portable bundle

Portable, pre-built distribution of the `devicechat` CLI. Extract and run on
Linux ARM64 (or x64) — typically Termux on Android, or any proot-distro
Debian/Ubuntu chroot. No internet access is required at runtime: the JS source
and all production `node_modules` are bundled here.

## 1. Prerequisites (Termux)

```sh
pkg install nodejs-lts cloudflared
```

- `nodejs-lts` provides `node` (v18+). The bundled code is ESM and targets
  Node 18 or newer.
- `cloudflared` is needed only for the public tunnel (worldwide chat). If you
  only want LAN-only chat, you can skip it; the relay will still run on
  `127.0.0.1:8080` (or `$PORT`) and any device on your network can reach
  `ws://<your-ip>:8080` directly.

**Why your Termux tunnel might fail with Cloudflare error 1033**:

Cloudflare error 1033 ("Argo Tunnel: connection not established") means
Cloudflare's network cannot find a healthy cloudflared instance to receive
the traffic. There are **three independent root causes** on Android — this
bundle auto-applies the fixes for #1 and #2; root cause #3 needs your phone
settings (see §5).

### Root cause 1 — broken QUIC/UDP ✅ auto-fixed in this bundle

The default Termux-packaged `cloudflared` is built with Cloudflare's patched
golang toolchain, which has incomplete Android support — see
[Termux issue #19552](https://github.com/termux/termux-packages/issues/19552).
Symptoms: `cloudflared` starts, accepts your `--url`, even prints a
`*.trycloudflare.com` registration URL, but when you open that URL in a
browser you get error 1033. This bundle forces **`--protocol http2`** in
`dist/serverctl.js` (Linux/Termux only), which skips the broken QUIC path and
uses HTTP/2 over TCP 443 — reliably working on Android.

### Root cause 2 — DNS resolution against `[::1]:53` ✅ auto-fixed in this bundle

The Termux `cloudflared` (and even the upstream linux-arm64 binary) tries to
resolve the SRV records `_v2-origintunneld._tcp.argotunnel.com` via
`[::1]:53` (localhost DNS), which **does not exist** on Android — produces
`[::1]:53: connection refused` and then error 1033. See
[Cloudflare community thread](https://community.cloudflare.com/t/cloudflared-tunnel-fails-srv-lookup-on-1-53-refused-termux-android-v2025-8-1/837267)
and [cloudflared#793](https://github.com/cloudflare/cloudflared/issues/793).

This bundle applies THREE belt-and-braces fixes:

1. `--edge-ip-version 4` — nudges cloudflared onto IPv4 edge lookup, which
   sidesteps the most common failure mode on Android.
2. `--edge 198.41.200.233:7844` — **fully bypasses the SRV DNS lookup** by
   pinning cloudflared to one pre-resolved Cloudflare edge IP:port. This is
   the strongest fix for error 1033 when DNS itself is the blocker; the
   `--edge-ip-version 4` flag alone does NOT skip the lookup, it only filters
   results from it. cloudflared falls back to SRV if this IP is unreachable.
3. **Auto-creates `$PREFIX/etc/resolv.conf`** (if absent or empty) pointing at
   `1.1.1.1` and `8.8.8.8`. You will see a line like
   `wrote /data/data/com.termux/files/usr/etc/resolv.conf (cloudflared needs…)`
   in `server on` output on the first run. If you already have a hand-edited
   resolv.conf the bundle will not touch it.

> ⚠️ **Misleading log line:** cloudflared always prints
> `INF Cannot determine default configuration path. No file [config.yml config.yaml] in [~cloudflared ...]`
> on startup when no `config.yml` exists. **This is INFO, not an error**, and is
> shown on every successful trycloudflare run (Cloudflare silenced it in later
> builds but the Termux-packaged one still emits it). Your real failure is the
> **next** line after it — read on.

If cloudflared still prints DNS errors after this, the manual workarounds that
**do** work (none of these are auto-applied — try them in order):

```sh
# (a) Verify the resolv.conf is present (bundle should have written it)
cat $PREFIX/etc/resolv.conf

# (b) Use proot/termux-chroot so /etc/resolv.conf exists at the hardcoded path:
pkg install proot
termux-chroot     # then re-run devicechat host inside the chroot

# (c) termux-etc-redirect — LD_PRELOAD redirects /etc → $PREFIX/etc (no root):
#   https://github.com/rios0rios0/termux-etc-redirect

# (d) Replace the Termux build with the upstream binary (see below) — the
#     upstream linux-arm64 build has better Android DNS handling.
```

> **The cleanest workaround for root cause #2**: run devicechat inside a
> **`proot-distro`** Debian/Ubuntu chroot. There `/etc/resolv.conf` exists and
> is properly managed by the distro's networking stack — root cause #2
> disappears entirely. See §1 "On a proot-distro" below.

If `--protocol http2` + the resolv.conf fix still fail for you, replace the
Termux-packaged build with the upstream linux-arm64 binary:

```sh
# Replace the Termux-packaged build with the upstream linux-arm64 build
pkg uninstall cloudflared
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 -o $PREFIX/bin/cloudflared
chmod +x $PREFIX/bin/cloudflared
cloudflared --version    # should print 2024.10.0 or newer
```

On a proot-distro Debian/Ubuntu instead:

```sh
apt install -y nodejs npm
# cloudflared: grab the linux-arm64 binary from
#   https://github.com/cloudflare/cloudflared/releases/latest
# and put it on your PATH. Same http2 protocol is auto-applied.
# root cause #2 (DNS) does NOT occur here — /etc/resolv.conf is real.
```

## 2. Extract

```sh
cd ~
tar xzf devicechat-termux.tgz
```

This produces a `~/devicechat/` directory containing:

```
devicechat/
  package.json
  package-lock.json
  dist/                 <- compiled JS (run this, not src/)
  node_modules/         <- all production deps (pure JS, platform-independent)
  README-TERMUX.md       <- this file
```

## 3. Run — host a relay + tunnel

```sh
cd ~/devicechat
node dist/index.js host
```

 (`host` is the alias inside the CLI for `server on` — starts the relay and,
if `cloudflared` is on `PATH`, the trycloudflare quick-tunnel.)

Alternative long form:

```sh
node dist/index.js server on
```

Output on success:

```
relay: online
starting cloudflare tunnel (grabbing public URL)...
tunnel: ready
public: https://<random>.trycloudflare.com
friend connects with: devicechat --server wss://<random>.trycloudflare.com --join <token> <key>
```

State (identity, pid files, logs, tunnel URL) lives in
`~/.devicechat/` (or `$DEVICECHAT_HOME` if set — on Termux this resolves to
`/data/data/com.termux/files/home/.devicechat/`).

## 4. Run — join a friend's chat

```
node dist/index.js --join <token> <key>            # interactive UI
node dist/index.js --server wss://... --join ...   # joining a specific URL
```

## 5. Stop / status

```sh
node dist/index.js server off        # stop relay + tunnel
node dist/index.js server status     # show state + public URL
```

Use `SIGINT`/`SIGTERM` (Ctrl+C) to stop the relay too — the relay installs
handlers that flush `close(1001)` frames to connected peers so they reconnect
cleanly instead of seeing a hard reset.

### ⚠️ Keep the tunnel alive on Android (root cause 3 of error 1033)

Android will kill the cloudflared socket when the screen is off / the Termux
app is backgrounded. This produces error 1033 from a *different* cause than
#1 and #2 — the relay is up, the registration is valid, but the cloudflared
**edge connection** dropped because the OS froze the process.

#### Easy wins (do these first)

```sh
pkg install termux-wake-lock
termux-wake-lock     # acquires a wake lock — you'll see a notification
# now run devicechat host — socket stays alive while screen is off
```

Always run `termux-wake-lock` before `node dist/index.js host` on a server
phone that's meant to stay online 24/7. To release: `termux-wake-release`.

#### Samsung phones (S10 FE / Android 16 / OneUI 8.x specifically)

Samsung's battery saver is notoriously aggressive — even with the battery
set to "Unrestricted", OneUI 8.x **freezes Termux wakelocks** via a
proprietary `FreecessController` when the app is backgrounded (see
[Termux issue #5086](https://github.com/termux/termux-app/issues/5086) and
[don't kill my app — Samsung](https://dontkillmyapp.com/samsung, updated June 2026)).

After enabling `Unrestricted` battery in Settings → Apps → Termux, ALSO do:

1. **Disable "High battery usage restriction"** for Termux in
   **Samsung Smart Manager** (preinstalled) or the **Good Guardians** module
   from Galaxy Store. "Unrestricted" alone is NOT enough on Samsung.
2. **Disable the Android 12+ phantom process killer** (cloudflared is a child
   process spawned from node; the phantom-process killer will reap it when
   memory pressure arises):
   - **Android 16 (your case)**: Settings → Developer Options → System →
     toggle **"Disable child process restrictions"** on.
   - **Android 12-15 (via ADB — connect to a PC once)**:
     ```sh
     adb shell settings put global settings_enable_monitor_phantom_procs false
     adb shell /system/bin/device_config put activity_manager max_phantom_processes 2147483647
     # Reboot afterwards. A system update can reset these — re-run if cloudflared
     # starts dying again after an OTA.
     ```

#### The blast-proof workaround for Samsung

If the Samsung battery measures still won't leave Termux alone, run devicechat
inside a **`proot-distro`** Debian/Ubuntu chroot — the chroot's processes are
owned by `proot` (a single entry in Android's process tree) instead of being
individual children of Termux, which significantly reduces the phantom-process
kill surface. See §1 of this document for the proot-distro setup commands.

#### Diagnostics — finding which root cause hit you

Cloudflare error 1033 alone does not tell you which of the three root causes
fired. So with `devicechat host` running and the trycloudflare URL printed:

```sh
# Watch the cloudflared errors live (separate Termux session):
tail -f ~/.devicechat/tunnel.log
# Press Ctrl+C to exit. Look for:
#   "[::1]:53: connection refused"        → root cause 2 (DNS — bundle fix should cure)
#   "QUIC protocol" / "udp 443" errors     → root cause 1 (QUIC — bundle fix cures)
#   Process exits with no error, no log    → root cause 3 (Samsung phantom kill — §5 fix)
```

## 6. Notes / environment tweakables

| Variable           | Default                | Meaning                                  |
| ------------------ | ---------------------- | ---------------------------------------- |
| `PORT`             | `8080`                 | Port the relay listens on                |
| `DEVICECHAT_HOME`  | `~/.devicechat`        | Where identity/pid/url/log files live    |

- The relay HTTP server answers `GET /` with `devicechat relay ok` — handy
  for uptime checks.
- All runtime dependencies (`ws`, `libsodium-wrappers-sumo`, `ink`, `react`,
  `chalk`, `wrap-ansi`, `string-width`, `ink-text-input`) are pure JavaScript
  with no native add-ons, so the included `node_modules/` works on both
  arm64 and x64 without reinstalling.
- If `cloudflared` is not found on `PATH`, the CLI prints `cloudflared not found`
  and stops at the local-relay stage. The install hint it prints is
  platform-aware (e.g. `pkg install cloudflared` on Termux, `apt install
  cloudflared` on Debian/Ubuntu). `findCloudflared()` also probes the standard
  install paths (`/usr/local/bin`, `/usr/bin`, `/snap/bin`, and Termux's
  `/data/data/com.termux/files/usr/bin/`) — so once `pkg install cloudflared`
  finishes, `server on` will find it with no extra configuration.
- Logs: `~/.devicechat/relay.log`, `~/.devicechat/tunnel.log`.
- The bundled `dist/` was built with `tsc` and is the same code that ran the
  `host` command on this developer machine.

## 7. Verify the bundle runs

```sh
cd ~/devicechat
node dist/index.js --help
node dist/index.js server status
```

If `--help` prints usage and `server status` shows `relay: offline`,
everything is wired up correctly.
