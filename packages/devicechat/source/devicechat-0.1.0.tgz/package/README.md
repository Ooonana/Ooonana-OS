# devicechat

End-to-end encrypted, human-to-human CLI chat. Your messages are encrypted and
decrypted **on your device**. The cloud relay server only ever sees opaque
ciphertext and an anonymous routing token — never your name, never your keys,
never your words.

```
You ──E2E ciphertext──▶ Relay server ──ciphertext──▶ Peer
        (decrypts here)   (dumb relay)     (decrypts here)
```

## Privacy model

- Each device generates an **X25519** keypair locally (`~/.devicechat/identity.json`).
- Two peers exchange, out-of-band (e.g. Signal), a **routing token** + each other's
  **public key**. The server never holds public keys.
- Shared secret = ECDH( my private, peer public ). Messages encrypted with
  XSalsa20-Poly1305 (libsodium `crypto_secretbox`).
- The server stores **nothing** — no names, no keys, no logs. It only keeps an
  in-memory `token -> socket` map that is dropped the instant a peer disconnects.
- Verify no man-in-the-middle with the **safety number** (`/safety`): both sides
  should show the identical `XXXX-XXXX-XXXX`. Read it to your peer out-of-band.

## Install

Requires Node.js 18+ (developed on v25).

On the machine you want to chat from:

```bash
# from the repo root — installs BOTH bins (devicechat + devicechat-relay)
npm i -g .          # builds + links both binaries

# or, if published:
npm i -g devicechat
```

Works on Linux and Windows.

## Run

Two people, each on their own device:

```bash
# Person A (host)
devicechat --new
#   -> prints a bundle:  token=...  key=...
#   -> send that bundle to Person B out-of-band

# Person B (join)
devicechat --join <token> <key>
```

Now type messages. They are encrypted on your machine and decrypted on the peer's.

In-chat commands:

| command | action |
|---------|--------|
| `/new` | print a fresh token + pubkey bundle (host a new session) |
| `/join <token> <pubkey>` | connect to a peer using their bundle |
| `/safety` | show the safety number — verify out-of-band to defeat MITM |
| `/whoami` | show your device name + public key |
| `/clear` | clear the transcript |
| `/help` | list commands |
| `/exit` | quit |

Set a device name and a custom relay:

```bash
devicechat --name "Alice" --server ws://your-relay.example.com --new
```

Environment variables: `DEVICECHAT_SERVER` (relay URL), `DEVICECHAT_HOME`
(identity dir), `DEVICECHAT_NAME`.

## Run your own relay server (free tier)

The server is a tiny stateless WebSocket relay. Deploy once; anyone can use it.
It learns nothing.

```bash
# from the repo root
npm install
npm run build
npm run relay            # or: PORT=8080 node dist/relay.js
```

It also serves `GET /` -> `devicechat relay ok` for health checks / uptime pings.

### Deploy to a free host

**Railway** — `railway.toml`:
```toml
[build]
buildCommand = "npm install && npm run build"
[deploy]
startCommand = "node dist/relay.js"
healthcheckPath = "/"
[env]
PORT = "8080"
```

**Render** — `render.yaml`:
```yaml
services:
  - type: web
    name: devicechat-relay
    runtime: docker
    plan: free
    healthCheckPath: "/"
    envVars:
      - key: PORT
        value: "8080"
```

**Fly.io** — `fly.toml`:
```toml
app = "devicechat-relay"
[build]
  [env]
    PORT = "8080"
[[services]]
  internal_port = 8080
  protocol = "tcp"
  [[services.ports]]
    port = 80
    handlers = ["http"]
  [[services.ports]]
    port = 443
    handlers = ["tls", "http"]
  [services.concurrency]
    type = "connections"
    hard_limit = 100
```

Add a `Dockerfile` at repo root:
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package.json package-lock.json* ./
RUN npm install
RUN npm run build
EXPOSE 8080
CMD ["node", "dist/relay.js"]
```

After deploy, point clients at it: `devicechat --server wss://<your-app>.fly.dev --new`.

## Project layout

```
src/
  crypto.ts     X25519 + secretbox crypto (libsodium, on-device)
  protocol.ts   wire protocol encode/decode + message types
  types.ts      local Identity type
  shared.ts     re-exports of the above
  relay.ts      stateless WebSocket relay (no persistence) — `devicechat-relay` bin
  client.ts     ChatClient engine
  store.ts      local identity store
  ui.tsx        devicechat TUI client (ink) — `devicechat` bin
  index.ts      CLI entry point
```

## Testing

```bash
npm run build                 # build the single package
node run-e2e.mjs              # spins relay + two distinct clients, asserts E2E
```

The E2E test verifies: two distinct identities connect, exchange an anonymous
token, derive matching safety numbers, and deliver correctly named, decrypted
messages — while the relay only ever sees ciphertext.
