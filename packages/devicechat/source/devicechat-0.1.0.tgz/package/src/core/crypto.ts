import {
  getSodium,
  initSodium,
  isReady,
  setSodium,
  type SodiumProvider,
} from './sodium.js';

export { initSodium, isReady, setSodium, type SodiumProvider };

function toB64(bytes: Uint8Array): string {
  const s = getSodium();
  return s.to_base64(bytes, s.base64_variants.ORIGINAL);
}

function fromB64(b64: string): Uint8Array {
  const s = getSodium();
  return s.from_base64(b64, s.base64_variants.ORIGINAL);
}

/**
 * Generate an X25519 key pair. Keys are returned as base64 strings.
 */
export function generateKeyPair(): { publicKey: string; privateKey: string } {
  const s = getSodium();
  const kp = s.crypto_box_keypair();
  return {
    publicKey: toB64(kp.publicKey),
    privateKey: toB64(kp.privateKey),
  };
}

/**
 * ECDH: derive a shared 32-byte secret from my private key and a peer public key.
 */
export function deriveSharedKey(
  myPrivateKeyB64: string,
  peerPublicKeyB64: string,
): string {
  const s = getSodium();
  const shared = s.crypto_scalarmult(
    fromB64(myPrivateKeyB64),
    fromB64(peerPublicKeyB64),
  );
  return toB64(shared);
}

/**
 * Encrypt plaintext with a shared secret using crypto_secretbox_easy.
 * Returns base64 ciphertext and a base64 24-byte nonce.
 */
export function encrypt(
  sharedKeyB64: string,
  plaintext: string,
): { ciphertext: string; nonce: string } {
  const s = getSodium();
  const nonce = s.randombytes_buf(s.crypto_secretbox_NONCEBYTES);
  const ciphertext = s.crypto_secretbox_easy(
    s.from_string(plaintext),
    nonce,
    fromB64(sharedKeyB64),
  );
  return {
    ciphertext: toB64(ciphertext),
    nonce: toB64(nonce),
  };
}

/**
 * Decrypt a ciphertext+nonce with a shared secret.
 * Returns null on a bad MAC (authentication failure) instead of throwing.
 */
export function decrypt(
  sharedKeyB64: string,
  ciphertextB64: string,
  nonceB64: string,
): string | null {
  const s = getSodium();
  try {
    const plaintext = s.crypto_secretbox_open_easy(
      fromB64(ciphertextB64),
      fromB64(nonceB64),
      fromB64(sharedKeyB64),
    );
    if (plaintext === null || plaintext === undefined) {
      return null;
    }
    return s.to_string(plaintext);
  } catch {
    // libsodium throws on a bad MAC / authentication failure; the spec wants
    // null instead of a thrown error.
    return null;
  }
}

/**
 * Safety number for out-of-band MITM verification.
 * Sort the two base64 public keys, concat, sha256, take first 12 hex as
 * XXXX-XXXX-XXXX.
 */
export function safetyNumber(pubA: string, pubB: string): string {
  const s = getSodium();
  const [a, b] = [pubA, pubB].sort();
  const hash = s.crypto_hash(s.from_string(a + b));
  const hex = s.to_hex(hash).slice(0, 12);
  return hex.replace(/(.{4})(.{4})(.{4})/, '$1-$2-$3');
}

/**
 * Anonymous routing token: 16 random bytes, base64, with + / = stripped so it is
 * URL/path safe. Used by the relay server purely as an opaque routing key.
 * (16 bytes gives ~22-char tokens and meaningfully more brute-force resistance
 * than the prior 8-byte tokens; tokens stay opaque strings everywhere.)
 */
export function randomToken(): string {
  const s = getSodium();
  const raw = s.randombytes_buf(16);
  return toB64(raw).replace(/[+/=]/g, '');
}

/**
 * Generate a fresh 32-byte symmetric group key (base64) for crypto_secretbox.
 * Used by the group-room founder; distributed to peers over pairwise ECDH
 * channels. The relay never sees it (it travels inside encrypted envelopes).
 */
export function randomGroupKey(): string {
  const s = getSodium();
  const raw = s.randombytes_buf(s.crypto_secretbox_KEYBYTES);
  return toB64(raw);
}
