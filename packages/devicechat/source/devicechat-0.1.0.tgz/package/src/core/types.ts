/**
 * A local device identity: a human-friendly name plus an X25519 key pair
 * (both keys as base64 strings).
 */
export interface Identity {
  name: string;
  publicKey: string;
  privateKey: string;
}
