/**
 * Wire protocol for the devicechat relay.
 *
 * PRIVACY: the relay server only ever sees `relay` envelopes carrying an opaque
 * base64 `payload`. It never inspects the payload, never stores device names or
 * public keys, and only keeps an in-memory token→socket mapping for routing.
 */

// Client -> Server
export interface AnnounceMessage {
  type: 'announce';
  token: string; // client claims this routing token; server maps token -> socket (in-memory only)
}

export interface RelayOutMessage {
  type: 'relay';
  token: string; // destination routing token
  payload: string; // base64 ciphertext+nonce blob; server forwards without inspecting
}

/**
 * Client -> Server: revoke a routing token.
 *
 * The host sends this for each previously-minted token before minting a fresh
 * one (see `client.resetToken()`). The relay forcibly closes whichever peer
 * is currently connected under that token and answers further `announce`
 * attempts under the same token with `{type:'error', message:'token revoked'}`
 * for the rest of THIS relay process's lifetime (the relay is in-memory and
 * stateless, so a relay restart clears the revoke record — which is fine,
 * because the host mints a brand-new token on its own restart anyway).
 *
 * Single-use posture: a token MAY be re-announced by the SAME socket during a
 * live session's auto-reconnect (the relay sees no current owner and no
 * revoke). Across host process restarts the host mints fresh, so reuse is
 * moot. Within a live session, `/reset-token` is the explicit "burn the
 * current token, kick everyone, mint a new one" knob.
 */
export interface RevokeMessage {
  type: 'revoke';
  token: string; // the token to burn
}

export type ClientMessage = AnnounceMessage | RelayOutMessage | RevokeMessage;

// Server -> Client
export interface ReadyMessage {
  type: 'ready';
  token: string; // ack that the token is registered
}

export interface RelayInMessage {
  type: 'relay';
  from: string; // opaque per-connection id, NOT a name
  payload: string; // forwarded opaque blob
}

export interface ErrorMessage {
  type: 'error';
  message: string;
  /**
   * Token of the peer route that failed (e.g. 'peer not connected' for a
   * `relay` envelope to a token that has no live socket). Set by the relay
   * for 'peer not connected' so the client knows WHICH of its peer slots to
   * clean up — without this, group fan-out leaves the client guessing.
   */
  token?: string;
}

export interface FullMessage {
  type: 'full'; // token already taken by a live socket
}

export type ServerMessage =
  | ReadyMessage
  | RelayInMessage
  | ErrorMessage
  | FullMessage;

export type AnyMessage = ClientMessage | ServerMessage;

/**
 * Encode a message to its JSON wire form.
 */
export function encode(msg: AnyMessage): string {
  return JSON.stringify(msg);
}

/**
 * Decode a JSON wire form into a typed message.
 * Throws if the payload is not a JSON object with a string `type`.
 */
export function decode<T = AnyMessage>(raw: string): T {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error('Invalid envelope: not valid JSON');
  }
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error('Invalid envelope: expected an object');
  }
  const obj = parsed as Record<string, unknown>;
  if (typeof obj.type !== 'string') {
    throw new Error('Invalid envelope: missing string "type"');
  }
  return obj as T;
}
