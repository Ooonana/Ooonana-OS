/**
 * Platform-agnostic sodium provider interface.
 *
 * Decoupling layer: the CORE crypto module never imports `node:*` or
 * `libsodium-wrappers-sumo` directly. A host (Node CLI, React Native app, ...)
 * supplies a concrete `SodiumProvider` via `setSodium()` / `initSodium()`.
 * This is the only place the core knows about libsodium's surface.
 */
export interface KeyPair {
  publicKey: Uint8Array;
  privateKey: Uint8Array;
}

export interface Base64Variants {
  ORIGINAL: number;
  ORIGINAL_NO_PADDING: number;
  URLSAFE: number;
  URLSAFE_NO_PADDING: number;
}

export interface SodiumProvider {
  ready: Promise<void>;
  crypto_secretbox_NONCEBYTES: number;
  crypto_secretbox_KEYBYTES: number;
  base64_variants: Base64Variants;
  to_base64(input: Uint8Array, variant?: number): string;
  from_base64(input: string, variant?: number): Uint8Array;
  from_string(str: string): Uint8Array;
  to_string(bytes: Uint8Array): string;
  to_hex(bytes: Uint8Array): string;
  from_hex(str: string): Uint8Array;
  randombytes_buf(length: number): Uint8Array;
  crypto_box_keypair(): KeyPair;
  crypto_scalarmult(privateKey: Uint8Array, publicKey: Uint8Array): Uint8Array;
  crypto_secretbox_easy(
    message: Uint8Array,
    nonce: Uint8Array,
    key: Uint8Array,
  ): Uint8Array;
  crypto_secretbox_open_easy(
    ciphertext: Uint8Array,
    nonce: Uint8Array,
    key: Uint8Array,
  ): Uint8Array | null;
  crypto_hash(message: Uint8Array): Uint8Array;
}

let sodium: SodiumProvider | null = null;
let ready = false;

/**
 * Inject a concrete sodium provider. The host calls this once at startup
 * (e.g. the Node adapter wires `libsodium-wrappers-sumo`; an RN adapter wires
 * a react-native-sodium binding). Must be called before `initSodium()`.
 */
export function setSodium(provider: SodiumProvider): void {
  sodium = provider;
  ready = false;
}

/**
 * Initialize the injected sodium provider. Must be awaited before any crypto
 * function is used. Safe to call multiple times; only the first call does
 * real work. Throws if no provider has been set.
 */
export async function initSodium(): Promise<void> {
  if (ready) return;
  if (!sodium) {
    throw new Error(
      'no SodiumProvider injected; call setSodium() before initSodium()',
    );
  }
  await sodium.ready;
  ready = true;
}

/**
 * Returns true once `initSodium()` has completed. Lets adapters/guards check
 * readiness without forcing initialization.
 */
export function isReady(): boolean {
  return ready;
}

/**
 * Internal accessor for the injected provider. Throws if not set/ready so
 * misuse fails loudly rather than silently producing bad output.
 */
export function getSodium(): SodiumProvider {
  if (!sodium) {
    throw new Error(
      'no SodiumProvider injected; call setSodium() + initSodium() first',
    );
  }
  if (!ready) {
    throw new Error('libsodium is not ready; call initSodium() first');
  }
  return sodium;
}
