import { homedir } from 'node:os';
import { join } from 'node:path';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { generateKeyPair, initSodium } from './crypto.js';
import type { Identity } from './types.js';

export type { Identity };

/**
 * Local identity store. The identity (name + X25519 keypair) lives ONLY on this
 * device. The relay server never sees it. The device name is sent inside the
 * encrypted payload, never in cleartext on the wire.
 */

function homeDir(): string {
  return process.env.DEVICECHAT_HOME || join(homedir(), '.devicechat');
}

function identityPath(): string {
  return join(homeDir(), 'identity.json');
}

let cached: Identity | null = null;

/**
 * Load the local identity, generating and persisting a fresh one on first run.
 * `name` is used when generating a new identity (e.g. from --name); otherwise
 * the caller is expected to have prompted for a name before calling this.
 */
export async function loadIdentity(name?: string): Promise<Identity> {
  if (cached) return cached;
  const path = identityPath();
  if (existsSync(path)) {
    const raw = readFileSync(path, 'utf8');
    cached = JSON.parse(raw) as Identity;
    return cached;
  }
  await initSodium();
  const kp = generateKeyPair();
  const identity: Identity = {
    name: name ?? 'anon',
    publicKey: kp.publicKey,
    privateKey: kp.privateKey,
  };
  saveIdentity(identity);
  cached = identity;
  return identity;
}

export function saveIdentity(identity: Identity): void {
  const dir = homeDir();
  mkdirSync(dir, { recursive: true });
  writeFileSync(identityPath(), JSON.stringify(identity, null, 2), { encoding: 'utf8', mode: 0o600 });
  cached = identity;
}

export async function getName(): Promise<string> {
  return (await loadIdentity()).name;
}

/** Test/internal helper: drop the cached identity so a different home loads. */
export function _resetIdentityCache(): void {
  cached = null;
}

export async function setName(name: string): Promise<void> {
  const id = await loadIdentity();
  id.name = name;
  saveIdentity(id);
}

// --- User-custom color ---------------------------------------------------
// Stored in ~/.devicechat/color.json so a fresh install OR a different machine
// resets cleanly. The color overrides the per-pubkey palette hash for OUR OWN
// chat lines and status-bar name (peers still see us via their own palette
// hash of OUR pubkey — the override is local-only, NOT a transmitted field).
// Format: hex string like '#f59e0b', or empty string for default.

function colorPath(): string {
  return join(homeDir(), 'color.json');
}

export function loadColor(): string {
  try {
    const raw = readFileSync(colorPath(), 'utf8');
    const obj = JSON.parse(raw) as { color?: string };
    return typeof obj.color === 'string' ? obj.color : '';
  } catch {
    return '';
  }
}

export function saveColor(color: string): void {
  const dir = homeDir();
  mkdirSync(dir, { recursive: true });
  writeFileSync(colorPath(), JSON.stringify({ color }, null, 2), { encoding: 'utf8', mode: 0o600 });
}
