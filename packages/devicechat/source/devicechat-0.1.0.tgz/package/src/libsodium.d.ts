// Minimal ambient module declaration for libsodium-wrappers-sumo.
// The published package only ships a CommonJS build (despite declaring ESM in
// package.json), so we import the default export (the module.exports object)
// which carries `ready` and all `crypto_*` functions added at runtime.
// All crypto is performed on-device.
declare module 'libsodium-wrappers-sumo' {
  export interface KeyPair {
    publicKey: Uint8Array;
    privateKey: Uint8Array;
  }

  export const ready: Promise<void>;

  export const crypto_box_PUBLICKEYBYTES: number;
  export const crypto_box_SECRETKEYBYTES: number;
  export const crypto_box_NONCEBYTES: number;
  export const crypto_secretbox_KEYBYTES: number;
  export const crypto_secretbox_NONCEBYTES: number;

  export const base64_variants: {
    ORIGINAL: number;
    ORIGINAL_NO_PADDING: number;
    URLSAFE: number;
    URLSAFE_NO_PADDING: number;
  };

  export function to_base64(input: Uint8Array, variant?: number): string;
  export function from_base64(input: string, variant?: number): Uint8Array;

  export function from_string(str: string): Uint8Array;
  export function to_string(bytes: Uint8Array): string;

  export function to_hex(bytes: Uint8Array): string;
  export function from_hex(str: string): Uint8Array;

  export function randombytes_buf(length: number): Uint8Array;

  export function crypto_box_keypair(): KeyPair;

  export function crypto_scalarmult(
    privateKey: Uint8Array,
    publicKey: Uint8Array,
  ): Uint8Array;

  export function crypto_secretbox_easy(
    message: Uint8Array,
    nonce: Uint8Array,
    key: Uint8Array,
  ): Uint8Array;

  export function crypto_secretbox_open_easy(
    ciphertext: Uint8Array,
    nonce: Uint8Array,
    key: Uint8Array,
  ): Uint8Array | null;

  export function crypto_hash(message: Uint8Array): Uint8Array;

  const sodium: {
    ready: Promise<void>;
    crypto_box_PUBLICKEYBYTES: number;
    crypto_box_SECRETKEYBYTES: number;
    crypto_box_NONCEBYTES: number;
    crypto_secretbox_KEYBYTES: number;
    crypto_secretbox_NONCEBYTES: number;
    base64_variants: {
      ORIGINAL: number;
      ORIGINAL_NO_PADDING: number;
      URLSAFE: number;
      URLSAFE_NO_PADDING: number;
    };
    to_base64(input: Uint8Array, variant?: number): string;
    from_base64(input: string, variant?: number): Uint8Array;
    from_string(str: string): Uint8Array;
    to_string(bytes: Uint8Array): string;
    to_hex(bytes: Uint8Array): string;
    from_hex(str: string): Uint8Array;
    randombytes_buf(length: number): Uint8Array;
    crypto_box_keypair(): KeyPair;
    crypto_scalarmult(
      privateKey: Uint8Array,
      publicKey: Uint8Array,
    ): Uint8Array;
    crypto_secretbox_easy(
      message: Uint8Array,
      nonce: Uint8Array,
      key: Uint8Array,
    ): Uint8Array;
    crypto_secretbox_open_easy(
      ciphertext: Uint8Array,
      nonce: Uint8Array,
      key: Uint8Array,
    ): Uint8Array | null;
    crypto_hash(message: Uint8Array): Uint8Array;
  };

  export default sodium;
}
