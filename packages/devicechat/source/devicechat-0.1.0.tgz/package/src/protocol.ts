/**
 * Wire protocol for the devicechat relay.
 *
 * PRIVACY: the relay server only ever sees `relay` envelopes carrying an opaque
 * base64 `payload`. It never inspects the payload, never stores device names or
 * public keys, and only keeps an in-memory token→socket mapping for routing.
 */

// Client -> Server
export interface AnnounceMessage {
  type: 'announce';
  token: string; // client claims this routing token; server maps token -> socket (in-memory only)
}

export interface RelayOutMessage {
  type: 'relay';
  token: string; // destination routing token
  payload: string; // base64 ciphertext+nonce blob; server forwards without inspecting
}

export type ClientMessage = AnnounceMessage | RelayOutMessage;

// Server -> Client
export interface ReadyMessage {
  type: 'ready';
  token: string; // ack that the token is registered
}

export interface RelayInMessage {
  type: 'relay';
  from: string; // opaque per-connection id, NOT a name
  payload: string; // forwarded opaque blob
}

export interface ErrorMessage {
  type: 'error';
  message: string;
}

export interface FullMessage {
  type: 'full'; // token already taken by a live socket
}

export type ServerMessage =
  | ReadyMessage
  | RelayInMessage
  | ErrorMessage
  | FullMessage;

export type AnyMessage = ClientMessage | ServerMessage;

/**
 * Encode a message to its JSON wire form.
 */
export function encode(msg: AnyMessage): string {
  return JSON.stringify(msg);
}

/**
 * Decode a JSON wire form into a typed message.
 * Throws if the payload is not a JSON object with a string `type`.
 */
export function decode<T = AnyMessage>(raw: string): T {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error('Invalid envelope: not valid JSON');
  }
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error('Invalid envelope: expected an object');
  }
  const obj = parsed as Record<string, unknown>;
  if (typeof obj.type !== 'string') {
    throw new Error('Invalid envelope: missing string "type"');
  }
  return obj as T;
}
