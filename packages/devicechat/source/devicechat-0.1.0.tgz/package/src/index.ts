#!/usr/bin/env node
// Entry point. The full-screen TUI lives in ./ui.tsx.
// The `server` subcommand manages the local relay + cloudflare tunnel.
// The `host` subcommand starts the server, prints a friend-ready invite line,
// then drops you into the chat TUI as the host.

const argv = process.argv.slice(2);

if (argv[0] === 'server') {
  const sub = (argv[1] || '').toLowerCase();
  const ctl = await import('./serverctl.js');
  if (sub === 'on' || sub === 'start') await ctl.serverStart();
  else if (sub === 'off' || sub === 'stop' || sub === 'kill') await ctl.serverStop();
  else if (sub === 'status' || sub === 'state') await ctl.serverStatus();
  else { ctl.printServerUsage(); process.exit(2); }
  process.exit(0);
}

if (argv[0] === 'host') {
  // Start relay + tunnel, then run the chat TUI as host. The TUI reads
  // DEVICECHAT_INVITE_URL and uses it to print a friend-ready one-liner with
  // the host's REAL token + key (minted by the TUI itself), so the invite
  // line always matches the live session.
  const ctl = await import('./serverctl.js');
  await ctl.serverStart();
  const tunnelUrl = ctl.readTunnelUrl();
  const port = Number(process.env.PORT) || 8080;
  if (tunnelUrl) {
    process.env.DEVICECHAT_INVITE_URL = tunnelUrl.replace(/^http/, 'ws');
  } else {
    console.error('tunnel did not come up; run "devicechat host" again or check "devicechat server status".');
    process.exit(1);
  }
  // Run the TUI as the host on the local relay.
  const rest = process.argv.slice(3).filter((a) => a !== '--server');
  process.argv = [process.argv[0], process.argv[1], '--new', '--server', `ws://localhost:${port}`, ...rest];
} else {
  // Bug#1 fix: bare `devicechat`, `devicechat --new`, and `devicechat --join …`
  // all connect to ws://localhost:8080 by default. If no relay is listening
  // there, the WS fails and the UI sits on "offline / locking…" forever (the
  // "connecting forever" bug). Auto-start the local relay (same detached-child
  // mechanism `host` uses) so a plain `devicechat` Just Works on a fresh
  // machine. Skip only if the user explicitly set --server to a remote URL
  // (they're joining someone else's relay) or set DEVICECHAT_SERVER.
  const hasRemoteServer =
    argv.includes('--server') ||
    Boolean(process.env.DEVICECHAT_SERVER);
  if (!hasRemoteServer) {
    const ctl = await import('./serverctl.js');
    await ctl.serverStart();
    const port = Number(process.env.PORT) || 8080;
    // Ensure the TUI connects to the local relay we just started.
    process.argv = [process.argv[0], process.argv[1], '--server', `ws://localhost:${port}`, ...argv];
  }
}

await import('./ui.js');
