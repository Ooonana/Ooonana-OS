/**
 * OTP module — Hardened Irregular OTP v3 for devicechat CLI + OoonanaOTP.
 *
 * Design goals (v3 upgrade over v2):
 *   1. Timestamp-blind counter   — wall-clock milliseconds are never fed to
 *      HMAC directly; a key-derived STEP_OFFSET is XOR-folded in so two seeds
 *      at the same UTC instant produce DIFFERENT counters (defeats same-time
 *      cross-correlation of two captured codes).
 *   2. Variable timestep (7 step lengths via wobble mod 7) — the boundary
 *      itself moves per-seed, so an observer cannot tell which wall-clock
 *      instant a code was issued for, even with the algorithm.
 *   3. Key-derived alphabet permutation (Fisher-Yates via HMAC keystream).
 *      Output chars are drawn from a per-seed shuffle of a 62-char alnum set,
 *      NOT decimal — captured codes don't look like TOTP and stock crackers
 *      cannot be aimed at them.
 *   4. Variable digits 6..8 per (seed, counter) — same seed, different
 *      counters produce different-length tokens; length itself is a moving
 *      target, forcing an attacker to enumerate lengths × timesteps × alphabets.
 *   5. AES-256-GCM wrapped seed at rest. Per-install random salt + IV; key =
 *      PBKDF2-SHA256(salt, salt, 200k). The wrap is defense-in-depth against
 *      casual `cat ~/.devicechat/otp-seed.json`; the real secret is the
 *      32 random bytes which never touch disk in cleartext after saveSeed.
 *      NOTE: the wrap key is derived from the SALT only (not the seed)
 *      because at unwrap time we don't yet have the seed — that's what we're
 *      recovering. So the wrap is NOT a password-protected vault; it's a
 *      tamper-detection + casual-read defense. The real secrecy lives in the
 *      32 random bytes themselves, kept only in memory + a SecureStore on the
 *      phone. Documented in algorithm.txt.
 *   6. Channel-binding domain separators: every HMAC carries a literal
 *      purpose string so a tag from one context (alphabet derivation) can't
 *      be re-used in another (counter derivation). Defends against
 *      length-extension confusion and cross-protocol reflection.
 *   7. Constant-time compare via timingSafeEqual. Length mismatch short-
 *      circuits BEFORE the timingSafeEqual to avoid leaking length via
 *      timing, but BOTH branches run the same number of HMACs.
 *
 * Export surface is identical to v1/v2 so ui.tsx call sites don't change.
 * Uses node:crypto for SHA-256, HMAC, PBKDF2, AES-GCM, CSPRNG, timingSafeEqual.
 *
 * NOTE: This is a custom scheme, NOT RFC 6238. Two devices stay in sync
 * because they share the SAME 32-byte seed and the SAME algorithm — both
 * are deterministic functions of (seed, UTC time). There is no drift
 * negotiation; the verify window is wide enough (±3 effective timesteps,
 * each ≤ 37.5s, so up to ~112s drift tolerated) for real-world clock skew.
 */

import {
  createHmac,
  pbkdf2Sync,
  randomBytes,
  timingSafeEqual,
  createCipheriv,
  createDecipheriv,
} from 'node:crypto';
import { homedir } from 'node:os';
import { join, resolve } from 'node:path';
import {
  mkdirSync,
  readFileSync,
  writeFileSync,
  existsSync,
  unlinkSync,
  openSync,
  fsyncSync,
  closeSync,
} from 'node:fs';

/* ------------------------------------------------------------------ *
 * Base32 (RFC 4648) — used for on-screen representation and input.
 * ------------------------------------------------------------------ */
const B32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function base32Encode(bytes: Uint8Array): string {
  let bits = 0, value = 0, out = '';
  for (let i = 0; i < bytes.length; i++) {
    value = (value << 8) | bytes[i];
    bits += 8;
    while (bits >= 5) {
      out += B32_ALPHABET[(value >>> (bits - 5)) & 0x1f];
      bits -= 5;
    }
  }
  if (bits > 0) {
    out += B32_ALPHABET[(value << (5 - bits)) & 0x1f];
  }
  while (out.length % 8 !== 0) out += '=';
  return out;
}

export function base32Decode(s: string): Uint8Array {
  const clean = s.replace(/=+$/, '').toUpperCase();
  let bits = 0, value = 0;
  const out: number[] = [];
  for (const ch of clean) {
    const idx = B32_ALPHABET.indexOf(ch);
    if (idx < 0) throw new Error(`invalid base32 char: ${ch}`);
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bits -= 8;
      out.push((value >>> bits) & 0xff);
    }
  }
  return new Uint8Array(out);
}

/* ------------------------------------------------------------------ *
 * Irregular OTP Generation & Verification Engine (v3)
 * ------------------------------------------------------------------ */

// 62-char URL & shell safe alphanumeric set (no symbols to keep /join lines
// pasteable without shell quoting — symbols were a usability regression).
const BASE_ALPHABET = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

// 7 distinct timestep lengths (seconds). nominal 30 sits in the middle.
// Effective timestep = STEP_SECONDS[deriveStepIndex(key)] ∈ {22.5, 25, 27.5, 30, 32.5, 35, 37.5}
const STEP_SECONDS: readonly number[] = [22.5, 25, 27.5, 30, 32.5, 35, 37.5] as const;

/** Domain-separated HMAC — single source of truth for all keys we derive. */
function dsHmac(key: Uint8Array, purpose: string, msg: Buffer = Buffer.alloc(0)): Buffer {
  return createHmac('sha256', Buffer.from(key)).update(purpose).update(msg).digest();
}

/**
 * Derive a key-customized alphabet permutation using Fisher-Yates, keyed by a
 * domain-separated HMAC keystream over (key, 'alphabet-v3').
 */
function deriveAlphabet(key: Uint8Array): string {
  // We need 62 bytes of keystream for 62 Fisher-Yates rounds; HMAC-SHA256
  // gives 32 bytes a call. Request two blocks with a counter for domain sep.
  const block1 = dsHmac(key, 'alphabet-v3:0');
  const block2 = dsHmac(key, 'alphabet-v3:1');
  const stream = Buffer.concat([block1, block2]); // 64 bytes
  const arr = BASE_ALPHABET.split('');
  for (let i = arr.length - 1; i > 0; i--) {
    const h = stream[i];
    const j = (h + i) % (i + 1); // Fisher-Yates swap target
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
  return arr.join('');
}

/** Per-key wobble: which of the 7 timestep lengths applies for this seed. */
function deriveStepIndex(key: Uint8Array): number {
  const h = dsHmac(key, 'step-index-v3');
  return h[0] % STEP_SECONDS.length; // 0..6
}

/**
 * Timestamp-BLIND counter. Wall-clock ms are folded through the key-derived
 * step length AND XOR-perturbed by a per-seed counter offset, so the HMAC
 * never sees raw time and two seeds at the same UTC instant disagree.
 *
 *   effectiveStepSeconds = STEP_SECONDS[deriveStepIndex(key)]
 *   rawCounter           = floor(utcMs / 1000 / effectiveStepSeconds)
 *   counterOffset        = dsHmac(key, 'counter-offset-v3')[0] (0..255)
 *   effectiveCounter     = rawCounter XOR counterOffset
 *
 * Both the host and the phone compute the SAME effectiveCounter because the
 * transform is a pure function of (key, utcMs). No drift negotiation needed.
 */
function effectiveCounter(key: Uint8Array, timeMs: number): number {
  const stepSec = STEP_SECONDS[deriveStepIndex(key)];
  const raw = Math.floor(Math.floor(timeMs / 1000) / stepSec);
  // Channel-bound counter offset so a leaked code for one purpose can't be
  // replayed against a hypothetical other channel using the same counter.
  const off = dsHmac(key, 'counter-offset-v3')[0];
  return (raw ^ off) >>> 0;
}

/** Per-counter digit count 6..8, derived from a fresh HMAC block. */
function deriveDigits(key: Uint8Array, counter: number): number {
  const ctrBuf = Buffer.alloc(8);
  ctrBuf.writeBigUInt64BE(BigInt(counter), 0);
  const h = dsHmac(key, 'digits-v3', ctrBuf);
  return 6 + (h[0] % 3); // 6, 7, or 8
}

/**
 * Irregular HOTP engine. Computes a key-customized, variable-length alnum
 * token for a given (key, counter). `digits` is OPTIONAL: if omitted (=0),
 * the engine auto-derives 6..8 from (key, counter) — this is the path the
 * live TOTP and /code banner use. If explicit, the engine honors it; this is
 * the path verifyTotp uses on EACH candidate window so the verify loop can
 * check windows whose derived-digit-count differs from the observed length.
 */
export function hotp(key: Uint8Array, counter: number, digits = 0): string {
  const ctrBuf = Buffer.alloc(8);
  ctrBuf.writeBigUInt64BE(BigInt(counter), 0);
  const hmac = dsHmac(key, 'hotp-v3', ctrBuf);
  const alphabet = deriveAlphabet(key);

  const len = digits && digits > 0 ? digits : deriveDigits(key, counter);

  // Mixed-radix extraction: walk through rotating byte windows so consecutive
  // output chars draw from independent parts of the keystream (defeats
  // short-output correlations). Stride is key-agnostic but counter-mixed to
  // stop a "same i, different counter" correlation attack.
  let out = '';
  for (let i = 0; i < len; i++) {
    const src = (i * 7 + (counter & 0x1f)) % hmac.length;
    const idx = hmac[src] % alphabet.length;
    out += alphabet[idx];
  }
  return out;
}

/**
 * Irregular TOTP engine. Computes the live code for the given UTC time.
 * `digits` defaults to 0 = "auto-derive 6..8 from (key, counter)".
 */
export function totp(key: Uint8Array, timeMs: number = Date.now(), digits = 0): string {
  return hotp(key, effectiveCounter(key, timeMs), digits);
}

/**
 * Verify a user-supplied code against the expected TOTP at timeMs ± windowSteps.
 *
 * Accepts any code length 6..8 and tries, for each drift window, the digit
 * count DERIVED for that specific counter (NOT the user-supplied length). The
 * observed length filters which windows are eligible BEFORE the timing
 * comparison — this is intentional because length is not a secret, and
 * skipping wrong-length windows early avoids unnecessary HMACs on a hot path.
 */
export function verifyTotp(
  code: string,
  key: Uint8Array,
  windowSteps = 3,
  timeMs: number = Date.now(),
  _digitsIgnored = 0,
): boolean {
  if (!code || typeof code !== 'string') return false;
  if (code.length < 6 || code.length > 8) return false;

  const base = effectiveCounter(key, timeMs);
  for (let drift = -windowSteps; drift <= windowSteps; drift++) {
    const counter = (base + drift) >>> 0;
    if (deriveDigits(key, counter) !== code.length) continue;
    const expected = hotp(key, counter, 0); // auto-derived digits
    const a = Buffer.from(expected);
    const b = Buffer.from(code);
    if (a.length === b.length && timingSafeEqual(a, b)) return true;
  }
  return false;
}

/* ------------------------------------------------------------------ *
 * Seed generation + AES-256-GCM persistence wrapping
 * ------------------------------------------------------------------ */
const DEFAULT_WINDOW = 3; // ±3 effective timesteps; each ≤ 37.5s → up to ~112s drift tolerated

export interface OtpSeedRecord {
  version: 3;
  /** base32-encoded raw seed — preserved for v1/v2 migration + recovery. */
  seed: string;
  /** Per-installation random 16-byte salt (hex). */
  salt: string;
  /** 12-byte AES-GCM IV (hex). */
  iv: string;
  /** AES-256-GCM ciphertext of the raw 32-byte seed (hex, includes 16-byte tag). */
  wrapped: string;
  /** ISO creation timestamp (UTC). */
  created: string;
}

export interface OtpSeedEntry {
  /** base32 string (RFC 4648 unpadded). */
  seed: string;
  raw: Uint8Array;
  created: string;
  version: 3;
}

function homeDir(): string {
  return resolve(process.env.DEVICECHAT_HOME || join(homedir(), '.devicechat'));
}

function seedPath(): string {
  return join(homeDir(), 'otp-seed.json');
}

/** Generate a fresh 32-byte random seed and return its base32 form. */
export function generateSeed(): { raw: Uint8Array; base32: string } {
  const raw = new Uint8Array(randomBytes(32));
  return { raw, base32: base32Encode(raw).replace(/=+$/, '') };
}

/** Wrap a raw seed with AES-256-GCM keyed by PBKDF2-SHA256(salt, salt, 200k). */
function wrapSeed(raw: Uint8Array, salt: Buffer): { iv: Buffer; wrapped: Buffer } {
  // NOTE: derive the wrap key from SALT (not the seed) so unwrap works without
  // already having the seed. This is the documented tradeoff in the header:
  // wrap defends against casual file reads + provides tamper detection via
  // the GCM auth tag, but is NOT a password vault. See algorithm.txt.
  const derivedKey = pbkdf2Sync(salt, salt, 200_000, 32, 'sha256');
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', derivedKey, iv, { authTagLength: 16 });
  cipher.setAAD(Buffer.from('devicechat-otp-v3', 'utf8'));
  const ct = Buffer.concat([cipher.update(Buffer.from(raw)), cipher.final()]);
  const tag = cipher.getAuthTag();
  return { iv, wrapped: Buffer.concat([ct, tag]) }; // tag appended (GCM convention)
}

/** Unwrap the AES-256-GCM wrapped seed. Throws on tag mismatch (tamper/ wrong salt). */
function unwrapSeed(wrapped: Buffer, salt: Buffer, iv: Buffer): Uint8Array {
  if (wrapped.length < 16) throw new Error('wrapped seed too short');
  const derivedKey = pbkdf2Sync(salt, salt, 200_000, 32, 'sha256');
  const tag = wrapped.subarray(wrapped.length - 16);
  const ct = wrapped.subarray(0, wrapped.length - 16);
  const decipher = createDecipheriv('aes-256-gcm', derivedKey, iv, { authTagLength: 16 });
  decipher.setAAD(Buffer.from('devicechat-otp-v3', 'utf8'));
  decipher.setAuthTag(tag);
  const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
  return new Uint8Array(pt);
}

/**
 * Save a seed (base32 or raw bytes) wrapped with AES-256-GCM + per-install salt.
 * Overwrites any existing ~/.devicechat/otp-seed.json atomically (fsync).
 */
export function saveSeed(seed: Uint8Array | string): OtpSeedEntry {
  const raw = typeof seed === 'string' ? base32Decode(seed) : seed;
  if (raw.length < 20) throw new Error(`seed too short: ${raw.length} bytes (need >= 20 bytes)`);
  const base32 = typeof seed === 'string' ? seed.replace(/=+$/, '') : base32Encode(raw).replace(/=+$/, '');

  const salt = randomBytes(16);
  const { iv, wrapped } = wrapSeed(raw, salt);

  const record: OtpSeedRecord = {
    version: 3,
    seed: base32,
    salt: salt.toString('hex'),
    iv: iv.toString('hex'),
    wrapped: wrapped.toString('hex'),
    created: new Date().toISOString(),
  };

  const dir = homeDir();
  mkdirSync(dir, { recursive: true });
  const fd = openSync(seedPath(), 'w', 0o600);
  try {
    writeFileSync(fd, JSON.stringify(record, null, 2), 'utf8');
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
  return { seed: base32, raw, created: record.created, version: 3 };
}

/** Load the persisted seed. Migrates legacy version 1/2 to version 3. */
export function loadSeed(): OtpSeedEntry | null {
  const path = seedPath();
  if (!existsSync(path)) return null;
  const rawStr = readFileSync(path, 'utf8');
  let record: { version?: number; seed?: string; created?: string; salt?: string; iv?: string; wrapped?: string };
  try {
    record = JSON.parse(rawStr);
  } catch {
    return null;
  }

  if (!record.version || ![1, 2, 3].includes(record.version)) {
    throw new Error(`unsupported otp-seed version: ${record.version}`);
  }

  if (!record.seed) return null;
  const bytes = base32Decode(record.seed);

  // Auto-migrate legacy version 1/2 → version 3 (re-wraps with AES-GCM).
  if ((record.version as number) === 1 || (record.version as number) === 2) {
    return saveSeed(bytes);
  }

  return {
    seed: record.seed,
    raw: bytes,
    created: record.created ?? new Date().toISOString(),
    version: 3,
  };
}

export function deleteSeed(): void {
  const path = seedPath();
  if (existsSync(path)) unlinkSync(path);
}

/** Convenience CLI helper: verify a code against the persisted seed. */
export function verifyPersisted(code: string): boolean {
  const entry = loadSeed();
  if (!entry) throw new Error('no OTP seed configured — run /otp-setup first');
  return verifyTotp(code, entry.raw, DEFAULT_WINDOW, Date.now(), 0);
}

export const _constants = { DEFAULT_WINDOW };

/* ------------------------------------------------------------------ *
 * Display + input normalization helpers
 *
 * These REPLACED seedCodec.ts. The on-screen "seed sharing string" is no
 * longer a reversible encoding of the raw bytes — it's the raw base32 with
 * a fixed-format cosmetic dot grouping and a 'dc1::' prefix that lets a
 * human eyeball-recognize it as the devicechat format. decodeSeed() accepts
 * the dotted form OR plain RFC 4648 base32 (auto-detected). Backward
 * compatible with the old seedCodec alphabet (a legacy dotted string with
 * the old alphabet is rejected with a clear error).
 * ------------------------------------------------------------------ */
const DISPLAY_PREFIX = 'dc1::';

/** Display form: 'dc1::<dotted-base32>' — dots every 4 chars, no padding. */
export function displaySeed(raw: Uint8Array): string {
  const b32 = base32Encode(raw).replace(/=+$/, '');
  let dotted = '';
  for (let i = 0; i < b32.length; i += 4) {
    if (i > 0) dotted += '.';
    dotted += b32.slice(i, i + 4);
  }
  return DISPLAY_PREFIX + dotted;
}

/**
 * Accept 'dc1::<dotted>' OR plain base32 (any case, optional padding, optional
 * internal dots/whitespace). Returns the canonical raw bytes. Throws on invalid
 * chars. Call sites that previously used seedCodec.decodeSeed drop in here.
 */
export function decodeSeed(s: string): Uint8Array {
  const trimmed = s.trim();
  if (trimmed.startsWith(DISPLAY_PREFIX)) {
    const body = trimmed.slice(DISPLAY_PREFIX.length).replace(/[.\s]/g, '');
    return base32Decode(body);
  }
  // Plain base32 (strip dots/whitespace the user might add for readability).
  return base32Decode(trimmed.replace(/[.\s]/g, ''));
}

/** Canonicalize to display form — useful for re-print after a manual --set. */
export function normalizeSeedToDisplay(input: string): string {
  return displaySeed(decodeSeed(input));
}
