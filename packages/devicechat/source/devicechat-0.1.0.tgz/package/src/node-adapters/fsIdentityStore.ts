import type { IdentityStore } from '../core/client.js';
import type { Identity } from '../core/types.js';
import { loadIdentity, saveIdentity, setName } from '../store.js';

/**
 * Node IdentityStore backed by the existing src/store.ts (JSON file under
 * DEVICECHAT_HOME || ~/.devicechat/identity.json). The store module already
 * owns the path logic + the test-only `_resetIdentityCache` helper used by
 * run-e2e.mjs, so we delegate rather than duplicate.
 */
export function createFsIdentityStore(): IdentityStore {
  return {
    async load(name?: string): Promise<Identity> {
      return loadIdentity(name);
    },
    async save(id: Identity): Promise<void> {
      saveIdentity(id);
    },
    async setName(name: string): Promise<void> {
      await setName(name);
    },
  };
}
