import WebSocket from 'ws';
import type { Transport } from '../core/client.js';

/**
 * Node Transport backed by the `ws` package. Each call to the factory produces
 * a fresh socket (the core client reconnects on drop, so it asks for a new
 * Transport per (re)connect). String frames only: outbound `send(string)`,
 * inbound Buffer/ArrayBuffer decoded to utf8 to match the original client.
 */
export function createWsTransport(url: string): Transport {
  // 256MB maxPayload — matches the relay's cap so large file envelopes
  // (base64-encoded files up to ~190MB) can be received without the ws
  // layer silently closing the connection on an oversized frame.
  const ws = new WebSocket(url, { maxPayload: 256 * 1024 * 1024 });
  let openCb: (() => void) | null = null;
  let messageCb: ((raw: string) => void) | null = null;
  let closeCb: (() => void) | null = null;
  let errorCb: ((e: Error) => void) | null = null;

  ws.on('open', () => openCb?.());
  ws.on('message', (data) => {
    // ws delivers Buffer | ArrayBuffer | Buffer[]; coerce to a utf8 string the
    // same way the original client.ts did.
    const raw = Buffer.isBuffer(data)
      ? data.toString('utf8')
      : Array.isArray(data)
        ? Buffer.concat(data as Buffer[]).toString('utf8')
        : Buffer.from(data as ArrayBuffer).toString('utf8');
    messageCb?.(raw);
  });
  ws.on('close', () => closeCb?.());
  ws.on('error', (err: Error) => errorCb?.(err));

  return {
    send(raw: string): void {
      if (ws.readyState === WebSocket.OPEN) ws.send(raw);
    },
    onMessage(cb: (raw: string) => void): void {
      messageCb = cb;
    },
    onClose(cb: () => void): void {
      closeCb = cb;
    },
    onError(cb: (e: Error) => void): void {
      errorCb = cb;
    },
    onOpen(cb: () => void): void {
      openCb = cb;
    },
    close(): void {
      try {
        ws.close();
      } catch {
        // ignore — close during teardown is best-effort
      }
    },
    get isConnected(): boolean {
      return ws.readyState === WebSocket.OPEN;
    },
  };
}
