import { createRequire } from 'node:module';
import type { SodiumProvider } from '../core/sodium.js';

// The published `libsodium-wrappers-sumo` package only ships a CommonJS build,
// but its package.json `exports.import` points to a non-existent ESM file.
// Loading it via createRequire() (CommonJS resolution) sidesteps that broken
// export map and gives us the real module.exports object with `ready` and all
// `crypto_*` functions. All crypto runs on-device.
const require = createRequire(import.meta.url);
const sodium = require('libsodium-wrappers-sumo') as typeof import('libsodium-wrappers-sumo');

/**
 * Build a SodiumProvider backed by the Node `libsodium-wrappers-sumo` package.
 * The returned object exposes `.ready` (a Promise) so core/sodium.ts can
 * `await provider.ready` inside `initSodium()`.
 */
export function createNodeSodiumProvider(): SodiumProvider {
  return sodium as unknown as SodiumProvider;
}
