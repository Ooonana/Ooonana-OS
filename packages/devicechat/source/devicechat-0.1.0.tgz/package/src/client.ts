// Node shim: ChatClient with the host's original constructor signature
// `new ChatClient(url, identity?)` that ui.tsx + run-e2e.mjs already use.
// Internally wires the platform-agnostic core ChatClient to the `ws` Transport
// and the filesystem IdentityStore. Zero changes required in ui.tsx or
// run-e2e.mjs.
import { ChatClient as CoreChatClient } from './core/client.js';
import type { Identity } from './core/types.js';
import { createWsTransport } from './node-adapters/wsTransport.js';
import { createFsIdentityStore } from './node-adapters/fsIdentityStore.js';

export class ChatClient extends CoreChatClient {
  constructor(url: string, identity?: Identity) {
    super({
      url,
      identity,
      createTransport: () => createWsTransport(url),
      identityStore: createFsIdentityStore(),
    });
  }
}

export type { Identity } from './core/types.js';
