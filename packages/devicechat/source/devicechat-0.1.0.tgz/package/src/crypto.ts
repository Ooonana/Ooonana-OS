// Node shim: inject the Node libsodium provider into the platform-agnostic
// core, then re-export the core crypto surface. Callers (store.ts, ui.tsx,
// run-e2e.mjs via dist/client.js) keep importing from './crypto.js' unchanged.
import { setSodium } from './core/sodium.js';
import { createNodeSodiumProvider } from './node-adapters/nodeSodium.js';

setSodium(createNodeSodiumProvider());

export {
  initSodium,
  isReady,
  generateKeyPair,
  deriveSharedKey,
  encrypt,
  decrypt,
  safetyNumber,
  randomToken,
  randomGroupKey,
} from './core/crypto.js';
