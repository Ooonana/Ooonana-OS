import React, { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import { EventEmitter } from 'node:events';
import { render, Box, Text, useInput, useStdout } from 'ink';
import TextInput from 'ink-text-input';
import chalk from 'chalk';
import wrapAnsi from 'wrap-ansi';
import stringWidth from 'string-width';
import { ChatClient } from './client.js';
import { loadIdentity, setName, loadColor, saveColor, type Identity } from './store.js';
import { initSodium } from './crypto.js';
import {
  generateSeed,
  saveSeed,
  loadSeed,
  deleteSeed,
  verifyPersisted,
  totp,
  displaySeed,
  decodeSeed,
} from './otp.js';
import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, basename, extname } from 'node:path';
import { homedir } from 'node:os';

/* ------------------------------------------------------------------ *
 * Theme — warm amber/orange accent scheme (distinct from openvino's
 * cyan). Mirrors openvino's palette structure but swaps the accent.
 * ------------------------------------------------------------------ */
const C = {
  bg: '#111827', // dark slate background
  input: '#e5e7eb', // near-white input text
  amber: '#f59e0b', // self marker + status accent
  amberSoft: '#fb923c', // softer orange for highlights
  green: '#4ade80', // peer messages
  dim: '#9ca3af', // system / notices
  magenta: '#c084fc', // encryption / lock indicator
  border: '#374151', // separator / panel border
};

const cAmber = (s: string) => chalk.hex(C.amber)(s);
const cAmberSoft = (s: string) => chalk.hex(C.amberSoft)(s);
const cGreen = (s: string) => chalk.hex(C.green)(s);
const cDim = (s: string) => chalk.hex(C.dim)(s);
const cMagenta = (s: string) => chalk.hex(C.magenta)(s);

// Distinct per-person color palette. Self stays amber; each peer hashes
// deterministically to one of these. The color key is the peer's IDENTITY PUBKEY
// when known (stable across renames + identical on every receiver), falling
// back to the display name.
const PEER_PALETTE = [
  '#4ade80', // green
  '#60a5fa', // blue
  '#f472b6', // pink
  '#facc15', // yellow
  '#22d3ee', // cyan
  '#fb923c', // orange
  '#a78bfa', // violet
  '#34d399', // emerald
  '#f87171', // red
  '#a3e635', // lime
  '#5eead4', // teal
  '#818cf8', // indigo
  '#fb7185', // rose
  '#fbbf24', // amber-soft
  '#38bdf8', // sky
  '#c084fc', // purple
];
function peerColorFor(key: string): string {
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
  return PEER_PALETTE[h % PEER_PALETTE.length];
}

// /color picker grid layout. PEER_PALETTE has 16 entries, so we render it as
// a real grid with 5 columns (rows of 5,5,5,1) — up/down arrows then move the
// highlight VERTICALLY by stepping ±PEER_PALETTE_COLS instead of sliding it
// sideways along a single wrapped row.
const PEER_PALETTE_COLS = 5;
function paletteRows(items: string[], cols: number): Array<Array<{ hex: string; index: number }>> {
  const rows: Array<Array<{ hex: string; index: number }>> = [];
  for (let i = 0; i < items.length; i += cols) {
    rows.push(items.slice(i, i + cols).map((hex, j) => ({ hex, index: i + j })));
  }
  return rows;
}

// FIX 3: inbound file size budget (DoS / disk-fill guard). Must match the cap
// enforced in core/client.ts.
const MAX_FILE_BYTES = 50 * 1024 * 1024;

/* ------------------------------------------------------------------ *
 * Types
 * ------------------------------------------------------------------ */
type Role = 'self' | 'peer' | 'system' | 'notice';

interface Line {
  id: number;
  role: Role;
  name?: string;
  color?: string; // per-person color (peers); overrides role default in renderLine
  text: string;
  // --- read receipts (Phase 8) ---
  // For self-sent GROUP messages only. msgTs/msgNonce identify the exact
  // outgoing envelope (captured from sendMessage's return) so onReadReceipt
  // can later flip readMarker from '✓' (sent) to '✓✓' (read by all peers).
  // Undefined for peer/system/notice lines and for pairwise self messages.
  msgTs?: number;
  msgNonce?: string;
  readMarker?: '✓' | '✓✓';
}

interface CliOptions {
  name?: string;
  server?: string;
  new?: boolean;
  join?: [string, string, string]; // [peerName, token, pubkey]
}

const SLASH_COMMANDS = [
  '/help',
  '/clear',
  '/clearall',
  '/code',
  '/color',
  '/exit',
  '/file',
  '/join',
  '/name',
  '/new',
  '/otp-delete',
  '/otp-setup',
  '/otp-show',
  '/otp-verify',
  '/quiet',
  '/reset-token',
  '/rules',
  '/safety',
  '/tokens',
  '/whoami',
];

// Commands that REQUIRE an argument. Enter on the slash popup will autofill
// with `/cmd ` (trailing space) and wait for the user to type the arg(s).
// Everything else is zero-arg: Enter autofills AND immediately runs.
// NOTE: /otp-setup is intentionally NOT here — it's zero-arg by default
// (auto-generates a random seed). The `--set <seed>` form is OPTIONAL;
// classifying it as arg-required caused the regression where typing `/otp`
// + Enter highlighted /otp-delete (alphabetically earlier) and immediately
// ran it, silently wiping the user's seed before /otp-setup ever ran.
const SLASH_NEEDS_ARG = new Set(['/color', '/file', '/join', '/name', '/otp-verify', '/quiet']);

// Destructive commands that must NOT be auto-run via slash autocomplete
// (would silently wipe state before the user knows what happened). They
// appear in the popup for discovery, but hitting Enter on the highlighted
// match only FILLS the input — the user must finish typing + Enter (or
// repeat Enter with the explicit token) to actually run them.
// NOTE: /exit and /quit are NOT here — quitting the app is not data-
// destructive (no persisted state is wiped), and the user explicitly wants
// /exit runnable from the popup. The 6A silent-wipe incident was about
// /otp-delete, not /exit.
const SLASH_DESTRUCTIVE = new Set(['/clear', '/clearall', '/reset-token', '/otp-delete']);

// Inline hints shown below the input when an arg-required command has been
// autofilled (input is exactly `/cmd ` with nothing typed after the space).
// Guides the user on what to type next. For /color we render a selectable
// palette instead (see SLASH_COLOR_HINT below).
const SLASH_ARG_HINT: Record<string, string> = {
  '/name': 'enter your new display name, then press Enter',
  '/join': 'enter: <name> <otp|token> <peer-pubkey>   (e.g. alice <6-8char> ed25519:...)',
  '/otp-verify': 'enter the 6-8 char code from the OoonanaOTP app',
  '/quiet': 'enter on or off',
  '/file': 'enter the path to the file to send (quote it if it has spaces)',
};

// Apply the highlighted completion to the input string. Returns the new input
// (with trailing space if the command takes an arg) and the next index.
function applyCompletion(currentInput: string, matches: string[], idx: number): { next: string; index: number } {
  if (matches.length === 0) return { next: currentInput, index: 0 };
  const i = ((idx % matches.length) + matches.length) % matches.length;
  const choice = matches[i];
  const parts = currentInput.split(' ');
  parts[0] = choice;
  const joined = parts.join(' ');
  // Append a trailing space so the user can immediately start typing the arg.
  // For zero-arg commands, the caller is expected to immediately run the
  // command — it should match one of the SLASH_NEEDS_ARG entries to be kept
  // open for typing. Destructive commands are also kept open (the user must
  // explicitly hit Enter a second time after the popup is gone) so they
  // cannot be auto-fired by mistyping a prefix.
  const needsPause = SLASH_NEEDS_ARG.has(choice) || SLASH_DESTRUCTIVE.has(choice);
  const next = needsPause ? (joined + ' ') : joined;
  return { next, index: i + 1 };
}

/* ------------------------------------------------------------------ *
 * Helpers
 * ------------------------------------------------------------------ */
function installInfo(): string {
  return `
Install (on this machine):
  npm i -g .            # builds and links the 'devicechat' bin

Install (other machines):
  npm i -g devicechat   # if published
  # or clone the repo and run:
  npm i -g .            # from the repo root

Usage:
  devicechat host                          # EASIEST: start relay+tunnel, print invite, chat
  devicechat --new                         # host: print token+pubkey bundle, then chat
  devicechat --join <name> <otp|token> <pubkey>  # join a peer (friend picks a name). OTP: 6-8 char alnum, devicechat hardened scheme
  devicechat --name "Alice" --new       # set a device name
  devicechat --server ws://host:8080 --new
  devicechat server on|off|status        # manage the local relay + tunnel only

In-chat commands:
  /help         show this help
  /clear        clear the transcript for everyone in the room (all devices)
  /exit         quit
  /file <path>  send a file to your peer (received files save to ~/Downloads)
  /name <name>  change your display name (peers see the new name on your next message)
  /new          mint a fresh token and print your bundle (host)
  /reset-token  burn ALL current tokens, kick every peer, mint a new token.
                Use when an invite leaked OR you want to be sure no old token
                can ever be reused. Old tokens are added to the relay's revoke
                list (for the rest of that relay process's lifetime).
  /tokens       list your token + all known peer tokens
   /join <name> <otp|token> <pubkey>   connect to a peer (OTP: 6-8 char alnum hardened v3)
  /safety       show the safety number for MITM verification
  /whoami       show your name + public key
  /code         print your invite bundle + OTP seed in one place
                (so you can copy/share without scrolling back)
  /color [#hex|name|clear]
                set your self-line color (or 'clear' to revert to default amber)
                no arg shows the current color + palette. Persists to
                ~/.devicechat/color.json across sessions

OTP second-factor (devicechat hardened OTP v3 — see algorithm.txt):
  /otp-setup                 generate a fresh random 32-byte seed, save it to
                             ~/.devicechat/otp-seed.json (locally stored, obfuscated — NOT encrypted),
                             and print the dc1:: dotted sharing string
  /otp-setup --set <seed>    use a specific seed (dc1:: display form OR plain
                             base32 A-Z2-7, >=10 chars) instead of generating
  /otp-show                  re-print the current dc1:: sharing string
  /otp-verify <code>         check whether a code matches (±3 windows). Accepts
                             6-8 char mixed-case alnum from the hardened scheme
  /otp-delete                delete the stored seed (the phone app keeps its copy)
  `;
}

function parseArgs(argv: string[]): CliOptions & { installInfo?: boolean } {
  const out: CliOptions & { installInfo?: boolean } = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--name') out.name = argv[++i];
    else if (a === '--server') out.server = argv[++i];
    else if (a === '--new') out.new = true;
    else if (a === '--join') {
      const name = argv[++i];
      const token = argv[++i];
      const key = argv[++i];
      if (name && token && key) {
        out.join = [name, token, key];
      } else {
        console.error('--join requires <name> <token> <peerPublicKey>');
        process.exit(2);
      }
    }
    else if (a === '--install-info') out.installInfo = true;
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * ChatApp — the full-screen ink TUI
 * ------------------------------------------------------------------ */
interface ChatAppProps {
  options: CliOptions;
  identity: Identity;
  tty: boolean;
  onQuit: () => void;
}

const ChatApp: React.FC<ChatAppProps> = ({ options, identity, tty, onQuit }) => {
  const { stdout } = useStdout();

  const [lines, setLines] = useState<Line[]>([]);
  const [input, setInput] = useState('');
  const [online, setOnline] = useState(false);
  const [encrypted, setEncrypted] = useState(false); // E2E session established
  const [peerName, setPeerName] = useState<string | null>(null);
  const [safety, setSafety] = useState<string | null>(null);
  // User-chosen color override for OWN chat lines + status bar name. Read from
  // ~/.devicechat/color.json on mount; updated by /color command. Empty string
  // = use the palette hash (peer-line style) or default amber for self.
  const [selfColor, setSelfColor] = useState<string>(() => loadColor());
  const [showHelp, setShowHelp] = useState(false);
  const [scroll, setScroll] = useState(0); // 0 = bottom (newest)
  const [completionIndex, setCompletionIndex] = useState(0);
  // Color picker index for the /color palette popup (only active when input is
  // exactly `/color ` with no arg typed yet). -1 = not active.
  const [colorIndex, setColorIndex] = useState(0);

  const lineId = useRef(0);
  const clientRef = useRef<ChatClient | null>(null);
  const peerTokenRef = useRef<string | null>(null);
  // OTP bootstrap re-announce timer (host mode only). Set iff a persisted TOTP
  // seed exists. setInterval(25s) recomputes the current OTP window and calls
  // client.announceToken so a joiner who only knows the OTP code (6-8 char
  // routing to us across TOTP rotation. Cleared once any peer completes the E2E
  // handshake (after which the peer-shared-key carries traffic and the OTP
  // route is no longer needed), and on unmount/socket close.
  const otpRouteTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  // Bug#4 fix: handshake-completion timer. Started when we go online; cleared
  // when a peer completes the E2E handshake (onPeerConnected). If it fires
  // (30s), we show a "no peer connected yet" notice instead of leaving the
  // user staring at a silent "locking…" status bar forever.
  const handshakeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const peerNameRef = useRef<string | null>(null);
  // --- color propagation ---
  // Map of peer identity pubkey (or name fallback) → the peer's self-chosen
  // display color, learned from handshake/presence/rename envelopes via the
  // onPeerColor callback. A ref (not state) so the boot useEffect callback
  // (captured once with [] deps) can mutate it without re-rendering. addLine
  // reads this to render a peer's messages in THEIR chosen color instead of
  // the palette hash, so every device sees the same color for that person.
  const peerColorMapRef = useRef<Map<string, string>>(new Map());
  const inputRef = useRef('');

  // Keep a ref of input for submit handlers that close over stale state.
  inputRef.current = input;

  // Mirror of `scroll` state into a ref so the boot-useEffect callbacks (captured
  // once with [] deps) can read the CURRENT scroll position without re-binding.
  // Used by onMessage's read-receipt logic: when the user is scrolled UP (not
  // viewing the newest messages), we do NOT auto-markRead incoming messages,
  // because the user hasn't actually seen them yet. 0 = bottom (newest).
  const scrollRef = useRef(0);
  scrollRef.current = scroll;
  // Tracks whether the user was pinned to the bottom (scroll === 0) before the
  // latest line arrived. The auto-scroll effect uses this to decide whether to
  // yank the view to the bottom on a new message: if the user had scrolled up
  // to read history, we leave them where they are (and the markRead gate at
  // line ~476 correctly skips marking unseen messages read).
  const wasAtBottomRef = useRef(true);
  useEffect(() => {
    wasAtBottomRef.current = scrollRef.current === 0;
  }, [scroll]);
  // When the color palette's Enter handler fills the chosen hex and schedules
  // submit() via setTimeout(0), ink ALSO fires TextInput.onSubmit synchronously
  // with the still-unfilled '/color ' input. This ref suppresses that spurious
  // synchronous submit so we don't emit a bogus '/color' usage line.
  const suppressNextSubmitRef = useRef(false);

  // --- Stale-closure fix for `addLine` (Phase 3 / CLI `/color` bug) ---------
  // `addLine` below is a useCallback with deps [selfColor], so its identity
  // changes every time the user runs /color. The boot useEffect (line ~286,
  // deps []) captures addLine ONCE on mount and registers all client.x
  // callbacks (onLog, onMessage, onPeerConnected, onRename, onPresence,
  // onClear, onReady, onFull, onClose, onPeerDropped). Those callbacks kept
  // calling the ORIGINAL addLine forever — so /color flipped selfColor in
  // state but self-stamped chat lines kept rendering in the OLD color, and
  // worse, Ink's re-render mid-keystroke could throw if the closures raced.
  // Fix: addLineRef redirects to the LATEST addLine on every render. Client
  // callbacks capture addLineRef (stable) and call addLineRef.current(...)
  // which always dispatches to the freshest addLine. Standard React pattern.
  const addLineRef = useRef<(role: Role, text: string, name?: string, colorKey?: string, readInfo?: { msgTs?: number; msgNonce?: string; readMarker?: '✓' | '✓✓' }) => void>(() => {});

  // /quiet on|off — when true, the boot-time host-mode banners ('your bundle
  // is OTP-BASED', 'peer should run:', 'current OTP:', 'FRIEND INVITE',
  // 'devicechat --server ... --join ...', 'your bundle — token=...') AND the
  // /code banner block are SUPPRESSED so the user isn't disturbed by the
  // repeating 'current OTP: XXX' line every 25s. Critical: quiet does NOT
  // stop the OTP route setInterval(25s) at line ~443 — that timer only calls
  // announceToken (sends to relay, no addLine). Only the VISIBLE banner chatter
  // is gated. Existing chat lines + peer events + system notices are unaffected.
  const quietRef = useRef(false);
  // Mirror showHelp into a ref so the global useInput key handler (which closes
  // over stale state) can read the current value and dismiss the overlay on any
  // non-modifier keypress — fulfilling the "press any key to dismiss" promise.
  const showHelpRef = useRef(false);
  showHelpRef.current = showHelp;

  // Quit handler: closing the app is NOT logout. wipe() would drop
  // peerSharedKeys/myTokens/peerNames/tokenToPubKey/groupKey, leaving us DEAF
  // on relaunch (incoming envelopes undecryptable, no myTokens to re-announce).
  // The OS reclaims heap secrets on process exit, so wipe() adds no security
  // benefit here and breaks relaunch ergonomics. Just delegate to onQuit.
  const handleQuit = useCallback(() => {
    console.log('\nbye.\n');
    onQuit();
  }, [onQuit]);

  const addLine = useCallback((role: Role, text: string, name?: string, colorKey?: string, readInfo?: { msgTs?: number; msgNonce?: string; readMarker?: '✓' | '✓✓' }) => {
    setLines((prev) => {
      // Compute the per-line color at insertion time so the stored Line is
      // self-contained and survives state resets without recomputation.
      //   - self: user-chosen color override (from /color), or amber default.
      //   - peer: palette hash of colorKey (peer pubkey) or name fallback.
      //   - system/notice: ALWAYS dim, regardless of colorKey. System lines
      //     (peer joined/away/renamed, history cleared, etc.) must never be
      //     colored like peer chat messages — they're metadata, not chat.
      //     (Bug m0076: previously a colorKey on a system/notice call colored
      //     the line like a peer, making "(name) online" look like a chat line.)
      let color: string | undefined;
      if (role === 'system' || role === 'notice') {
        color = C.dim; // always dim, ignore colorKey
      } else if (role === 'self') {
        color = selfColor || C.amber;
      } else if (role === 'peer') {
        // Prefer the peer's self-chosen color (propagated via handshake/presence)
        // over the palette hash, so everyone sees the same color for this person.
        const pubKey = colorKey ?? name ?? '';
        color = peerColorMapRef.current.get(pubKey) ?? peerColorFor(pubKey);
      } else {
        color = C.green;
      }
      const next = [...prev, { id: lineId.current++, role, text, name, color, ...readInfo }];
      // Cap transcript to avoid unbounded memory growth.
      return next.length > 500 ? next.slice(next.length - 500) : next;
    });
  }, [selfColor]);
  // Phase 3 fix: keep addLineRef.current pointing at the FRESHEST addLine so
  // the boot useEffect's client callbacks (captured once with [] deps) always
  // dispatch through to the version that knows the current selfColor.
  // Moved into a useEffect (commit phase) instead of mutating the ref during
  // render — mutating refs during render is a React anti-pattern that can
  // contribute to flicker/re-render churn on every keystroke, because the
  // assignment runs in the render body and can race with Ink's reconciler.
  useEffect(() => {
    addLineRef.current = addLine;
  }, [addLine]);

  // Boot the client once.
  useEffect(() => {
    const serverUrl =
      options.server || process.env.DEVICECHAT_SERVER || 'ws://localhost:8080';
    const client = new ChatClient(serverUrl, identity);
    clientRef.current = client;
    // Push our persisted self-chosen color into the client so handshake/presence
    // envelopes carry it to peers (color propagation).
    client.setSelfColor(selfColor || null);

    client.onLog = (l) => {
      // The client now (as of m2074) handles 'server error: peer not connected'
      // INTERNALLY when the relay tags the error with which target token failed
      // (see client.ts:handleMessage error branch). In that path it calls
      // forgetPeerByToken + onPeerDropped(name), which prints a cleaner
      // '${name} logged out' system line. We only get to see 'server error:
      // peer not connected' here if the relay's error lacked a token field
      // (older relay) or the client couldn't resolve deadName from the token.
      // In those cases fall back to a generic 'peer disconnected' notice and
      // best-effort-clobber the UI's peer display.
      if (l === 'server error: peer not connected') {
        peerNameRef.current = null;
        peerTokenRef.current = null;
        setPeerName(null);
        setEncrypted(false);
        addLineRef.current('notice', 'peer disconnected');
        return;
      }
      addLineRef.current('notice', l);
    };
    client.onPeerDropped = (name, _token) => {
      addLineRef.current('system', `${name} logged out`, name);
      if (name === peerNameRef.current) {
        peerNameRef.current = null;
        peerTokenRef.current = null;
        setPeerName(null);
      }
      // Only flip encrypted off when NO peers remain. In a multi-peer group,
      // dropping a single peer must NOT clear the E2E flag — E2E with the
      // remaining peers is still live. `encrypted` tracks "an E2E session is
      // established with at least one peer", so it stays true while any peer is
      // connected. (We stay online to the relay, so online stays true.)
      if (client.getPeers().length === 0) setEncrypted(false);
      // When the peer list becomes empty, also clear the stale peerName so the
      // status bar does not keep showing a name for a peer that is gone.
      if (client.getPeers().length === 0) {
        peerNameRef.current = null;
        setPeerName(null);
      }
    };
    client.onPeerConnected = (name, token) => {
      peerTokenRef.current = token;
      peerNameRef.current = name;
      setPeerName(name);
      setEncrypted(true);
      // Bug#4 fix: peer completed the handshake — cancel the "no peer yet" timer.
      if (handshakeTimer.current) { clearTimeout(handshakeTimer.current); handshakeTimer.current = null; }
      const s = client.safety();
      setSafety(s);
      addLineRef.current('system', `peer connected: ${name}`);
    };
    client.onMessage = (name, text, senderPubKey, ts, msgNonce) => {
      const colorKey = senderPubKey ?? name;
      addLineRef.current('peer', text, name, colorKey);
      if (name && name !== peerNameRef.current) {
        peerNameRef.current = name;
        setPeerName(name);
      }
      // Read receipts (Phase 8): mark the incoming GROUP message as read
      // instantly — BUT only when the user is actually viewing the newest
      // messages (scroll === 0, i.e. pinned to the bottom). In a terminal CLI
      // every received message is visible on screen in real time, so sending a
      // 'read' envelope back over the group key (so the original sender's UI
      // can flip ✓ → ✓✓) is correct. HOWEVER if the user has scrolled UP to
      // read older history, new messages arrive at the bottom unseen — we must
      // NOT markRead those (the user hasn't actually read them). Skip for
      // pairwise 'msg' (ts/msgNonce undefined — group-only) and our own
      // messages (senderPubKey === our pubkey).
      // (Bug fix: previously markRead fired on EVERY receipt regardless of
      //  scroll position, marking messages read the user never saw.)
      if (ts !== undefined && msgNonce !== undefined && senderPubKey && senderPubKey !== client.myPublicKey && scrollRef.current === 0) {
        try { client.markRead(senderPubKey, ts, msgNonce); } catch { /* best-effort */ }
      }
    };
    client.onPeerColor = (name, color, senderPubKey) => {
      // FIX 1: mirror the core reset convention — a null/empty color deletes
      // the cached color so the peer falls back to the palette hash. FIX 4:
      // only store values that are valid #rrggbb hex; ignore anything else
      // (keep the previous color) so a malformed value can't crash chalk.hex.
      const key = senderPubKey ?? name;
      if (color === null || color === '') {
        peerColorMapRef.current.delete(key);
      } else if (typeof color === 'string' && /^#[0-9a-fA-F]{6}$/.test(color)) {
        peerColorMapRef.current.set(key, color);
      }
    };
    // --- read receipts (Phase 8) ---
    // A peer broadcast a 'read' envelope: they have read up to (ts, msgNonce)
    // of messages originally sent by readOfSender (our pubkey, for self-sent
    // lines). Flip the readMarker on every self-sent line whose (ts, msgNonce)
    // is at or before the reader's cursor from '✓' to '✓✓'. We use the client's
    // isReadByAllPeers() to decide ✓✓ (every known peer has read it) vs ✓
    // (only some peers have). Re-rendering happens via setLines (state update).
    client.onReadReceipt = (_readerName, readOfSender, readUpToTs, _readUpToNonce, _readerPubKey) => {
      const client = clientRef.current;
      if (!client) return;
      // Only self-sent lines (role === 'self') with a captured (msgTs, msgNonce)
      // are candidates. readOfSender must equal OUR pubkey for the receipt to
      // concern our messages.
      if (readOfSender !== client.myPublicKey) return;
      setLines((prev) => {
        let changed = false;
        const next = prev.map((l) => {
          if (l.role !== 'self' || l.msgTs === undefined || l.msgNonce === undefined) return l;
          // Only consider lines at or before the reader's cursor ts.
          if (l.msgTs > readUpToTs) return l;
          if (l.readMarker === '✓✓') return l; // already fully read
          // ✓✓ iff EVERY known peer has read at or past this line.
          const readByAll = client.isReadByAllPeers(client.myPublicKey, l.msgTs, l.msgNonce);
          if (!readByAll) return l; // not all peers have read it yet — keep ✓
          changed = true;
          return { ...l, readMarker: '✓✓' as const };
        });
        return changed ? next : prev;
      });
    };
    client.onRename = (prevName, newName, senderPubKey) => {
      const colorKey = senderPubKey ?? newName;
      addLineRef.current('notice', `${prevName} → ${newName}`, newName, colorKey);
      if (newName && newName !== peerNameRef.current) {
        peerNameRef.current = newName;
        setPeerName(newName);
      }
    };
    client.onPresence = (name, state, senderPubKey) => {
      const colorKey = senderPubKey ?? name;
      addLineRef.current('system', `${name} ${state}`, name, colorKey);
      if (state === 'away' && name === peerNameRef.current) {
        peerNameRef.current = null;
        setPeerName(null);
      } else if (state === 'online' && name && peerNameRef.current === null) {
        peerNameRef.current = name;
        setPeerName(name);
      }
    };
    client.onClear = (senderPubKey) => {
      setLines([]);
      setScroll(0);
      addLineRef.current('notice', 'history cleared');
    };
    client.onFileReceived = (name, fileName, fileSize, fileData, senderPubKey) => {
      // FIX 3: reject oversized inbound files (DoS / disk-fill guard). The
      // sender's declared fileSize is untrusted, so also check the decoded
      // buffer length.
      const buf = Buffer.from(fileData, 'base64');
      if (fileSize > MAX_FILE_BYTES || buf.length > MAX_FILE_BYTES) {
        addLineRef.current('notice', `rejected file from ${name}: ${fileName} exceeds max size (${(Math.max(fileSize, buf.length) / 1024 / 1024).toFixed(1)} MB)`);
        return;
      }
      // Save to ~/Downloads/ (create if missing). Sanitize filename to prevent
      // path traversal — basename only, no path components.
      const safeName = basename(fileName);
      const downloadsDir = join(homedir(), 'Downloads');
      try {
        if (!existsSync(downloadsDir)) {
          mkdirSync(downloadsDir, { recursive: true });
        }
        // Write to a collision-free filename so we never overwrite an existing
        // ~/Downloads file: if the basename already exists, append a short
        // random suffix before the extension.
        let dest = join(downloadsDir, safeName);
        if (existsSync(dest)) {
          const ext = extname(safeName);
          const base = safeName.slice(0, safeName.length - ext.length);
          const suffix = Math.random().toString(36).slice(2, 8);
          dest = join(downloadsDir, `${base}-${suffix}${ext}`);
        }
        writeFileSync(dest, buf);
        const sizeStr = fileSize >= 1024 * 1024
          ? `${(fileSize / 1024 / 1024).toFixed(1)} MB`
          : fileSize >= 1024
            ? `${(fileSize / 1024).toFixed(1)} KB`
            : `${fileSize} B`;
        const colorKey = senderPubKey ?? name;
        addLineRef.current('notice', `received file from ${name}: ${safeName} (${sizeStr}) — saved to ${dest}`, name, colorKey);
      } catch (e) {
        addLineRef.current('notice', `failed to save received file ${safeName}: ${e instanceof Error ? e.message : String(e)}`);
      }
    };
    client.onReady = (token) => {
      setOnline(true);
      if (!quietRef.current) addLineRef.current('system', `ready — announced token ${token}`);
      // Bug#4 fix: start a 30s handshake timer. If no peer completes the E2E
      // handshake in that window, show a helpful notice instead of leaving the
      // status bar on a silent "locking…" forever.
      if (handshakeTimer.current) clearTimeout(handshakeTimer.current);
      handshakeTimer.current = setTimeout(() => {
        handshakeTimer.current = null;
        if (!peerNameRef.current) {
          addLineRef.current('notice', 'no peer connected yet — share your invite (run /code) and have them /join');
        }
      }, 30_000);
    };
    client.onFull = () => addLineRef.current('notice', 'that token is taken by a live peer; try another.');
    client.onClose = () => {
      setOnline(false);
      peerNameRef.current = null;
      peerTokenRef.current = null;
      setPeerName(null);
      setEncrypted(false);
      if (handshakeTimer.current) { clearTimeout(handshakeTimer.current); handshakeTimer.current = null; }
      addLineRef.current('notice', 'connection closed');
    };
    // Bug#2/#6 fix: surface permanent connection failure (relay unreachable
    // after MAX_RETRIES) so the UI transitions off "connecting" instead of
    // sitting silent on offline/locking….
    client.onPermanentFailure = (reason) => {
      setOnline(false);
      setEncrypted(false);
      if (handshakeTimer.current) { clearTimeout(handshakeTimer.current); handshakeTimer.current = null; }
      addLineRef.current('notice', reason);
    };

    let cancelled = false;
    (async () => {
      try {
        if (options.join) {
          // --join <name> <token> <pubkey>: arg[0] is the JOINER's OWN name.
          // Persist it so the handshake envelope carries it (host shows this name).
          const [myName, peerToken, peerKey] = options.join;
          if (myName && identity.name !== myName) {
            identity.name = myName;
            await setName(myName);
            if (cancelled) return;
          }
          await client.connect();
          if (cancelled) return;
          peerTokenRef.current = peerToken;
          client.setPeer(peerToken, peerKey);
          addLineRef.current('system', `joining as ${myName} via token ${peerToken}...`);
        } else {
          // Host mode. If a TOTP seed is persisted, bootstrap our relay route
          // under the CURRENT OTP code so a joiner who only knows the OTP
          // (6-8 char alnum from devicechat hardened v3 — see algorithm.txt)
          // can reach us. Effective timestep is 22.5-37.5s (per-seed wobble);
          // re-announce every 25s to stay ahead of rotation while still
          // reachable by OTP. Stop the timer once any peer completes the E2E
          // handshake (peer-shared-key then carries traffic and the OTP route
          // is no longer needed). No seed → fallback to a random reusable token
          // (backwards-compatible).
          const otpSeed = loadSeed();
          let token: string;
          if (otpSeed) {
            token = await client.connect(totp(otpSeed.raw));
            if (cancelled) return;
            // Re-announce on the rotated OTP every 25s. The just-superseded OTP
            // is intentionally left in myTokens for a grace window so a near-
            // rotation joiner still lands.
            // Keep refreshing the OTP route FOREVER, even after peers connect, so
            // any future peer can join by typing the current OTP code (6-8 char
            // alnum from devicechat hardened v3 — see algorithm.txt) shown on
            // the host's screen. The already-connected peers keep using their
            // peer-shared-key over the same live socket; the OTP route is purely
            // for admission of new peers. Stopping here would strand any later
            // joiner (e.g. the 2nd/3rd friend) with no socket listening on the
            // rotated-away OTP.
            otpRouteTimer.current = setInterval(async () => {
              if (otpRouteTimer.current === null) return; // already cleared
              const c = clientRef.current;
              if (!c) return;
              try {
                await c.announceToken(totp(otpSeed.raw));
              } catch {
                // Socket dropped mid-rotation is fine; the connect() retry
                // path will re-establish. Don't spam the user with notice spam.
              }
            }, 25_000);
          } else {
            token = await client.connect();
            if (cancelled) return;
          }
          // The host is the group-room founder: mint the shared group key now.
          client.founderMint();
          const inviteUrl = process.env.DEVICECHAT_INVITE_URL;
          if (otpSeed && otpRouteTimer.current !== null) {
            // Invite is short-lived. The displayed OTP is the host's current
            // code, which rotates every 22.5-37.5s (per-seed wobble). The
            // joiner must run within ~30-60s.
            if (!quietRef.current) {
              addLineRef.current('system', `your bundle is OTP-BASED — refresh the code before the joiner runs it.`);
              addLineRef.current('system', `peer should run: devicechat --join <name> <otp> ${client.myPublicKey}`);
              addLineRef.current('notice', `current OTP: ${totp(otpSeed.raw)}  (rotates with hardened v3 scheme)`);
              if (inviteUrl) {
                addLineRef.current('system', `devicechat --server ${inviteUrl} --join <name> <otp> ${client.myPublicKey}`);
                addLineRef.current('notice', `(friend installs once:  npm i -g devicechat-0.1.0.tgz)`);
              }
            }
          } else {
            if (inviteUrl) {
              if (!quietRef.current) {
                addLineRef.current('system', `FRIEND INVITE — send this one line to your friend (tell them to replace <name>):`);
                addLineRef.current('system', `devicechat --server ${inviteUrl} --join <name> ${token} ${client.myPublicKey}`);
                addLineRef.current('notice', `(friend installs once:  npm i -g devicechat-0.1.0.tgz)`);
              }
            } else {
              if (!quietRef.current) {
                addLineRef.current('system', `your bundle — token=${token} key=${client.myPublicKey}`);
                addLineRef.current('system', `peer should run: devicechat --join <name> ${token} ${client.myPublicKey}`);
              }
            }
          }
        }
      } catch (e) {
        if (!cancelled) addLineRef.current('notice', `connect failed: ${(e as Error).message}`);
      }
    })();

    return () => {
      cancelled = true;
      if (otpRouteTimer.current !== null) {
        clearInterval(otpRouteTimer.current);
        otpRouteTimer.current = null;
      }
      client.close();
    };
    // CRITICAL: deps MUST NOT include `addLine`. addLine is rebuilt whenever
    // `selfColor` changes (useCallback dep `[selfColor]`), so including it here
    // would re-fire this boot useEffect on EVERY `/color` command — re-booting
    // the WebSocket, re-running announceToken, re-triggering OTP setup. That
    // was a Phase-3 recheck bug: the addLineRef redirect inside the callbacks
    // was correct, but the dep list re-booted the client anyway. The ref
    // pattern means callbacks INSIDE this effect always dispatch to the
    // freshest addLine WITHOUT needing the effect to re-fire. Deps reduced to
    // `[options, identity]` only — the ChatClient boot depends solely on the
    // server URL + the identity (name + keypair), neither of which changes
    // during a chat session. selfColor is NOT a boot dependency.
  }, [options, identity]);

  // ---- command handling -------------------------------------------
  const doNew = useCallback(async () => {
    const client = clientRef.current;
    if (!client) return;
    // Mint a NEW token on the LIVE socket (do NOT close — that would drop
    // existing peers). Multiple tokens = multiple friends can join at once.
    const token = await client.mintToken();
    const inviteUrl = process.env.DEVICECHAT_INVITE_URL;
    if (inviteUrl) {
      addLine('system', `FRIEND INVITE (token #${client.getAllMyTokens().length}) — send this one line (tell them to replace <name>):`);
      addLine('system', `devicechat --server ${inviteUrl} --join <name> ${token} ${client.myPublicKey}`);
      addLine('notice', `(your previous invite lines still work too)`);
    } else {
      addLine('system', `new token minted — token=${token} key=${client.myPublicKey}`);
      addLine('system', `peer should run: devicechat --join <name> ${token} ${client.myPublicKey}`);
    }
  }, [addLine]);

  // /reset-token — burn every currently-minted token, kick all peers, mint
  // a fresh one. Equivalent to "kick everyone + re-host" without quitting the
  // host process. The burned tokens are added to the relay's revoke set so
  // a leaked old invite cannot be re-used on this relay.
  const doResetToken = useCallback(async () => {
    const client = clientRef.current;
    if (!client) return;
    const oldTokens = client.getAllMyTokens();
    addLine('system', `rotating token… (revoking ${oldTokens.length} token${oldTokens.length === 1 ? '' : 's'} + disconnecting every peer)`);
    for (const t of oldTokens) addLine('system', `  revoking: ${t}`);
    const fresh = await client.resetToken();
    if (!fresh) {
      addLine('notice', 'not connected — connect first with /new');
      return;
    }
    const inviteUrl = process.env.DEVICECHAT_INVITE_URL;
    if (inviteUrl) {
      addLine('system', `NEW TOKEN — send this one line (tell them to replace <name>):`);
      addLine('system', `devicechat --server ${inviteUrl} --join <name> ${fresh} ${client.myPublicKey}`);
    } else {
      addLine('system', `new token=${fresh} key=${client.myPublicKey}`);
      addLine('system', `peer should run: devicechat --join <name> ${fresh} ${client.myPublicKey}`);
    }
    addLine('notice', 'all peers were kicked — share the new invite above.');
  }, [addLine]);

  const doJoin = useCallback(
    async (rest: string) => {
      const client = clientRef.current;
      if (!client) return;
      const parts = rest.trim().split(/\s+/);
      if (parts.length < 3) {
        addLine('notice', 'usage: /join <your-name> <otp|token> <pubkey>');
        return;
      }
      const [myName, peerCredential, peerKey] = parts;

      // Autodetect: a credential in the hardened OTP shape (6-8 char alnum)
      // is treated as an OTP bootstrap code. We DO NOT verify it locally — the
      // joiner's role is not to prove anything to itself; routing the code as
      // the peer token is sufficient because a host that announces on that OTP
      // is implicitly proving it holds the same seed. The relay returns
      // 'peer not connected' for a wrong/stale code, which the onLog handler
      // surfaces as 'peer disconnected' — that IS the failure signal. No
      // rate-limit is needed because no host resource is consumed on a wrong
      // guess (only the relay does a routes.get lookup, which is constant-time
      // and harmless). Anything outside the OTP shape is the legacy reusable
      // bearer token from /new (those tokens are >=32 chars so they cannot
      // collide with a 6-8 char OTP credential).
      const peerToken = peerCredential;
      const isOtp = /^[A-Za-z0-9]{6,8}$/.test(peerCredential);
      if (isOtp) {
        addLine('notice', `routing to host via OTP ${peerCredential} — handshake validates the link`);
      }

      // Guard against a double connect: the boot IIFE (or a prior /join) may
      // have already opened the transport / completed the handshake. Only call
      // connect() when we are neither connected nor holding a live transport,
      // otherwise we'd open a second socket on top of the existing one.
      if (!client.isConnected && !client.hasTransport) {
        await client.connect();
      }
      if (myName && identity.name !== myName) {
        identity.name = myName;
        await setName(myName);
      }
      // Tear down any prior host/founder or peer state (e.g. this TUI booted in
      // host mode and minted a dummy group key). Without this, outbound messages
      // would be encrypted with the stale dummy key and dropped by the real host.
      client.resetAsPeer();
      peerTokenRef.current = peerToken;
      client.setPeer(peerToken, peerKey);
      addLine('system', `joining as ${myName} via ${isOtp ? 'OTP' : 'token'}...`);
    },
    [addLine],
  );

  const submit = useCallback(
    (raw: string): boolean => {
      const line = raw.trim();

      // ---- slash-completion autofill on Enter ----
      // When the popup is visible and the typed first token does NOT already
      // equal the highlighted match, Enter autofills instead of submitting.
      // Zero-arg commands ALSO run immediately; arg-required commands just
      // fill `/cmd ` and wait for the user to type the arg(s).
      if (line.startsWith('/')) {
        const matches = SLASH_COMMANDS.filter((c) => c.startsWith(line.split(' ')[0]));
        if (matches.length > 0) {
          const idx = completionIndex % matches.length;
          const highlighted = matches[idx];
          // Only autofill if the typed first token isn't already an exact
          // match (otherwise the user typed the full command and wants it to
          // run normally).
          if (highlighted !== line.split(' ')[0]) {
            const { next, index } = applyCompletion(line, matches, completionIndex);
            // For zero-arg commands, run immediately. `/name` and `/join` and
            // `/otp-verify` need an arg, so just fill. `/otp-setup` is zero-arg
            // by default (auto-generates a seed) so it runs immediately too.
            // Destructive commands also just fill — they require an explicit
            // second Enter so the user can't wipe state via a mistyped prefix.
            if (!SLASH_NEEDS_ARG.has(highlighted) && !SLASH_DESTRUCTIVE.has(highlighted)) {
              setInput('');
              setCompletionIndex(0);
              setShowHelp(false);
              // Recursively submit the now-complete command line, bypassing
              // the popup logic (the typed token == highlighted this time).
              setTimeout(() => submit(next), 0);
              return false;
            }
            // Arg-required or destructive: just fill, don't run. Leave popup
            // open so arrows remain navigable (or the user can backspace out).
            // For destructive commands the trailing space is the cue — the
            // user must press Enter again (with the popup now closed and the
            // exact token already typed) to actually run it.
            setInput(next);
            setCompletionIndex(index);
            return true;
          }
          // else: exact match typed. If it's an arg-required command typed
          // with NO arg (e.g. bare `/otp-verify`), autofill to `/cmd ` + show
          // the inline hint instead of running it bare (which would silently
          // fall through to sendMessage). The user then types the arg + Enter.
          // EXCEPTION: `/quiet` — its bare form IS valid (toggles quiet mode),
          // so let it fall through to the `line === '/quiet'` handler below.
          // Intercepting it here caused an infinite autofill loop where the
          // documented bare toggle could never execute (`/quiet on|off` are
          // unaffected — they contain a space and never matched this branch).
          if (SLASH_NEEDS_ARG.has(highlighted) && !line.includes(' ') && highlighted !== '/quiet') {
            setInput(highlighted + ' ');
            setCompletionIndex(0);
            return true;
          }
          // else: run the normal submit (below).
        }
      }

      if (!line) return false;

      if (line === '/exit' || line === '/quit') {
        handleQuit();
        return false;
      }
      if (line === '/help') {
        // Toggle so a second /help dismisses the overlay.
        setShowHelp((s) => !s);
        return false;
      }
      if (line === '/clear' || line === '/clearall') {
        const client = clientRef.current;
        // Per the user spec, /clear wipes OUR transcript AND broadcasts the
        // 'clear' envelope to every peer so their history clears too. This
        // unifies /clear and /clearall into one destructive command.
        const sent = !!client?.broadcastClear();
        setLines([]);
        setScroll(0);
        addLine('notice', sent ? 'history cleared on all devices' : 'history cleared (no peers connected — broadcast skipped)');
        return false;
      }
      if (line === '/rules') {
        addLine('notice', 'Yellow is the best color. It is 잉 not 밍');
        return false;
      }
      if (line === '/whoami') {
        addLine('system', `name: ${identity.name}`);
        addLine('system', `key:  ${identity.publicKey}`);
        return false;
      }
      if (line === '/code') {
        // Convenience: print invite info + OTP seed (if any) in one place.
        // Useful as a quick "show me what to send my friend" command —
        // especially when the chat has been running for a while and the
        // original boot banner scrolled past.
        const inviteUrl = process.env.DEVICECHAT_INVITE_URL;
        const client = clientRef.current;
        const myKey = identity.publicKey;
        const tokens = client ? client.getAllMyTokens() : [];
        const otp = loadSeed();
        if (otp) {
          if (!quietRef.current) {
            addLine('system', `your bundle is OTP-BASED — refresh the code before the joiner runs it.`);
            const code = totp(otp.raw);
            addLine('system', `current OTP: ${code}  (rotates with hardened v3 scheme)`);
            if (inviteUrl) {
              addLine('system', `devicechat --server ${inviteUrl} --join <name> <otp> ${myKey}`);
            } else {
              addLine('system', `devicechat --join <name> <otp> ${myKey}`);
            }
            addLine('system', `seed: ${displaySeed(otp.raw)}  (give this only to a trusted friend — paste into the OoonanaOTP app)`);
          } else {
            addLine('notice', 'quiet mode is on — /code banners suppressed. /quiet off to show them.');
          }
        } else {
          if (tokens.length === 0) {
            addLine('notice', 'you have no token yet; run /new or restart as host');
            return false;
          }
          if (!quietRef.current) {
            for (const t of tokens) {
              addLine('system', `token: ${t}`);
              if (inviteUrl) {
                addLine('system', `devicechat --server ${inviteUrl} --join <name> ${t} ${myKey}`);
              } else {
                addLine('system', `devicechat --join <name> ${t} ${myKey}`);
              }
            }
          } else {
            addLine('notice', `quiet mode is on — ${tokens.length} token(s) on file. /quiet off to show banners.`);
          }
        }
        return false;
      }
      if (line === '/quiet') {
        // Bare /quiet toggles. Mirrors the APK Phase 4 quiet button (one tap
        // flips on/off). Shows the resulting state + usage hint.
        const next = !quietRef.current;
        quietRef.current = next;
        addLine('system', next ? 'quiet mode: on (banners suppressed) — /quiet off to show' : 'quiet mode: off (banners shown) — /quiet on to hide');
        return false;
      }
      if (line === '/quiet on' || line === '/quiet off') {
        const on = line === '/quiet on';
        quietRef.current = on;
        addLine('system', on ? 'quiet mode: on (banners suppressed)' : 'quiet mode: off (banners shown)');
        return false;
      }
      if (line.startsWith('/color ')) {
        const arg = line.slice('/color '.length).trim();
        if (!arg) {
          addLine('notice', 'usage: /color <#hex|name|clear>');
          return false;
        }
        // Accept: a hex color ('#f59e0b' or 'f59e0b'), a palette name (the
        // keys in PEER_PALETTE below as a hex value), or 'clear' / 'reset' /
        // 'default' to remove the override.
        const lower = arg.toLowerCase();
        if (lower === 'clear' || lower === 'reset' || lower === 'default') {
          saveColor('');
          setSelfColor('');
          const client = clientRef.current;
          if (client) {
            client.setSelfColor(null);
            client.broadcastPresence('online');
          }
          addLine('notice', `color cleared — self lines back to default amber`);
          return false;
        }
        let hex = arg;
        if (!hex.startsWith('#')) {
          // Allow bare hex like 'f59e0b' OR named palette colors.
          if (/^[0-9a-f]{6}$/i.test(hex)) {
            hex = '#' + hex;
          } else {
            // Fall back to palette lookup by hex value (PEER_PALETTE entries
            // are already #hex strings).
            const match = PEER_PALETTE.find((p) => p.toLowerCase() === ('#' + lower));
            if (!match) {
              addLine('notice', `unknown color: ${arg} — try a #rrggbb hex value, 'clear', or pick from the palette`);
              addLine('notice', `palette: ${PEER_PALETTE.join(' · ')}`);
              return false;
            }
            hex = match;
          }
        }
        // Validate hex format roughly so bad input doesn't crash rendering.
        if (!/^#[0-9a-f]{6}$/i.test(hex)) {
          addLine('notice', `invalid color: ${arg} — expected #rrggbb hex`);
          return false;
        }
        saveColor(hex);
        setSelfColor(hex);
        const client = clientRef.current;
        if (client) {
          client.setSelfColor(hex);
          // Push the new color to all peers via a presence broadcast.
          client.broadcastPresence('online');
        }
        addLine('notice', `your color is now ${hex}`);
        return false;
      }
      if (line === '/color') {
        const cur = selfColor || '(default amber)';
        addLine('system', `your color: ${cur}`);
        addLine('system', `usage: /color <#hex|name|clear>`);
        addLine('system', `palette: ${PEER_PALETTE.join(' · ')}`);
        return false;
      }
      if (line.startsWith('/name ')) {
        const newName = line.slice(6).trim();
        if (!newName) {
          addLine('notice', 'usage: /name <new-name>');
          return false;
        }
        const prevName = identity.name;
        if (newName === prevName) {
          addLine('notice', `your name is already ${newName}`);
          return false;
        }
        identity.name = newName;
        void setName(newName);
        // Push the new name into the live ChatClient so client.myName reflects
        // it immediately for self-sent message labels and future handshakes.
        if (clientRef.current) clientRef.current.myName = newName;
        // Broadcast a rename notice to the whole E2E room so peers see
        // "(prevName) → (newName)". Best-effort: no-op if not in a group room.
        clientRef.current?.broadcastRename(prevName, newName);
        addLine('notice', `${prevName} → ${newName}`);
        return false;
      }
      if (line === '/tokens') {
        const client = clientRef.current;
        if (!client) return false;
        const tokens = client.listTokens();
        if (tokens.length === 0) {
          addLine('notice', 'no tokens yet — run /new or /join first');
          return false;
        }
        addLine('system', `known tokens (${tokens.length}):`);
        for (const t of tokens) {
          addLine('system', `  ${t.token}  [${t.role}]${t.name ? '  ' + t.name : ''}`);
        }
        return false;
      }
      if (line === '/safety') {
        const client = clientRef.current;
        const s = client ? client.safety() : null;
        addLine('system', s ? `safety number (verify out-of-band): ${s}` : 'no peer connected yet');
        const gs = client ? client.groupSafety() : null;
        if (gs) addLine('system', `group (vs founder): ${gs}`);
        return false;
      }
      if (line === '/new') {
        // Fire-and-forget, but surface any rejection as a visible notice
        // instead of letting it become an unhandled promise rejection.
        void doNew().catch((e) =>
          addLine('notice', `new failed: ${e instanceof Error ? e.message : String(e)}`),
        );
        return false;
      }
      if (line === '/reset-token') {
        // Fire-and-forget, but surface any rejection as a visible notice
        // instead of letting it become an unhandled promise rejection.
        void doResetToken().catch((e) =>
          addLine('notice', `reset-token failed: ${e instanceof Error ? e.message : String(e)}`),
        );
        return false;
      }
      if (line.startsWith('/join ')) {
        // Fire-and-forget, but surface any rejection as a visible notice
        // instead of letting it become an unhandled promise rejection.
        void doJoin(line.slice(6)).catch((e) =>
          addLine('notice', `join failed: ${e instanceof Error ? e.message : String(e)}`),
        );
        return false;
      }
      // ----- OTP second-factor commands -----
      // Purpose: devicechat host owns a TOTP seed; user copies it into the
      // Ooonana-OTP phone app once (no ongoing token exchange). Phone then
      // shows live 6-8 char alnum codes (devicechat hardened OTP v3 — see
      // algorithm.txt); user types one into /otp-verify to prove they hold
      // the secret. Variable timestep (22.5-37.5s per-seed wobble), variable
      // digits (6/7/8 per counter), per-seed Fisher-Yates alphabet.
      try {
        if (line === '/otp-setup' || line.startsWith('/otp-setup ')) {
          const arg = line.slice('/otp-setup'.length).trim();
          let b32: string;
          let mode: 'generated' | 'manual';
          if (arg.startsWith('--set ')) {
            const provided = arg.slice('--set '.length).trim();
            try {
              saveSeed(decodeSeed(provided));
            } catch {
              addLine('notice', 'invalid seed — must be dc1::<dotted> form or plain base32 (A-Z2-7, >=10 chars)');
              return false;
            }
            const loaded = loadSeed();
            b32 = loaded ? displaySeed(loaded.raw) : provided;
            mode = 'manual';
          } else if (arg === '') {
            const gen = generateSeed();
            b32 = displaySeed(gen.raw);
            saveSeed(gen.raw);
            mode = 'generated';
          } else {
            addLine('notice', 'usage: /otp-setup [--set <seed>]');
            return false;
          }
          addLine('system', `OTP seed ${mode} and saved to ~/.devicechat/otp-seed.json (locally stored, obfuscated — NOT encrypted)`);
          addLine('system', `seed: ${b32}`);
          addLine('notice', 'paste this into the OoonanaOTP app (devicechat hardened OTP v3 — see algorithm.txt)');
          return false;
        }
        if (line === '/otp-show') {
          const entry = loadSeed();
          if (!entry) {
            addLine('notice', 'no OTP seed configured — run /otp-setup first');
            return false;
          }
          addLine('system', `seed: ${displaySeed(entry.raw)}`);
          addLine('system', `created: ${entry.created}  (devicechat hardened OTP v3 — see algorithm.txt)`);
          return false;
        }
        if (line.startsWith('/otp-verify ')) {
          const code = line.slice('/otp-verify '.length).trim();
          if (!/^[A-Za-z0-9]{6,8}$/.test(code)) {
            addLine('notice', 'usage: /otp-verify <code>  (6-8 char alnum from the hardened v3 scheme)');
            return false;
          }
          let ok = false;
          try {
            ok = verifyPersisted(code);
          } catch (e) {
            addLine('notice', String(e instanceof Error ? e.message : e));
            return false;
          }
          addLine('system', ok ? 'OTP Accepted' : 'OTP Rejected (code mismatch or expired)');
          return false;
        }
        if (line === '/otp-delete') {
          deleteSeed();
          addLine('notice', 'OTP seed deleted from ~/.devicechat/otp-seed.json');
          return false;
        }
      } catch (e) {
        addLine('notice', `otp error: ${e instanceof Error ? e.message : String(e)}`);
        return false;
      }

      if (line.startsWith('/file ')) {
        const arg = line.slice('/file '.length).trim();
        // Strip surrounding quotes if present (user may type /file "C:\path with spaces\foo.txt")
        const filePath = (arg.startsWith('"') && arg.endsWith('"') && arg.length >= 2)
          ? arg.slice(1, -1)
          : arg;
        if (!filePath) {
          addLine('notice', 'usage: /file "/path/to/file"');
          return false;
        }
        if (!existsSync(filePath)) {
          addLine('notice', `file not found: ${filePath}`);
          return false;
        }
        const client = clientRef.current;
        const token = client?.getPeerToken() ?? peerTokenRef.current ?? '';
        if (!token && !client?.hasGroupKey() && (client?.getPeers().length ?? 0) === 0) {
          addLine('notice', 'no peer connected — run /new (host) or /join <name> <token> <pubkey> to link with a friend');
          return false;
        }
        try {
          const buf = readFileSync(filePath);
          const fileDataB64 = buf.toString('base64');
          const fileName = basename(filePath);
          const fileSize = buf.length;
          const sizeStr = fileSize >= 1024 * 1024
            ? `${(fileSize / 1024 / 1024).toFixed(1)} MB`
            : fileSize >= 1024
              ? `${(fileSize / 1024).toFixed(1)} KB`
              : `${fileSize} B`;
          // sendFile is async (it chunks + yields to the event loop between
          // chunks so the ws keepalive is serviced). We kick it off and show
          // the self line once it resolves; submit() returns false immediately
          // so the input box clears without waiting for the transfer.
          void (async () => {
            try {
              const ok = await client?.sendFile(token, fileName, fileDataB64, fileSize);
              if (ok) {
                addLine('self', `sent file: ${fileName} (${sizeStr})`, identity.name);
              } else {
                addLine('notice', 'failed to send file (no peers connected or socket not open — peer may not be handshaked yet)');
              }
            } catch (e) {
              addLine('notice', `file send error: ${e instanceof Error ? e.message : String(e)}`);
            }
          })();
        } catch (e) {
          addLine('notice', `file read error: ${e instanceof Error ? e.message : String(e)}`);
        }
        return false;
      }

      // Default: send as a message.
      const client = clientRef.current;
      const token = client?.getPeerToken() ?? peerTokenRef.current;
      if (!token) {
        addLine('notice', 'no peer connected — run /new (host) or /join <name> <token> <pubkey> to link with a friend');
        return false;
      }
      // Read receipts (Phase 8): sendMessage now returns {ts, msgNonce} | null.
      // For GROUP messages these are the real envelope ts + nonce — capture
      // them on the self-sent line so onReadReceipt can later flip ✓ → ✓✓.
      // For pairwise 'msg' the nonce is '' (dummy) — we don't render a marker.
      // null = send failed (no peers/key) — don't add a self line at all.
      const sent = client?.sendMessage(token, line);
      if (!sent) {
        addLine('notice', 'failed to send (no peers connected or no shared key)');
        return false;
      }
      const isGroup = sent.msgNonce !== '';
      addLine('self', line, identity.name, undefined, isGroup
        ? { msgTs: sent.ts, msgNonce: sent.msgNonce, readMarker: '✓' }
        : undefined);
      return false;
    },
    [addLine, doJoin, doNew, doResetToken, identity.name, handleQuit, completionIndex],
  );

  // ---- input key handling (beyond what ink-text-input covers) -----
  // We handle Tab/Up/Down/PageUp/PageDown here; ink-text-input manages typing.
  useInput(
    (inputStr, key) => {
      // Ctrl+C quits.
      if (inputStr === 'c' && key.ctrl) {
        handleQuit();
        return;
      }

      // Help overlay: any non-modifier keypress dismisses it (fulfills the
      // "press any key to dismiss" promise). Ctrl combos and Tab still pass
      // through to their own handlers below.
      if (showHelpRef.current && !key.ctrl && !key.tab && !key.return) {
        setShowHelp(false);
        // Don't return — let the key also do its normal thing (e.g. an arrow
        // also scrolls, a printable char also goes to TextInput). The overlay
        // just goes away.
      }

      // Color palette picker: active when input is exactly `/color ` (autofilled,
      // no arg typed yet). Arrows navigate the palette, Enter selects + runs.
      // This takes priority over the generic slash popup (which would otherwise
      // show a single `/color` match).
      if (inputRef.current === '/color ' || inputRef.current === '/color') {
        // Palette is rendered as a grid of PEER_PALETTE_COLS columns:
        // LEFT/RIGHT step ±1 (horizontal), UP/DOWN step ±COLS (vertical).
        // Indices are clamped to [0, PEER_PALETTE.length - 1].
        if (key.upArrow) {
          setColorIndex((i) => Math.max(0, i - PEER_PALETTE_COLS));
          return;
        }
        if (key.downArrow) {
          setColorIndex((i) => Math.min(PEER_PALETTE.length - 1, i + PEER_PALETTE_COLS));
          return;
        }
        if (key.leftArrow) {
          setColorIndex((i) => Math.max(0, i - 1));
          return;
        }
        if (key.rightArrow) {
          setColorIndex((i) => Math.min(PEER_PALETTE.length - 1, i + 1));
          return;
        }
        // Enter on the palette: TextInput.onSubmit fires too, but it would
        // submit `/color ` (empty arg) → usage notice. Intercept here by
        // filling the chosen hex + letting submit run via a microtask.
        if (key.return) {
          const hex = PEER_PALETTE[colorIndex % PEER_PALETTE.length];
          const filled = '/color ' + hex;
          setInput(filled);
          setCompletionIndex(0);
          setShowHelp(false);
          // Suppress the synchronous TextInput.onSubmit that ink fires for the
          // still-unfilled '/color ' input; the real submit runs via setTimeout.
          suppressNextSubmitRef.current = true;
          setTimeout(() => { submit(filled); setInput(''); }, 0);
          return;
        }
      }

      // Autocomplete navigation when input starts with '/'.
      const isSlash = inputRef.current.startsWith('/');
      if (key.tab && isSlash) {
        const matches = SLASH_COMMANDS.filter((c) =>
          c.startsWith(inputRef.current.split(' ')[0]),
        );
        if (matches.length) {
          const { next, index } = applyCompletion(inputRef.current, matches, completionIndex);
          setInput(next);
          setCompletionIndex(index);
        }
        return;
      }

      // When the slash completion popup is visible, arrows navigate the list
      // rather than scrolling the transcript (default ↑/↓ behavior restored
      // once the popup is hidden by the user typing a non-/ prefix or clearing
      // the input).
      if (isSlash) {
        const matches = SLASH_COMMANDS.filter((c) =>
          c.startsWith(inputRef.current.split(' ')[0]),
        );
        if (matches.length > 0) {
          if (key.upArrow) {
            setCompletionIndex((i) => Math.max(0, i - 1));
            return;
          }
          if (key.downArrow) {
            setCompletionIndex((i) => i + 1);
            return;
          }
          // Enter while popup visible: TextInput's onSubmit will also fire;
          // we let submit() see the popup state and autofill+run there. (We
          // cannot early-terminate the Enter key here because ink-text-input
          // owns the Enter-to-submit binding.)
        }
      }

      // Scrollback over the transcript. scroll=0 = bottom (newest); increasing
      // scroll scrolls UP. Clamp so we never scroll past the top of history.
      const maxScroll = Math.max(0, totalRows - transcriptHeight);
      if (key.pageUp) {
        setScroll((s) => Math.min(s + 1, maxScroll));
        return;
      }
      if (key.pageDown) {
        setScroll((s) => Math.max(0, s - 1));
        return;
      }
      if (key.upArrow) {
        setScroll((s) => Math.min(s + 1, maxScroll));
        return;
      }
      if (key.downArrow) {
        setScroll((s) => Math.max(0, s - 1));
        return;
      }
    },
    { isActive: tty },
  );

  // Reset scroll to bottom whenever a new line arrives — but only if the user
  // was already at the bottom. If they scrolled up to read history, leave them
  // there (the markRead gate skips marking unseen messages read).
  useEffect(() => {
    if (wasAtBottomRef.current) setScroll(0);
  }, [lines.length]);

  // ---- layout math -------------------------------------------------
  const cols = stdout?.columns ?? 80;
  const rows = stdout?.rows ?? 24;
  const panelWidth = cols > 90 ? 38 : 0; // right panel only on wide terminals
  const transcriptWidth = Math.max(20, cols - panelWidth - 1);

  // Reserve: 1 status bar + 1 separator + 1 input + 1 privacy note = 4 lines.
  const transcriptHeight = Math.max(3, rows - 4);

  // Plain-text marker strings (no chalk) — width-measured for wrap math.
  // Colors applied via <Text color> props below.
  const markerText = (role: Role, name?: string): string => {
    if (role === 'peer') return `> ${name ?? 'peer'}: `;
    if (role === 'self') return '> ';
    // system + notice: NO prefix marker. System lines (peer online/offline,
    // rename, history cleared, etc.) render as bare dim text — NOT as chat
    // lines with a `>` prefix. (Bug m0076 follow-up: previously system lines
    // got a `>` and notice lines got a `·`, making them look like chat.)
    return '';
  };
  const bodyColor = (role: Role, color?: string): string | undefined => {
    if (role === 'self') return color ?? C.amberSoft;
    if (role === 'peer') return color ?? C.green;
    // system + notice: ALWAYS dim, never colored like a peer (Bug m0076).
    // The stored `color` is ignored for these roles so a colorKey passed to
    // addLine('system'|'notice', ..., colorKey) can't leak into the render.
    return C.dim;
  };
  const markerColor = (role: Role, color?: string): string | undefined => {
    if (role === 'self') return color ?? C.amber;
    if (role === 'peer') return color ?? C.green;
    // system + notice: ALWAYS dim (Bug m0076).
    return C.dim;
  };

  // Visible window — measured in RENDERED ROWS (not logical lines) so that
  // wrapped multi-row messages don't desync the window when scrolling. We
  // pre-compute every line's wrapped rows, flatten to a single row list, then
  // take the last `transcriptHeight` rows offset by `scroll` (in rows).
  const visibleRows = useMemo(() => {
    const allRows: Array<{ key: string; marker: string; body: string; mColor?: string; bColor?: string; col: number }> = [];
    for (const l of lines) {
      const mt = markerText(l.role, l.name);
      const markerW = stringWidth(mt);
      // Read-receipt marker (✓ / ✓✓) for self-sent group messages. Appended
      // to the END of the last wrapped row so it appears at the message tail.
      const readTail = l.readMarker ?? '';
      const bodyW = Math.max(10, transcriptWidth - markerW);
      const wrapped = wrapAnsi(l.text, bodyW, { hard: true, trim: false });
      const r = wrapped.split('\n');
      r.forEach((row, i) => {
        const isLast = i === r.length - 1;
        allRows.push({
          key: `${l.id}-${i}`,
          marker: i === 0 ? mt : ' '.repeat(markerW),
          body: isLast && readTail ? `${row} ${readTail}` : row,
          mColor: markerColor(l.role, l.color),
          bColor: bodyColor(l.role, l.color),
          col: i,
        });
      });
    }
    const start = Math.max(0, allRows.length - transcriptHeight - scroll);
    const end = Math.max(0, allRows.length - scroll);
    return allRows.slice(start, end);
  }, [lines, transcriptHeight, scroll, transcriptWidth]);

  // Total number of RENDERED rows (un-windowed). Used to clamp scroll so it
  // can't scroll past the top of the available history.
  const totalRows = useMemo(() => {
    let n = 0;
    for (const l of lines) {
      const mt = markerText(l.role, l.name);
      const markerW = stringWidth(mt);
      const bodyW = Math.max(10, transcriptWidth - markerW);
      const wrapped = wrapAnsi(l.text, bodyW, { hard: true, trim: false });
      n += wrapped.split('\n').length;
    }
    return n;
  }, [lines, transcriptWidth]);

  const renderRow = (r: { key: string; marker: string; body: string; mColor?: string; bColor?: string }) => (
    <Text key={r.key}>
      <Text color={r.mColor}>{r.marker}</Text>
      <Text color={r.bColor}>{r.body}</Text>
    </Text>
  );

  // Build a peer list snapshot from the live ChatClient so the status bar can
  // show ALL connected peers at once (not just the last handshaked one). We
  // poll on every render, which is cheap (the Map is small + sorted). We sync
  // the React state only when the set of names DIFFERS from the last snapshot
  // so we don't churn renders for re-orderings.
  const allPeers = clientRef.current ? clientRef.current.getPeers() : [];
  const peerListStr = allPeers.length === 0
    ? 'none'
    : allPeers.map((p) => peerColorFor(p.pub ?? p.name) && chalk.hex(peerColorFor(p.pub ?? p.name))(p.name)).join(chalk.hex(C.dim)(' · '));

  const statusFragments = [
    cAmber('devicechat'),
    `peer: ${allPeers.length}  ${peerListStr}`,
    encrypted ? cMagenta('🔒 encrypted') : cDim('locking…'),
    online ? cGreen('online') : cDim('offline'),
  ];

  // Slash popup: only show while the user is typing the command PREFIX (no
  // space yet). Once a space is present (arg being typed) we hide the popup
  // and show the inline arg hint / color picker instead — avoids a redundant
  // single-item popup of the already-typed command.
  const completionMatches = input.startsWith('/') && !input.includes(' ')
    ? SLASH_COMMANDS.filter((c) => c.startsWith(input.split(' ')[0]))
    : [];

  return (
    <Box flexDirection="column" width={cols} height={rows}>
      {/* Privacy note */}
      <Text color={C.dim}>
        End-to-end encrypted. Server only relays ciphertext; your messages are
        encrypted/decrypted on this device.
      </Text>

      {/* Main area: transcript + optional right panel */}
      <Box flexDirection="row" flexGrow={1}>
        <Box
          flexDirection="column"
          width={transcriptWidth}
          flexGrow={1}
        >
          {visibleRows.map(renderRow)}
          {scroll > 0 && (
            <Text color={C.dim}>… {scroll} row(s) above — scroll with ↑/PgUp …</Text>
          )}
        </Box>

        {panelWidth > 0 && (
          <Box
            flexDirection="column"
            width={panelWidth}
            borderStyle="single"
            borderColor={C.border}
            paddingX={1}
          >
            <Text color={C.amber} bold>
              connection
            </Text>
            <Text color={C.dim}>name</Text>
            <Text>{identity.name}</Text>
            <Text color={C.dim}>peer</Text>
            {allPeers.length === 0 ? (
              <Text>{cDim('—')}</Text>
            ) : (
              <Box flexDirection="column">
                {allPeers.map((p) => (
                  <Text key={p.token} color={peerColorFor(p.pub ?? p.name)}>
                    {p.name}
                  </Text>
                ))}
              </Box>
            )}
            <Text color={C.dim}>state</Text>
            <Text>
              {online ? cGreen('online') : cDim('offline')}
              {'  '}
              {encrypted ? cMagenta('e2e') : cDim('handshaking')}
            </Text>
            <Text color={C.dim}>safety</Text>
            <Text wrap="wrap">
              {safety ? cMagenta(safety) : cDim('not established')}
            </Text>
          </Box>
        )}
      </Box>

      {/* Separator */}
      <Text color={C.border}>{'-'.repeat(cols)}</Text>

      {/* Input */}
      <Box>
        <Text color={C.amber}>{'> '}</Text>
        {tty ? (
          <TextInput
            value={input}
            onChange={setInput}
            onSubmit={(v) => {
              // The color palette's Enter handler fills the hex and schedules
              // the real submit via setTimeout(0); ink also fires this onSubmit
              // synchronously with the un-filled '/color ' input. Skip that
              // spurious submit and reset the guard so the next real submit works.
              if (suppressNextSubmitRef.current) {
                suppressNextSubmitRef.current = false;
                return;
              }
              // /help toggles the overlay on inside submit(); don't clobber it
              // by unconditionally clearing showHelp afterwards. Any other
              // command (or a plain message) should dismiss the overlay.
              // submit() returns true if it autofilled (e.g. /otp-verify →
              // "/otp-verify " + hint) — in that case KEEP the input so the
              // user can type the arg. Only clear when submit ran/did nothing.
              const isHelp = v.trim() === '/help';
              const autofilled = submit(v);
              if (!autofilled) setInput('');
              setCompletionIndex(0);
              if (!isHelp) setShowHelp(false);
            }}
            placeholder="type a message, or /help"
            showCursor
          />
        ) : (
          <Text color={C.dim}>[no TTY — input disabled]</Text>
        )}
      </Box>

      {/* Slash autocomplete popup */}
      {completionMatches.length > 0 && (
        <Box flexDirection="column" borderStyle="round" borderColor={C.amber} paddingX={1}>
          {completionMatches.map((c, i) => (
            <Text key={c} color={i === completionIndex % completionMatches.length ? C.amberSoft : C.dim}>
              {i === completionIndex % completionMatches.length ? '› ' : '  '}
              {c}
            </Text>
          ))}
        </Box>
      )}

      {/* Inline arg hint + color palette picker.
          Shown when an arg-required command has been autofilled (input is
          exactly `/cmd ` with nothing typed after the space). For /color we
          render a navigable palette; for others a one-line hint. */}
      {(() => {
        const m = input.match(/^(\/\S+) $/);
        const cmd = m ? m[1] : '';
        if (cmd === '/color') {
          return (
            <Box flexDirection="column" borderStyle="round" borderColor={C.amber} paddingX={1}>
              <Text color={C.amber} bold>pick a color</Text>
              <Text color={C.dim}>arrow keys to move, Enter to select, or type your own #rrggbb</Text>
              {/* Real grid: PEER_PALETTE_COLS columns per row so ↑/↓ navigate
                  vertically (matching the ±PEER_PALETTE_COLS key steps). */}
              <Box flexDirection="column">
                {paletteRows(PEER_PALETTE, PEER_PALETTE_COLS).map((row, r) => (
                  <Box key={r} flexDirection="row">
                    {row.map(({ hex, index }) => (
                      <Box key={hex} marginRight={1}>
                        <Text color={index === colorIndex % PEER_PALETTE.length ? C.amber : C.dim}>
                          {index === colorIndex % PEER_PALETTE.length ? '>' : ' '}
                        </Text>
                        <Text color={hex}>{' # '}{hex}</Text>
                      </Box>
                    ))}
                  </Box>
                ))}
              </Box>
            </Box>
          );
        }
        if (cmd && SLASH_ARG_HINT[cmd]) {
          return (
            <Box flexDirection="column" borderStyle="round" borderColor={C.amber} paddingX={1}>
              <Text color={C.amberSoft}>{SLASH_ARG_HINT[cmd]}</Text>
            </Box>
          );
        }
        return null;
      })()}

      {/* Help overlay */}
      {showHelp && (
        <Box flexDirection="column" borderStyle="round" borderColor={C.magenta} paddingX={1}>
          <Text color={C.magenta} bold>commands</Text>
          <Text color={C.dim}>/help · /clear · /code · /color · /quiet on|off · /rules · /exit · /name &lt;new&gt; · /new · /join &lt;name&gt; &lt;otp|token&gt; &lt;pubkey&gt; · /tokens · /safety · /whoami · /otp-setup · /otp-show · /otp-verify · /otp-delete · /reset-token · /quiet on|off</Text>
          <Text color={C.dim}>press any key or /help to dismiss</Text>
        </Box>
      )}

      {/* Status bar */}
      <Text color={C.dim}>
        {statusFragments.join('  |  ')}
      </Text>
    </Box>
  );
};

/* ------------------------------------------------------------------ *
 * util: naive word-wrap for a colored string (splits on spaces, keeps
 * ANSI intact because we operate on already-colored substrings).
 * ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ *
 * Entry
 * ------------------------------------------------------------------ */
async function main(): Promise<void> {
  const options = parseArgs(process.argv.slice(2));
  if (options.installInfo) {
    process.stdout.write(installInfo());
    return;
  }

  const serverUrl =
    options.server || process.env.DEVICECHAT_SERVER || 'ws://localhost:8080';

  // libsodium must be ready before any key generation.
  await initSodium();

  let identity = await loadIdentity(options.name);
  if (options.name) {
    await setName(options.name);
    identity = await loadIdentity();
  }

  // Headless-friendly: ink's App component throws if it can't enable raw mode
  // on the real process.stdin (e.g. piped CI runs). When stdin isn't a TTY we
  // hand ink a no-op stream so the layout still renders without crashing.
  const tty = Boolean(process.stdin.isTTY);
  const stdin: NodeJS.ReadStream = tty
    ? process.stdin
    : (new ReadableStreamShim() as unknown as NodeJS.ReadStream);

  const { waitUntilExit } = render(
    <ChatApp
      options={options}
      identity={identity}
      tty={tty}
      onQuit={() => {
        process.exit(0);
      }}
    />,
    { exitOnCtrlC: false, stdin, stdout: process.stdout },
  );

  await waitUntilExit();
}

/**
 * Minimal readable-stream stand-in used only when there is no real TTY. It
 * reports `isTTY` so ink believes raw mode is available, but its setRawMode is
 * a no-op and it never emits data — keeping the app crash-free headlessly.
 */
class ReadableStreamShim extends EventEmitter {
  isTTY = true;
  setRawMode(): void {}
  setEncoding(): void {}
  ref(): void {}
  unref(): void {}
  resume(): void {}
  pause(): void {}
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
