#!/usr/bin/env node
import { spawn, execFileSync, execSync } from 'node:child_process';
import type { Socket } from 'node:net';
import type { ChildProcessByStdio } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, unlinkSync, mkdirSync, appendFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { get } from 'node:http';
import { get as getHttps } from 'node:https';

const DEFAULT_PORT = Number(process.env.PORT) || 8080;

function home(): string {
  return process.env.DEVICECHAT_HOME || join(homedir(), '.devicechat');
}
function ensureHome(): void {
  const h = home();
  if (!existsSync(h)) mkdirSync(h, { recursive: true });
}
function pidFile(name: string): string {
  return join(home(), name);
}
function relayLog(): string { return join(home(), 'relay.log'); }
function tunnelLog(): string { return join(home(), 'tunnel.log'); }
function tunnelUrlFile(): string { return join(home(), 'tunnel.url'); }

function pidAlive(pid: number): boolean {
  try { process.kill(pid, 0); return true; } catch { return false; }
}

function readPid(name: string): number | null {
  const f = pidFile(name);
  if (!existsSync(f)) return null;
  try {
    const pid = parseInt(readFileSync(f, 'utf8').trim(), 10);
    return Number.isFinite(pid) ? pid : null;
  } catch { return null; }
}

function urlForWs(port: number) { return `ws://localhost:${port}` }
function urlForWss(url: string) { return url.replace(/^http/, 'ws'); }

async function relayUp(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const req = get({ host: '127.0.0.1', port, path: '/', timeout: 800 }, (res) => {
      res.resume(); resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}

async function waitForRelay(port: number, tries: number, delayMs: number): Promise<boolean> {
  for (let i = 0; i < tries; i++) {
    if (await relayUp(port)) return true;
    await new Promise((r) => setTimeout(r, delayMs));
  }
  return false;
}

/**
 * Probe whether a trycloudflare URL is actually live from OUTSIDE. The local
 * cloudflared process can be alive but its edge-side tunnel registration can
 * have been garbage-collected by Cloudflare (e.g. after a network blip), which
 * leaves us with a process that reports "running" but a hostname that does not
 * resolve. Always probe DNS + HTTP reachability before trusting a stale URL.
 */
async function tunnelReachable(url: string): Promise<boolean> {
  let hostname = url;
  try { hostname = new URL(url).hostname; } catch { return false; }
  return new Promise((resolve) => {
    const req = getHttps({ hostname, port: 443, path: '/', timeout: 4000, method: 'GET' }, (res) => {
      // cloudflare quick-tunnel serves a 502/1034 when the backend is down,
      // but ANY HTTP response from cloudflare means the tunnel itself
      // resolves + is wired. 200/1034/502 all count as "live".
      res.resume();
      resolve(true);
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}

/**
 * Kill a PID reliably across platforms. On Windows, the default SIGTERM that
 * Node sends via process.kill() is treated as a no-op by many console apps
 * (cloudflared.exe especially — it ignores the message and stays running).
 * Use taskkill /F /T to forcibly kill the process tree in that case.
 */
function killPid(pid: number, force = false): boolean {
  if (!Number.isSafeInteger(pid) || pid <= 0) return false;
  if (process.platform === 'win32') {
    // For the relay, send a graceful taskkill first (no /F) so the relay's
    // SIGBREAK handler can flush close(1001) frames to connected peers.
    // Only escalate to /F if the graceful signal fails (caller passes force=true,
    // or the graceful attempt already failed and we retry with force).
    if (!force) {
      try { execFileSync('taskkill', ['/T', '/PID', String(pid)], { stdio: 'ignore', shell: false }); return true; }
      catch { return false; }
    }
    try { execFileSync('taskkill', ['/F', '/T', '/PID', String(pid)], { stdio: 'ignore', shell: false }); return true; }
    catch { return false; }
  }
  try { process.kill(pid, force ? 'SIGKILL' : 'SIGTERM'); return true; } catch { return false; }
}

function findCloudflared(): string | null {
  const paths = [
    'cloudflared',
    'cloudflared.exe',
    'C:\\Program Files (x86)\\cloudflared\\cloudflared.exe',
    'C:\\Program Files\\cloudflared\\cloudflared.exe',
    '/usr/local/bin/cloudflared',
    '/usr/bin/cloudflared',
    '/snap/bin/cloudflared',
    '/data/data/com.termux/files/usr/bin/cloudflared', // Termux default prefix
  ];
  for (const p of paths) {
    try {
      execFileSync(p, ['--version'], { stdio: 'ignore' });
      return p;
    } catch { /* keep trying */ }
  }
  return null;
}

export async function serverStart(port = DEFAULT_PORT): Promise<void> {
  ensureHome();

  // 1. Relay
  if (await relayUp(port)) {
    console.log(`relay already running on ${urlForWs(port)}`);
  } else {
    const hereDir = dirname(fileURLToPath(import.meta.url));
    let relayChild: ReturnType<typeof spawn>;
    try {
      relayChild = spawn(process.execPath, [join(hereDir, 'relay.js')], {
        env: { ...process.env, PORT: String(port) },
        detached: true,
        stdio: ['ignore', 'ignore', 'ignore'],
        shell: false,
        windowsHide: true,
      });
    } catch (e) {
      throw new Error(
        `failed to spawn relay process (${process.execPath}): ${(e as Error).message}`,
      );
    }
    relayChild.unref();
    writeFileSync(pidFile('relay.pid'), String(relayChild.pid));
    console.log(`relay starting on ${urlForWs(port)} (pid ${relayChild.pid})`);
    const up = await waitForRelay(port, 20, 250);
    if (!up) { console.error('relay did not come up (check ~/.devicechat/relay.log).'); return; }
    console.log('relay: online');
  }

  // 2. Cloudflare tunnel
  const existingTpid = readPid('tunnel.pid');
  const existingUrl = readTunnelUrl();
  if (existingTpid && pidAlive(existingTpid) && existingUrl && await tunnelReachable(existingUrl)) {
    console.log('tunnel already running.');
    console.log(`public: ${existingUrl}  (ws: ${urlForWss(existingUrl)})`);
    return;
  }
  // Tunnel process is alive-but-dead (stale URL) OR no process at all. In
  // either case, force-kill the zombie so we don't leak a process while we
  // spawn a replacement. Then clear the stale url file so we don't show it
  // again until we capture a fresh one.
  if (existingTpid && pidAlive(existingTpid)) {
    console.log(`tunnel pid ${existingTpid} alive but URL unreachable — recycling…`);
    killPid(existingTpid, true);
  }
  try { unlinkSync(pidFile('tunnel.pid')); } catch {}
  try { unlinkSync(tunnelUrlFile()); } catch {}

  const bin = findCloudflared();
  if (!bin) {
    console.error('cloudflared not found. Install it:');
    if (process.platform === 'win32') {
      console.error('  winget install --id Cloudflare.cloudflared');
    } else if (process.platform === 'darwin') {
      console.error('  brew install cloudflared');
    } else {
      // Linux / Termux / WSL / proot-distro
      console.error('  Debian/Ubuntu: sudo apt install cloudflared');
      console.error('  Termux:        pkg install cloudflared');
      console.error('  or download from https://github.com/cloudflare/cloudflared/releases/latest');
    }
    console.error('Relay is up locally; for worldwide chat, start a tunnel manually or install cloudflared.');
    return;
  }

  console.log('starting cloudflare tunnel (grabbing public URL)...');
  // On Linux/Termux, force http2 — the default QUIC protocol often fails on
  // Android (Cloudflare's golang toolchain doesn't fully support Android,
  // see Termux issue #19552). http2 over TCP 443 works reliably and produces
  // the same trycloudflare.com URL on stdout. Windows+macOS use QUIC by default
  // and it works there, so we only override on Linux.
  //
  // Also force `--edge-ip-version 4`: on Android (esp. Samsung OneUI 8.x /
  // Android 16) cloudflared's default tries IPv6 edges first, which often
  // fail; this nudges it onto IPv4. See README-TERMUX.md §1 root cause 2.
  const tunnelArgs = ['tunnel', '--no-autoupdate', '--url', `http://localhost:${port}`];
  if (process.platform !== 'win32' && process.platform !== 'darwin') {
    tunnelArgs.push('--protocol', 'http2');
    tunnelArgs.push('--edge-ip-version', '4');
    // Belt-and-braces against Cloudflare error 1033 on Android: --edge with a
    // pre-resolved Cloudflare edge IP:port skips the SRV lookup entirely,
    // sidestepping "lookup region1.argotunnel.com on [::1]:53: connection refused"
    // (cloudflared has no resolver of its own on Android). IP below is one of
    // Cloudflare's documented edge endpoints; port 7844 = http2 edge.
    // If the IP is unreachable for some network reason, cloudflared falls back
    // to the original SRV+DNS path automatically.
    tunnelArgs.push('--edge', '198.41.200.233:7844');
  }
  // Belt-and-braces: if we're on Termux and $PREFIX/etc/resolv.conf is
  // missing or empty, cloudflared's SRV lookup will hit [::1]:53 (which does
  // not exist on Android) and produce Cloudflare error 1033 even with http2.
  // Auto-create one pointing at public DNS resolvers. (Idempotent: only writes
  // if the file is absent OR is empty, never overwrites a user's real config.)
  try {
    const prefix = process.env.PREFIX;
    if (prefix && process.platform !== 'win32' && process.platform !== 'darwin') {
      const resolvConf = `${prefix}/etc/resolv.conf`;
      let existing = '';
      try { existing = readFileSync(resolvConf, 'utf8'); } catch {}
      if (!existing.trim() || !/nameserver\s+\d+\.\d+\.\d+\.\d+/i.test(existing)) {
        writeFileSync(resolvConf, 'nameserver 1.1.1.1\nnameserver 8.8.8.8\n', { mode: 0o644 });
        console.log(`wrote ${resolvConf} (cloudflared needs a real DNS resolver on Android).`);
      }
    }
  } catch { /* best-effort; user can create it manually per README */ }
  const tun = spawn(bin, tunnelArgs, {
    detached: true,
    stdio: ['ignore', 'pipe', 'pipe'],
    shell: false,
    windowsHide: true,
  }) as unknown as ChildProcessByStdio<null, Socket, Socket>;

  // Log tunnel output to a file so we can recover the URL later if needed.
  const URL_RE = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/i;
  let urlBuf = '';
  // Register the URL parser FIRST so no early chunk is missed by the logger
  // getting the data event first on some/std ordering quirks. Both handlers
  // receive the same chunks because Node fans out `data` to every listener.
  const onChunkCapture = (s: Buffer | string) => {
    urlBuf += String(s);
  };
  const logStream = (s: Buffer | string) => { try { appendFileSync(tunnelLog(), s); } catch {} };
  tun.stdout.on('data', onChunkCapture);
  tun.stderr.on('data', onChunkCapture);
  tun.stdout.on('data', logStream);
  tun.stderr.on('data', logStream);

  const found = await new Promise<string | null>((resolve) => {
    // Poll urlBuf for the URL regex every ~50ms as chunks arrive, since the
    // match might span two chunks. Resolve as soon as we have it.
    const timer = setInterval(() => {
      const m = urlBuf.match(URL_RE);
      if (m) { clearInterval(timer); clearTimeout(to); resolve(m[0]); }
    }, 50);
    const to = setTimeout(() => { clearInterval(timer); resolve(null); }, 12000);
    tun.on('close', () => { clearInterval(timer); clearTimeout(to); resolve(null); });
    void to;
  });

  if (!found) {
    console.error('could not capture tunnel URL (timed out). Check ~/.devicechat/tunnel.log.');
    try { killPid(tun.pid!, true); } catch {}
    return;
  }

  // Detach the tunnel now that we have the URL.
  writeFileSync(tunnelUrlFile(), found);
  writeFileSync(pidFile('tunnel.pid'), String(tun.pid));
  try { tun.stdout.destroy(); tun.stderr.destroy(); } catch {}
  tun.unref();
  console.log(`tunnel: ready`);
  console.log(`public: ${found}`);
  console.log(`friend connects with: devicechat --server ${urlForWss(found)} --join <token> <key>`);
}

export async function serverStop(): Promise<void> {
  // Tunnel first.
  const tpid = readPid('tunnel.pid');
  if (tpid) {
    if (pidAlive(tpid)) {
      if (killPid(tpid, true)) console.log(`tunnel stopped (pid ${tpid}).`);
      else console.error(`failed to stop tunnel pid ${tpid}.`);
    } else {
      console.log(`tunnel pid ${tpid} was not alive.`);
    }
    try { unlinkSync(pidFile('tunnel.pid')); } catch {}
  } else {
    console.log('tunnel not running (no pid file).');
  }
  try { unlinkSync(tunnelUrlFile()); } catch {}

  // Relay.
  const rpid = readPid('relay.pid');
  if (rpid) {
    if (!pidAlive(rpid)) {
      try { unlinkSync(pidFile('relay.pid')); } catch {}
      console.log(`relay pid ${rpid} was not alive (cleaned pid file).`);
    } else if (killPid(rpid)) {
      // Graceful SIGTERM/SIGBREAK succeeded — give the relay ~500ms to flush
      // close(1001) frames to connected peers before we force-kill.
      await new Promise((r) => setTimeout(r, 500));
      if (pidAlive(rpid)) {
        console.log(`relay pid ${rpid} still alive after graceful stop — force-killing…`);
        if (killPid(rpid, true)) {
          try { unlinkSync(pidFile('relay.pid')); } catch {}
          console.log(`relay stopped (pid ${rpid}, force).`);
        } else {
          console.error(`failed to stop relay pid ${rpid}.`);
        }
        return;
      }
      try { unlinkSync(pidFile('relay.pid')); } catch {}
      console.log(`relay stopped (pid ${rpid}).`);
    } else {
      // Graceful attempt FAILED. On Windows this is the EXPECTED outcome for
      // the relay: it is a windowless detached console node process, and
      // taskkill without /F only closes GUI windows — for console processes
      // it exits nonzero ("can only be terminated forcefully"). Without this
      // escalation, `server off` printed "failed to stop" and silently left
      // the relay running. Retry with a forced tree kill (taskkill /F /T),
      // then re-check liveness so we report success/failure accurately.
      killPid(rpid, true);
      await new Promise((r) => setTimeout(r, 500));
      if (!pidAlive(rpid)) {
        try { unlinkSync(pidFile('relay.pid')); } catch {}
        console.log(`relay stopped (pid ${rpid}, force).`);
      } else {
        console.error(`failed to stop relay pid ${rpid}.`);
      }
    }
  } else {
    console.log('relay not running (no pid file).');
  }

  // Last-resort sweep: if cloudflared is still somehow running on Windows but
  // our pid file is gone, kill any stray cloudflared processes so a fresh
  // `devicechat server on` doesn't end up sharing the tunnel-port with a
  // zombie. Best-effort — silently ignore on platforms without taskkill.
  if (process.platform === 'win32') {
    try { execSync('taskkill /F /IM cloudflared.exe /T', { stdio: 'ignore' }); } catch { /* none running */ }
  }
}

export function readTunnelUrl(): string | null {
  if (!existsSync(tunnelUrlFile())) return null;
  try { return readFileSync(tunnelUrlFile(), 'utf8').trim(); } catch { return null; }
}

export async function serverStatus(port = DEFAULT_PORT): Promise<void> {
  const rpid = readPid('relay.pid');
  const rAlive = rpid ? pidAlive(rpid) : false;
  const up = await relayUp(port);
  console.log(`relay:  ${up ? 'online' : 'offline'}  pid: ${rpid ?? '-'} (${rAlive ? 'alive' : 'not alive'})`);
  console.log(`local:  ${urlForWs(port)}`);
  const tpid = readPid('tunnel.pid');
  const tAlive = tpid ? pidAlive(tpid) : false;
  const url = readTunnelUrl();
  let reachability = 'unknown';
  if (url) {
    // Distinguish "process alive" (local) from "tunnel actually serves" (the
    // thing that actually matters for joiners). A zombie cloudflared with a
    // garbage-collected edge registration used to print "running" here even
    // though public joiners got ENOTFOUND — now we surface that honestly.
    const live = await tunnelReachable(url);
    reachability = live ? 'reachable' : 'unreachable';
  }
  console.log(`tunnel: ${tpid ? (tAlive ? 'running' : 'dead') : 'stopped'}  pid: ${tpid ?? '-'}  ${url ? `(${reachability})` : ''}`);
  if (url) console.log(`public: ${url}  (ws: ${urlForWss(url)})`);
}

export function printServerUsage(): void {
  console.log('devicechat server <on|off|status>');
  console.log('  on      start relay + cloudflare tunnel (public wss URL printed)');
  console.log('  off     stop relay and tunnel');
  console.log('  status  show relay + tunnel state and public URL');
}
