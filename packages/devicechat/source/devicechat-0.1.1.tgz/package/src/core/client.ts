import {
  initSodium,
  deriveSharedKey,
  encrypt,
  decrypt,
  safetyNumber,
  randomToken,
  randomGroupKey,
} from './crypto.js';
import {
  encode,
  decode,
  type ClientMessage,
  type ServerMessage,
} from './protocol.js';
import type { Identity } from './types.js';

/**
 * Decoupling layer: the CORE ChatClient never imports `ws` or any `node:*`
 * module. A host supplies a Transport factory that produces a fresh connected
 * socket per call (the client reconnects on drop, so it needs a factory, not a
 * single instance). The Node adapter wires `ws`; an RN adapter wires the
 * Hermes global `WebSocket`.
 */
export interface Transport {
  send(raw: string): boolean;
  onMessage(cb: (raw: string) => void): void;
  onClose(cb: () => void): void;
  onError(cb: (e: Error) => void): void;
  onOpen(cb: () => void): void;
  close(): void;
  readonly isConnected: boolean;
}

/**
 * Decoupling layer: persistent identity storage is host-specific (Node uses a
 * JSON file under DEVICECHAT_HOME; RN will use AsyncStorage / Keychain). The
 * core client only needs to load an identity when none was supplied to the
 * constructor.
 */
export interface IdentityStore {
  load(name?: string): Promise<Identity>;
  save(id: Identity): Promise<void>;
  setName(name: string): Promise<void>;
}

/**
 * Envelope carried INSIDE the ciphertext. The relay server only ever sees the
 * outer `relay` payload (opaque base64); the device name and routing hints live
 * here, encrypted with the peer shared key.
 */
interface Envelope {
  kind: 'handshake' | 'msg' | 'intro' | 'group-key' | 'group-rekey' | 'group-msg' | 'rename' | 'presence' | 'clear' | 'revoke' | 'file' | 'file-chunk' | 'read';
  name?: string;
  pubKey?: string; // sender's identity public key (intro only — cleartext, pubkeys are not secret)
  text?: string; // message body (msg / group-msg)
  token?: string; // sender's routing token, so the receiver can index peers
  // --- group-room fields ---
  epoch?: number; // group-key / group-rekey / group-msg / rename / presence / clear
  groupKey?: string; // group-key / group-rekey only (base64 symmetric key)
  founderPubKey?: string; // group-key / group-rekey only
  senderPubKey?: string; // group-msg / rename / presence / clear / file / file-chunk only (inside ciphertext)
  senderName?: string; // group-msg / presence only (inside ciphertext)
  ts?: number; // group-msg / rename / presence / clear / file-chunk only
  // Per-message random nonce so the dedup key (senderPubKey:ts:msgNonce) is
  // unique even when two messages share the same millisecond. Kept separate
  // from `ts` (which stays a number) so existing display/test code is untouched.
  msgNonce?: string; // group-msg / rename / presence / clear / file-chunk only
  // --- rename fields ---
  prevName?: string; // rename only (old display name)
  // --- presence fields ---
  state?: 'online' | 'away'; // presence only
  // --- file transfer fields ---
  fileName?: string; // file / file-chunk — original filename (sanitized, no path)
  fileSize?: number; // file / file-chunk — byte size of original file
  fileData?: string; // file only — base64-encoded file contents (whole file, legacy single-envelope path)
  // --- file-chunk fields (chunked transfer to avoid blocking the event loop) ---
  chunkIndex?: number; // file-chunk only — 0-based index of this chunk
  totalChunks?: number; // file-chunk only — total number of chunks for this file
  chunkData?: string; // file-chunk only — base64 chunk payload
  // --- color propagation ---
  color?: string | null; // handshake / presence — sender's chosen display color (#hex), null sentinel = reset, undefined = no change
  // --- read receipts ---
  readUpToTs?: number;        // read only — ts of the last message the reader has seen
  readUpToNonce?: string;     // read only — msgNonce of that message
  readOfSender?: string;      // read only — identity pubkey of the ORIGINAL sender whose messages are being marked read
}

/**
 * KEY EXCHANGE MODEL (no server-held keys):
 *
 * The relay server stores nothing and holds no public keys. To bootstrap a
 * shared secret we rely on an out-of-band exchange of TWO pieces of information
 * between the two humans:
 *   1. an anonymous routing `token` (low-value, just an address), and
 *   2. each other's long-term identity public key (base64) — pubkeys are NOT
 *      secret, so sharing them out-of-band is fine.
 *
 * Shared key = deriveSharedKey(myIdentityPrivate, theirIdentityPub).
 *
 * The handshake envelope carries our display name (inside the encrypted
 * envelope, never cleartext) and our routing token so the peer can index us.
 */

const MAX_RETRIES = 5;
const RETRY_DELAY_MS = 3000;

// FIX 3: inbound file size budget (DoS / disk-fill guard). A single inbound
// transfer may not exceed this many base64-encoded bytes.
const MAX_FILE_BYTES = 50 * 1024 * 1024;

export interface ChatClientOptions {
  url: string;
  identity?: Identity;
  createTransport: () => Transport;
  identityStore?: IdentityStore;
}

export class ChatClient {
  private url: string;
  private createTransport: () => Transport;
  private identityStore?: IdentityStore;
  private transport: Transport | null = null;
  private identity!: Identity;
  private myToken: string | null = null; // most-recently minted (for backwards-compat)
  // ALL tokens this client has announced on the live socket. A host can mint
  // many tokens (one per invited friend) and keep them all live so several
  // friends can join at once.
  private myTokens = new Set<string>();
  private peerPubKey: string | null = null; // their identity public key
  private peerToken: string | null = null; // their routing token

  // --- group-room state ---
  // A single shared symmetric group key (crypto_secretbox key) distributed over
  // each pairwise ECDH channel. The founder (the host) mints it; every peer who
  // completes a handshake receives it. Group messages are encrypted with this
  // key and fan out to all known peer tokens. The relay never sees it.
  private groupKey: string | null = null;
  private groupEpoch = 0;
  private isFounder = false;
  // The founder's identity public key, learned when we receive a group-key
  // envelope. Used by groupSafety() to show the room-vs-founder safety number.
  private founderPubKey: string | null = null;

  // token -> shared key (base64)
  private peerSharedKeys = new Map<string, string>();
  // token -> decrypted display name
  private peerNames = new Map<string, string>();
  // tokens -> peer identity pubkey (for stable per-person colour across renames)
  private tokenToPubKey = new Map<string, string>();
  // tokens we have already completed a handshake with (prevents loops)
  private handshaked = new Set<string>();
  // Reverse map: peer identity pubkey -> MOST-RECENT routing token we saw from
  // them. Used to MIGRATE per-peer state when a peer rotates its routing token
  // (e.g. the host re-announces under a fresh TOTP every 25s). The peer's
  // identity pubkey is the stable identifier; the route is ephemeral. Without
  // this map, a host rotating OTP would strand every joiner — the joiner would
  // keep trying to send to the host's OLD (pruned) OTP route and the relay would
  // return 'peer not connected' on every retry. With it, when the joiner
  // receives any envelope carrying a NEW env.token from a peer whose pubkey we
  // already know, we transparently move the peer's slot to the new token.
  private pubKeyToToken = new Map<string, string>();
  // Dedup set for group messages: prevents infinite re-broadcast loops when a
  // message circles back to us via the founder's fan-out. Keyed by
  // (senderPubKey:ts:msgNonce). Capped to keep memory bounded.
  private seenMsgIds = new Set<string>();

  // --- file-chunk reassembly (Bug C2 fix) ---
  // Inbound file transfers are split into ~512KB base64 chunks so each
  // encrypt()/decrypt() call stays <50ms and the Node event loop can service
  // WebSocket keepalive frames between chunks (otherwise a multi-MB synchronous
  // secretbox blocks the loop → relay ping timeout → socket death → the
  // "connecting 1/5 2/5 then nothing" symptom). We accumulate chunks per
  // (senderPubKey:fileName:ts:msgNonce) transfer id and emit onFileReceived
  // once totalChunks arrive.
  private fileChunkBuffers = new Map<string, { chunks: Map<number, string>; total: number; fileName: string; fileSize: number; senderName?: string; senderPubKey?: string }>();

  // Peer liveness: timestamp of the last envelope we received FROM each peer
  // token. Updated in routeEnvelope() for EVERY inbound envelope (msg,
  // presence, rename, clear, intro, handshake) so we can detect silent peers
  // that hard-disconnect (app killed, network loss) without the relay ever
  // telling us. Without this, a dead peer lingers in peerNames/peerSharedKeys
  // forever — and the CLI status bar shows them as still connected indefinitely.
  // The sweep timer (presenceSweepTimer) runs every 30s, pings silent peers via
  // broadcastPresence('online'), and if a peer is silent past the timeout
  // forgets them locally + fires onPeerDropped so the user sees 'logged out'.
  private lastSeenAt = new Map<string, number>();
  private presenceSweepTimer: ReturnType<typeof setInterval> | null = null;
  // Tracks the last time we sent a presence broadcast. Used by the presence
  // ping-pong logic: when we receive a presence ping from a peer, we respond
  // with our own presence — but only if we haven't sent one in the last 30s,
  // to avoid a presence storm (A pings B → B responds → A receives B's
  // response → A responds → ...). Without this throttle, two idle peers would
  // ping-pong presence envelopes every few hundred ms forever.
  private lastPresenceSentAt = 0;
  // 90s grace before first ping; 150s total silence = drop. Tuned for the worst
  // case where a peer's relay is mid-OTP-rotation (25s announce cadence) and
  // we wouldn't otherwise hear from them for ~30s naturally.
  private static readonly PRESENCE_GRACE_MS = 90_000;
  private static readonly PRESENCE_TIMEOUT_MS = 150_000;
  // Minimum gap between presence broadcasts. When we receive a presence ping,
  // we respond with our own presence — but only if at least this much time has
  // passed since our last broadcast. 30s matches the sweep tick interval, so
  // in the steady state we send at most 1 presence envelope per 30s per peer.
  private static readonly PRESENCE_PONG_MIN_MS = 30_000;

  private retries = 0;
  private connected = false;
  protected destroyed = false;
  protected reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  // Bug#4 fix: handshake-completion timeout. Started when we go online (ready
  // acked). If no peer completes a handshake within 30s, fire onHandshakeTimeout
  // so the UI can show "no peer connected yet" instead of silent "locking…".
  // Cleared on first onPeerConnected, on close, and on destroy.
  private handshakeTimer: ReturnType<typeof setTimeout> | null = null;
  // Stable-connection retry reset. A flaky relay that drops+reconnects
  // repeatedly must still be able to reach onPermanentFailure after MAX_RETRIES
  // consecutive failed reconnects, so we no longer reset retries to 0 on every
  // handleOpen. Instead we only reset once the connection has stayed up for
  // RETRY_DELAY_MS (i.e. it's actually stable).
  private stableTimer: ReturnType<typeof setTimeout> | null = null;
  // Per-token ready ack resolvers. Each announce() await its own 'ready' for that token.
  private tokenResolvers = new Map<string, () => void>();
  // Tokens the host has burned via /reset-token. We refuse to re-announce them
  // (defensive — host normally mints fresh anyway) and the relay refuses to
  // announces under these tokens for the rest of its process lifetime.
  private revokedTokens = new Set<string>();

  // --- color propagation ---
  // Per-peer chosen display color, keyed by the peer's identity pubkey (stable
  // across token rotations). When a peer sends a handshake/presence/rename
  // envelope carrying `color`, we record it here so addLine() can render their
  // messages in THEIR chosen color instead of the palette hash.
  private peerColors = new Map<string, string>(); // senderPubKey → chosen color
  private selfColor: string | null = null;

  // --- read receipts ---
  // Per-peer read cursor: originalSenderPubKey -> { ts, msgNonce } of the highest message they've read.
  // Used to decide ✓ vs ✓✓ on self-sent lines.
  private peerReadCursors = new Map<string, { ts: number; msgNonce: string }>();

  // Hooks for UI
  onLog: (line: string) => void = () => {};
  onPeerConnected: (name: string, token: string) => void = () => {};
  onPeerDropped: (name: string, token: string) => void = () => {};
  onMessage: (name: string, text: string, senderPubKey?: string, ts?: number, msgNonce?: string) => void = () => {};
  onRename: (prevName: string, newName: string, senderPubKey?: string) => void = () => {};
  onPresence: (name: string, state: 'online' | 'away', senderPubKey?: string) => void = () => {};
  onClear: (senderPubKey?: string) => void = () => {};
  onFileReceived: (name: string, fileName: string, fileSize: number, fileData: string, senderPubKey?: string) => void = () => {};
  onPeerColor: (name: string, color: string | null, senderPubKey?: string) => void = () => {};
  onReadReceipt: (readerName: string, readOfSender: string, ts: number, msgNonce: string, readerPubKey?: string) => void = () => {};
  onReady: (token: string) => void = () => {};
  onFull: () => void = () => {};
  onClose: () => void = () => {};
  // Bug#2/#6 fix: fired once when the WS exhausts MAX_RETRIES and gives up.
  // Lets the UI transition out of "connecting" to a real "connection failed"
  // state instead of sitting on offline/locking… with only a log line.
  onPermanentFailure: (reason: string) => void = () => {};
  // Bug#4 fix: fired once 30s after going online if no peer has completed a
  // handshake. Lets the UI show "no peer connected yet — share your invite"
  // instead of sitting on silent "locking…".
  onHandshakeTimeout: () => void = () => {};

  constructor(opts: ChatClientOptions) {
    this.url = opts.url;
    this.createTransport = opts.createTransport;
    this.identityStore = opts.identityStore;
    if (opts.identity) this.identity = opts.identity;
  }

  get myName(): string {
    return this.identity.name;
  }

  set myName(name: string) {
    this.identity.name = name;
  }

  get myPublicKey(): string {
    return this.identity.publicKey;
  }

  /**
   * Connect and announce an initial routing token. Returns the token.
   * Further tokens (for more friends) are minted with mintToken() without
   * reconnecting, so existing peer links stay live.
   */
  async connect(token?: string): Promise<string> {
    await initSodium();
    this.retries = 0;
    this.destroyed = false;
    if (!this.identity) {
      if (!this.identityStore) {
        throw new Error('no identity and no identityStore; cannot load identity');
      }
      this.identity = await this.identityStore.load();
    }
    const t = token ?? randomToken();
    this.myToken = t;
    this.myTokens.add(t);
    this.open();
    try {
      await this.waitForToken(t);
    } catch (e) {
      // The 8s 'ready' ack timed out while the socket is still open. Close the
      // transport so the dangling open socket does not linger and reconnect
      // logic (handleClose -> open) engages cleanly instead of stacking a
      // second socket on top of the first.
      this.transport?.close();
      throw e;
    }
    return t;
  }

  /**
   * Mint a fresh routing token on the LIVE socket (no reconnect), so multiple
   * friends can join via distinct tokens while existing peers stay connected.
   * Returns the new token after the server acks it.
   */
  async mintToken(): Promise<string> {
    if (!this.transport || !this.connected) {
      throw new Error('not connected; call connect() first');
    }
    await initSodium();
    const t = randomToken();
    this.myTokens.add(t);
    this.myToken = t; // most-recently minted
    this.send({ type: 'announce', token: t });
    await this.waitForToken(t);
    return t;
  }

  /**
   * Announce a HOST-SUPPLIED token on the LIVE socket (no reconnect, no random
   * mint). Used by the OTP bootstrap loop: the host re-announces under the
   * current TOTP code every ~25s so a joiner who only knows the OTP code
   * (6-8 char alnum from devicechat hardened OTP v3 — see algorithm.txt) can
   * route to it. The token stays live (in myTokens) until resetToken burns
   * it or the socket closes. Calling this repeatedly to rotate OTP routes is
   * the intended usage; stale OTP tokens from prior windows are intentionally
   * left in myTokens for a brief grace window so a joiner mid-rotation still
   * lands. Call clearInterval on the refresh once a peer completes handshake.
   */
  async announceToken(token: string): Promise<void> {
    if (!this.transport || !this.connected) {
      throw new Error('not connected; call connect() first');
    }
    await initSodium();
    this.myTokens.add(token);
    this.myToken = token; // most-recently announced
    this.send({ type: 'announce', token });
    await this.waitForToken(token);

    // OTP refresh loops call this every ~25s with a rotating OTP code
    // (6-8 char alnum from devicechat hardened OTP v3 — see algorithm.txt).
    // Prune prior-minted INFO: keep only the just-announced token and any
    // OTHER (non-OTP-format) tokens the host may also hold (e.g. one minted
    // via /new). Old OTP codes expired >1 window ago serve no routing purpose.
    //
    // We DO NOT send a relay `revoke` for the pruned tokens. Reasons:
    //   - They all point at THIS SAME socket; revoking would harmlessly fizzle
    //     relay-side (relay guards `victim !== socket`) but adds the token to
    //     the relay's permanent `revoked` set, poisoning it against ANY
    //     future reuse (e.g. a joiner mid-rotation whose relay route came in
    //     just as we pruned on our side — the joiner's announce would be
    //     rejected as 'token revoked').
    //   - Stale routes die naturally when our socket closes (relay's close
    //     handler deletes every token owned by this socket).
    // So this prune is purely a local memory-hygiene step on the host side.
    if (/^[A-Za-z0-9]{6,8}$/.test(token)) {
      for (const t of Array.from(this.myTokens)) {
        if (t === token) continue;
        if (!/^[A-Za-z0-9]{6,8}$/.test(t)) continue; // preserve non-OTP tokens (legacy invites)
        this.myTokens.delete(t);
      }
    }
    // FIX: notify connected peers of the new routing token immediately so they
    // migrate (routeEnvelope updates pubKeyToToken[peerPubKey] = newToken when it
    // receives any envelope carrying the new env.token). Without this, peers keep
    // sending to the OLD (pruned) OTP route and the relay returns
    // 'peer not connected' → onPeerDisconnected → "peer disconnected" spam.
    if (this.peerSharedKeys.size > 0) {
      this.broadcastPresence('online');
    }
  }

  /**
   * Tear down any host/founder or prior-peer state so this client can cleanly
   * become a joiner (e.g. when the user runs `/join` inside a TUI that booted
   * in host mode, or switches from one peer to another). Without this, outbound
   * messages would be encrypted with a stale dummy group key and dropped by the
   * real host as undecryptable, and stale per-peer routes would linger.
   */
  resetAsPeer(): void {
    this.isFounder = false;
    this.groupKey = null;
    this.groupEpoch = 0;
    this.founderPubKey = null;
    this.peerPubKey = null;
    this.peerToken = null;
    this.peerSharedKeys.clear();
    this.peerNames.clear();
    this.tokenToPubKey.clear();
    this.handshaked.clear();
    this.pubKeyToToken.clear();
    this.seenMsgIds.clear();
    this.lastSeenAt.clear();
    this.fileChunkBuffers.clear();
  }

  /**
   * True once at least one peer has completed the E2E handshake on the current
   * socket. Lets the host stop re-announcing OTP routes (the peer-shared-key
   * now carries all traffic, so the routing token is no longer needed) once
   * it has at least one live E2E link.
   */
  hasHandshakedPeer(): boolean {
    return this.handshaked.size > 0;
  }

  /**
   * Burn ALL currently-minted tokens, kick every peer via the relay, broadcast
   * a 'revoke' envelope so peers drop their per-token state, then mint a
   * fresh token. Keeps the same live socket — peers must re-/join with the
   * new invite. Returns the new token (or null if we were not connected).
   *
   * Posture: the SAME token may be re-announced during a live session's
   * auto-reconnect (the relay sees no current owner after we briefly dropped
   * and no revoke on file). `/reset-token` and across-host-process-restart
   * are the two cases where we explicitly BURN a token so it cannot be used
   * again.
   */
  async resetToken(): Promise<string | null> {
    if (!this.transport || !this.connected) return null;

    // 1) Tell peers (over their pairwise or group channel) BEFORE we kick
    //    them with a relay-level revoke, so their client-side state drops
    //    cleanly even if their socket close event races the message arrival.
    //    We send to whoever is currently in peerSharedKeys / peerNames keys.
    this.broadcastRevoke();

    // 2) For every token we own: mark revoked client-side and ask the relay
    //    to drop + close the peer currently holding it + reject re-announce.
    const oldTokens = Array.from(this.myTokens);
    for (const t of oldTokens) {
      this.revokedTokens.add(t);
      this.send({ type: 'revoke', token: t });
    }

    // 3) Tear down per-peer state on our side; the next handshake has to
    //    start fresh with a new safety number and join invite.
    this.peerSharedKeys.clear();
    this.peerNames.clear();
    this.tokenToPubKey.clear();
    this.handshaked.clear();
    this.pubKeyToToken.clear();
    this.myTokens.clear();
    this.myToken = null;
    this.groupKey = null;
    this.groupEpoch = 0;
    this.isFounder = false;
    this.founderPubKey = null;
	this.seenMsgIds.clear();
	this.peerReadCursors.clear();
	this.peerColors.clear();
	this.fileChunkBuffers.clear();

    // 4) Mint a new token and re-establish founder state. The relay will
    //    accept this brand-new token since it is not on the revoke list.
    const fresh = await this.mintToken();
    this.isFounder = true; // host keeps founder status post-rotation
    // Mint a fresh epoch-1 group key so group chat works again after rotation.
    // Without this, groupKey stays null → distributeKeyToPeer early-returns and
    // broadcastGroupMsg returns null, breaking the room until a re-handshake
    // happens to re-mint one. The new key is distributed to peers on their next
    // handshake via distributeKeyToPeer.
    this.founderMint();
    return fresh;
  }

  /**
   * Broadcast a `revoke` envelope to every peer we have a channel to, so each
   * peer drops this OLD senderToken from their peerSharedKeys/peerNames. We
   * fan out per-peer just like broadcastClear (handles both group-key and
   * pairwise-only topologies). Wrapped with the SAME channel key the peer
   * already knows so the envelope authenticates as us.
   */
  private broadcastRevoke(): void {
    const tokens = Array.from(this.peerSharedKeys.keys());
    if (tokens.length === 0) return;
    for (const oldToken of this.myTokens) {
      const env: Envelope = {
        kind: 'revoke',
        token: oldToken,
        senderPubKey: this.identity.publicKey,
        senderName: this.identity.name,
        ts: Date.now(),
        msgNonce: Math.random().toString(36).slice(2, 10),
      };
      if (this.groupKey) {
        const payload = this.wrap(env, this.groupKey);
        for (const theirToken of tokens) {
          this.send({ type: 'relay', token: theirToken, payload });
        }
      } else {
        for (const theirToken of tokens) {
          const shared = this.peerSharedKeys.get(theirToken);
          if (!shared) continue;
          this.send({ type: 'relay', token: theirToken, payload: this.wrap(env, shared) });
        }
      }
    }
  }

  /**
   * Wait for the server's 'ready' ack for a specific token.
   *
   * Bug#5 fix: the 8s timeout used to RESOLVE silently, which made connect()
   * return "success" even when the relay never acked the announce — the UI
   * then printed invite text while the status bar stayed "offline / locking…"
   * (the "connecting forever" appearance). Now the timeout REJECTS so
   * connect()'s await throws and the boot IIFE catch block surfaces a real
   * "connect failed: relay did not acknowledge token" notice instead of
   * masking the failure.
   */
  private waitForToken(token: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.tokenResolvers.delete(token);
        reject(new Error('relay did not acknowledge token (no "ready" within 8s — is the relay running?)'));
      }, 8000);
      this.tokenResolvers.set(token, () => {
        clearTimeout(timer);
        this.tokenResolvers.delete(token);
        resolve();
      });
    });
  }

  /**
   * Drop all per-peer state for a routing token that the relay reports as
   * unreachable (peer socket gone / peer rotated their token and we didn't get
   * the migration envelope yet). The UI calls this when it sees the relay's
   * 'peer not connected' error so the host doesn't keep broadcasting into a
   * dead route on every group fan-out (which would otherwise spam the user
   * with 'peer disconnected' notices every time they send a message after a
   * peer quietly dropped).
   *
   * Note: this is BEST-EFFORT cleanup. The route will be re-populated if the
   * peer reconnects and we receive a fresh intro/handshake from them.
   */
  forgetPeerByToken(token: string): void {
    const pub = this.tokenToPubKey.get(token);
    this.peerSharedKeys.delete(token);
    this.peerNames.delete(token);
    this.tokenToPubKey.delete(token);
    this.handshaked.delete(token);
    this.lastSeenAt.delete(token);
    // Prune the dead peer's group-msg dedup entries WITHOUT wiping the whole
    // set. seenMsgIds is keyed by `${senderPubKey}:${ts}:${msgNonce}` and
    // holds dedup memory for EVERY peer's group broadcasts. A prior version
    // called seenMsgIds.clear() here, which would wipe the host's dedup
    // memory for B and C simply because peer A died — then a stale re-broadcast
    // of an OLD B/C message that happens to circle back via the founder's
    // fan-out would be re-delivered to the UI as a duplicate line.
    if (pub) {
      const prefix = `${pub}:`;
      for (const id of Array.from(this.seenMsgIds)) {
        if (id.startsWith(prefix)) this.seenMsgIds.delete(id);
      }
    }
	if (pub) {
		// Only clear the reverse map if it still points at THIS token. A peer
		// may have JUST sent us an envelope with a new env.token, in which case
		// pubKeyToToken already moved to the new slot and we must not erase it.
		if (this.pubKeyToToken.get(pub) === token) {
			this.pubKeyToToken.delete(pub);
		}
	}
	if (pub) {
		this.peerReadCursors.delete(pub);
		this.peerColors.delete(pub);
		for (const id of Array.from(this.fileChunkBuffers.keys())) {
			if (id.startsWith(`${pub}:`)) this.fileChunkBuffers.delete(id);
		}
	}
	// If the dead token was our "current peer", clear those slots too so the
    // UI status bar emits 'no peer'. The next incoming envelope will repopulate.
    if (this.peerToken === token) {
      this.peerToken = null;
      // Keep peerPubKey — the user typed it into Settings; we may want to
      // reconnect using the same pubKey + a fresh OTP. Actually safer to drop
      // peerPubKey too so we don't accidentally reply to the NEXT occupant of
      // the rotated-away OTP route (could be a stranger if host reused it).
      this.peerPubKey = null;
    }
  }

  getMyToken(): string | null {
    return this.myToken;
  }

  /**
   * True once the transport has acked at least one token (connected === true).
   * Exposed so UI callers (e.g. doJoin) can avoid a redundant connect() that
   * would open a second socket on top of a live one.
   */
  get isConnected(): boolean {
    return this.connected;
  }

  /**
   * True if a transport instance currently exists (socket may still be
   * handshaking the 'ready' ack). Used alongside isConnected to guard against
   * double-connect during the open-but-not-yet-acked window.
   */
  get hasTransport(): boolean {
    return this.transport !== null;
  }

  getAllMyTokens(): string[] {
    return Array.from(this.myTokens);
  }

  private open(): void {
    if (this.transport) {
      try {
        this.transport.close();
      } catch {}
      this.transport = null;
    }
    const t = this.createTransport();
    this.transport = t;
    t.onOpen(() => this.handleOpen());
    t.onMessage((raw) => this.handleMessage(raw));
    t.onClose(() => this.handleClose());
    t.onError((err) => this.onLog(`socket error: ${err.message}`));
  }

  private handleOpen(): void {
    if (this.destroyed) return;
    this.connected = true;
    // On (re)connect, re-announce EVERY token we own so peers can still reach us.
    // Skip tokens we explicitly burned via /reset-token — they're revoked on the
    // relay and re-announcing them would just produce another 'token revoked'
    // error and an unwanted close.
    for (const t of this.myTokens) {
      if (this.revokedTokens.has(t)) continue;
      this.send({ type: 'announce', token: t });
    }
    // If we somehow have no tokens yet, use the legacy myToken.
    if (this.myTokens.size === 0 && this.myToken) {
      this.send({ type: 'announce', token: this.myToken });
    }
    // Start the liveness sweep so silent peers get detected. Idempotent —
    // if a prior sweep timer is still alive (from a previous connect on the
    // same ChatClient) we clear it first to avoid double-ticking.
    this.startPresenceSweep();
    // Bug#4 fix: start the handshake-completion timer. If no peer completes
    // a handshake within 30s, onHandshakeTimeout fires so the UI can show
    // "no peer connected yet" instead of silent "locking…".
    this.startHandshakeTimer();
    // Only reset the reconnect counter once the connection proves stable. If the
    // relay keeps dropping us, this timer never fires and retries keeps climbing
    // toward MAX_RETRIES, making onPermanentFailure reachable.
    this.stableTimer = setTimeout(() => {
      this.stableTimer = null;
      if (!this.destroyed && this.connected) this.retries = 0;
    }, RETRY_DELAY_MS);
  }

  private startHandshakeTimer(): void {
    if (this.handshakeTimer) clearTimeout(this.handshakeTimer);
    this.handshakeTimer = setTimeout(() => {
      this.handshakeTimer = null;
      if (!this.destroyed && this.connected && this.peerSharedKeys.size === 0) {
        this.onHandshakeTimeout();
      }
    }, 30_000);
  }

  private clearHandshakeTimer(): void {
    if (this.handshakeTimer) {
      clearTimeout(this.handshakeTimer);
      this.handshakeTimer = null;
    }
  }

  /**
   * Start the per-peer liveness sweep. Every 30s we look at every peer token
   * in peerSharedKeys (the set of peers we have a shared E2E key with, i.e.
   * the ones the user sees as "connected"):
   *
   *   - If we haven't heard ANY envelope from a peer in > PRESENCE_GRACE_MS
   *     (90s), we broadcast a 'presence online' envelope to nudge them — they
   *     reply (or their next envelope) updates lastSeenAt. This is cheap: it
   *     piggybacks on the existing presence envelope path; no protocol bump.
   *
   *   - If we haven't heard from a peer in > PRESENCE_TIMEOUT_MS (150s), we
   *     declare them gone: forgetPeerByToken + onPeerDropped(name, token).
   *     The UI shows 'name logged out (silent)' and clears the peer slot.
   *
   * This is the fix for the long-standing "stale peer stays in the peer list
   * forever when the peer hard-disconnects" bug: the relay knows the peer's
   * socket closed, but it never tells US unless *we* send and get a 'peer not
   * connected' error. With this sweep, we NOTICE the silence ourselves and
   * proactively drop the peer on our end. No relay cooperation required.
   */
  private startPresenceSweep(): void {
    if (this.presenceSweepTimer) {
      clearInterval(this.presenceSweepTimer);
    }
    this.presenceSweepTimer = setInterval(() => this.runPresenceSweep(), 30_000);
  }

  private stopPresenceSweep(): void {
    if (this.presenceSweepTimer) {
      clearInterval(this.presenceSweepTimer);
      this.presenceSweepTimer = null;
    }
    this.lastSeenAt.clear();
  }

  private runPresenceSweep(): void {
    if (this.destroyed || !this.connected) return;
    const now = Date.now();
    const tokens = Array.from(this.peerSharedKeys.keys());
    for (const token of tokens) {
      const last = this.lastSeenAt.get(token) ?? 0;
      const silentFor = now - last;
      // Once we've passed the grace window, nudge with a presence ping. We do
      // this every sweep tick while silent (not just once) because if the
      // first ping was lost in transit a second ping 30s later is cheap and
      // gives the peer another chance.
      if (silentFor > ChatClient.PRESENCE_GRACE_MS) {
        // Broadcast a presence 'online' to ALL peers (broadcastPresence iterates
        // peerSharedKeys itself); it's the cheapest existing envelope and also
        // serves as a keep-alive for any near-silent-but-alive peer. We DON'T
        // narrow to just this token because broadcastPresence fires pairwise to
        // every peer in a loop anyway — calling it once covers everyone silently.
        // One ping per sweep tick is enough — break out of the token loop so we
        // don't fire N presence envelopes when N peers are simultaneously silent.
        this.broadcastPresence('online');
        break;
      }
    }
    // Hygiene: cap lastSeenAt to live tokens. Tokens that migrated to a new
    // route (routeMigration block) lazily still have stale entries here; we
    // drop them whenever we sweep so the map doesn't grow unbounded.
    for (const token of Array.from(this.lastSeenAt.keys())) {
      if (!this.peerSharedKeys.has(token)) this.lastSeenAt.delete(token);
    }
  }

  private handleClose(): void {
    if (this.destroyed) return;
    this.connected = false;
    this.clearHandshakeTimer();
    if (this.stableTimer) {
      clearTimeout(this.stableTimer);
      this.stableTimer = null;
    }
    this.onClose();
    // FIX 2: keep peer state (peerNames, peerSharedKeys, tokenToPubKey,
    // pubKeyToToken, peerReadCursors, handshaked, groupKey) intact across a
    // transient reconnect so a peer can still SEND after the socket drops and
    // recovers. The presence sweep prunes peers that are truly gone. We only
    // drop the stale lastSeenAt timestamp (so a pre-disconnect value can't
    // trigger a false onPeerDropped after reconnect) and any incomplete inbound
    // file transfers. isFounder is intentionally left as-is — a host stays a
    // host across reconnects.
    this.lastSeenAt.clear();
    this.fileChunkBuffers.clear();
    if (this.retries < MAX_RETRIES) {
      this.retries++;
      this.onLog(
        `connection lost; reconnecting (${this.retries}/${MAX_RETRIES}) in ${RETRY_DELAY_MS / 1000}s...`,
      );
      this.reconnectTimer = setTimeout(() => this.open(), RETRY_DELAY_MS);
    } else {
      this.onLog('could not reconnect; giving up.');
      // Bug#2/#6 fix: surface permanent failure to the UI so it can
      // transition out of "connecting" instead of sitting silent.
      this.onPermanentFailure('could not reconnect after ' + MAX_RETRIES + ' attempts — is the relay running?');
    }
  }

  private handleMessage(raw: string): void {
    if (this.destroyed) return;
    let msg: ServerMessage;
    try {
      msg = decode<ServerMessage>(raw);
    } catch (e) {
      this.onLog(`bad message from server: ${(e as Error).message}`);
      return;
    }

    switch (msg.type) {
      case 'ready':
        this.onReady(msg.token);
        {
          const r = this.tokenResolvers.get(msg.token);
          if (r) r();
        }
        break;
      case 'full':
        this.onFull();
        break;
      case 'error':
        // Relay-level "token revoked" — the host (or relay) invalidated one of
        // our tokens via /reset-token on the same relay process. Peer clients
        // see this after the relay kicks them. We surface a clearer log line
        // and pin retries to MAX so we don't loop trying to re-announce a
        // token the relay now rejects (it would just tell us 'token revoked'
        // again, then close again).
        if (msg.message === 'token revoked') {
          this.onLog('token revoked — host reset the token. Ask the host for a fresh /join invite.');
          this.retries = MAX_RETRIES;
          if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
          }
          // Best-effort cleanup of our own per-peer state since the host will
          // not accept this token on this relay process again.
          this.peerSharedKeys.clear();
          this.peerNames.clear();
          this.tokenToPubKey.clear();
          this.handshaked.clear();
          this.pubKeyToToken.clear();
          this.myTokens.forEach((t) => this.revokedTokens.add(t));
          this.myTokens.clear();
          this.myToken = null;
          this.connected = false;
          // Close the underlying transport so a stale socket doesn't linger.
          this.close();
        } else if (msg.message === 'token taken over') {
          // Another connection (e.g. a restarted or second app instance)
          // claimed this token's relay route. Stop retrying so we don't flap
          // against the takeover; the user must close the other instance or
          // restart the relay, then reconnect manually.
          this.onLog('token taken over by another connection — close the other instance or restart the relay, then reconnect.');
          this.retries = MAX_RETRIES;
          if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
          }
          this.connected = false;
          this.close();
        } else if (msg.message === 'peer not connected' && msg.token) {
          // The relay now tags the error with WHICH target token failed, so we
          // can precisely prune THAT peer slot (instead of guessing from the UI
          // side via peerTokenRef). This is important for group fan-out: the
          // host sends to many tokens in a loop; only one is dead. Without the
          // tag, we'd forget a random peer and leave the actually-dead one in
          // the map → repeated 'peer not connected' on every next broadcast.
          const deadName = this.peerNames.get(msg.token) ?? null;
          this.forgetPeerByToken(msg.token);
          if (deadName !== null) {
            // Surface a clean 'name logged out' event so the UI doesn't stack
            // a generic 'peer disconnected' notice trail. onPeerDropped also
            // fires the App's notification scheduler so the user gets a
            // background push that the peer left.
            this.onPeerDropped(deadName, msg.token);
          } else {
            this.onLog('server error: peer not connected');
          }
        } else {
          this.onLog(`server error: ${msg.message}`);
        }
        break;
      case 'relay': {
        // A relay frame with no payload (peer sent `{type:'relay',token:'x'}`
        // and the blind relay forwarded it verbatim; JSON drops the undefined
        // key) would make unwrap() call payloadB64.slice(0,32) on undefined →
        // TypeError that escapes the ws 'message' listener and crashes the
        // process (remote DoS). Drop such frames defensively.
        if (typeof msg.payload !== 'string') {
          this.onLog('relay frame missing payload — dropped');
          return;
        }
        const env = this.unwrap(msg.payload);
        if (!env) return;
        this.routeEnvelope(env);
        break;
      }
    }
  }

  private send(msg: ClientMessage): boolean {
    // Bug C3 fix: return whether the transport actually queued the bytes.
    // sendFile propagates this so the UI can show a real failure instead of
    // "sent file" when the socket was actually closed mid-transfer.
    if (this.transport && this.connected) {
      return this.transport.send(encode(msg));
    }
    return false;
  }

  /**
   * Decrypt an opaque relay payload into an Envelope. We try every known peer
   * shared key (the server's `from` is opaque, so we brute-force the small set
   * of peers locally). Returns null if no key authenticates the blob.
   */
  private unwrap(payloadB64: string): Envelope | null {
    // First try decrypting with every known peer shared key (pairwise channel).
    const { ciphertext, nonce } = this.splitPayload(payloadB64);
    for (const [token, key] of this.peerSharedKeys) {
      const json = decrypt(key, ciphertext, nonce);
      if (json === null) continue;
      try {
        return JSON.parse(json) as Envelope;
      } catch {
        return null;
      }
    }
    // No pairwise key authenticated it. Try the group key (group-msg is
    // encrypted with the shared symmetric group key, not a pairwise key).
    if (this.groupKey) {
      const json = decrypt(this.groupKey, ciphertext, nonce);
      if (json !== null) {
        try {
          const env = JSON.parse(json) as Envelope;
          if (env && typeof env.kind === 'string') return env;
        } catch {
          // not a group payload; fall through
        }
      }
    }
    // No shared key authenticated the blob. Try a CLEARTEXT intro envelope
    // (pubkeys are not secret, so an introductory peer-pubkey may arrive
    // unencrypted). This is how a host learns a joiner's public key.
    try {
      const env = JSON.parse(payloadB64) as Envelope;
      if (env && typeof env.kind === 'string' && env.kind === 'intro') {
        return env;
      }
    } catch {
      // not JSON either
    }
    this.onLog('received payload we could not decrypt (unknown peer?)');
    return null;
  }

  private splitPayload(payloadB64: string): {
    ciphertext: string;
    nonce: string;
  } {
    // payload = base64(nonce || ciphertext); nonce is 24 bytes -> 32 b64 chars
    if (typeof payloadB64 !== 'string') return { ciphertext: '', nonce: '' };
    const nonce = payloadB64.slice(0, 32);
    const ciphertext = payloadB64.slice(32);
    return { ciphertext, nonce };
  }

  private wrap(env: Envelope, key: string): string {
    const { ciphertext, nonce } = encrypt(key, JSON.stringify(env));
    return nonce + ciphertext;
  }

  private routeEnvelope(env: Envelope): void {
    const senderToken = env.token;
    if (!senderToken && env.kind !== 'group-msg' && env.kind !== 'group-rekey' && env.kind !== 'presence' && env.kind !== 'clear') {
      return;
    }

    // --- ROUTE MIGRATION ---
    // A peer may have rotated its routing token since we last indexed state
    // (host re-announces on a fresh TOTP every ~25s; /reset-token; etc.).
    // Any envelope we receive carries the peer's CURRENT myToken in env.token.
    // We trust this as the peer's live route for the next send. If we already
    // have state for the same peer under an OLD token, migrate it forward so
    // (a) replies route to the live token, and (b) the relay doesn't keep
    // telling us 'peer not connected' on the stale one. The stable identity
    // anchor is the peer's identity pubkey — extracted from env.pubKey (intro)
    // or env.senderPubKey (handshake/group-msg/rename/presence/clear).
    const peerPubKey =
      env.kind === 'intro' ? env.pubKey :
      env.senderPubKey ?? (senderToken ? this.tokenToPubKey.get(senderToken) : undefined);
    if (peerPubKey && senderToken) {
      const knownToken = this.pubKeyToToken.get(peerPubKey);
      if (knownToken && knownToken !== senderToken) {
        // Migrate per-peer state from knownToken -> senderToken, then update
        // the reverse map.
        const shared = this.peerSharedKeys.get(knownToken);
        const name = this.peerNames.get(knownToken);
        const wasHandshaked = this.handshaked.has(knownToken);
        if (shared) {
          this.peerSharedKeys.delete(knownToken);
          this.peerSharedKeys.set(senderToken, shared);
        } else if (this.peerPubKey === peerPubKey && this.peerPubKey) {
          // We know this peer via the legacy single-peer slot but never added
          // it to peerSharedKeys (rare edge case during very early handshake).
          this.peerSharedKeys.set(senderToken, deriveSharedKey(this.identity.privateKey, peerPubKey));
        }
        if (name) {
          this.peerNames.delete(knownToken);
          this.peerNames.set(senderToken, name);
        }
        this.tokenToPubKey.delete(knownToken);
        this.tokenToPubKey.set(senderToken, peerPubKey);
        if (wasHandshaked) {
          this.handshaked.delete(knownToken);
          this.handshaked.add(senderToken);
        }
        // If the migrated peer is our "current peer" tracked in peer* slots,
        // update those too so sendMessage routes to the live token.
        if (this.peerToken === knownToken) {
          this.peerToken = senderToken;
        }
        if (this.peerPubKey === peerPubKey) {
          // peerPubKey already matches; no change.
        }
        this.pubKeyToToken.set(peerPubKey, senderToken);
      } else if (!knownToken) {
        // First time we see this peer's pubkey — record the reverse map.
        this.pubKeyToToken.set(peerPubKey, senderToken);
        this.tokenToPubKey.set(senderToken, peerPubKey);
      }
    }

    // Liveness: mark this peer as heard-from NOW. The presence sweep timer
    // (started in connect() via handleOpen) uses this timestamp to decide
    // whether a peer has gone silent. We update for EVERY inbound envelope
    // carrying a senderToken (after the migration block above so senderToken
    // is the CURRENT route).
    if (senderToken) {
      this.lastSeenAt.set(senderToken, Date.now());
    }

    if (env.kind === 'intro') {
      this.handleIntro(senderToken!, env);
    } else if (env.kind === 'handshake') {
      this.handleHandshake(senderToken!, env);
    } else if (env.kind === 'msg') {
      const name = this.peerNames.get(senderToken!) ?? env.name ?? 'peer';
      const text = env.text ?? '';
      this.onMessage(name, text, this.tokenToPubKey.get(senderToken!));
    } else if (env.kind === 'file') {
      const name = this.peerNames.get(senderToken!) ?? env.name ?? 'peer';
      const fileName = env.fileName ?? 'unknown';
      const fileSize = env.fileSize ?? 0;
      const fileData = env.fileData ?? '';
      this.onFileReceived(name, fileName, fileSize, fileData, this.tokenToPubKey.get(senderToken!));
    } else if (env.kind === 'file-chunk') {
      // Bug C2 receive side: accumulate chunks and emit onFileReceived once
      // all totalChunks have arrived. The transfer id is
      // (senderPubKey:fileName:ts:msgNonce) — the sender stamps every chunk
      // of a given file with the same ts + transferNonce so we can group them.
      this.handleFileChunk(senderToken ?? undefined, env);
    } else if (env.kind === 'group-key' || env.kind === 'group-rekey') {
      this.handleGroupKey(env);
    } else if (env.kind === 'group-msg' || env.kind === 'rename') {
      // Dedup BEFORE delivering or re-broadcasting: if we've already seen this
      // exact message (same sender + ts + msgNonce) drop it. This is what stops
      // an infinite re-broadcast loop when a group message circles back to us.
      // rename uses the same dedup + founder re-broadcast as group-msg.
      const id = this.msgId(env);
      if (this.seenMsgIds.has(id)) return;
      // Cap the dedup set to 200 entries; evict the oldest insertion BEFORE
      // adding so the set never briefly holds 201 (off-by-one guard).
      if (this.seenMsgIds.size >= 200) {
        const first = this.seenMsgIds.values().next().value;
        if (first) this.seenMsgIds.delete(first);
      }
      this.seenMsgIds.add(id);
      if (env.kind === 'group-msg') {
        const name = env.senderName ?? (senderToken ? this.peerNames.get(senderToken) : undefined) ?? 'peer';
        const text = env.text ?? '';
        this.onMessage(name, text, env.senderPubKey ?? (senderToken ? this.tokenToPubKey.get(senderToken) : undefined), env.ts, env.msgNonce);
      } else {
        // rename
        if (env.senderPubKey && senderToken) {
          this.tokenToPubKey.set(senderToken, env.senderPubKey);
        }
        if (env.senderName && senderToken) {
          this.peerNames.set(senderToken, env.senderName);
        }
        this.onRename(env.prevName ?? '?', env.senderName ?? '?', env.senderPubKey ?? (senderToken ? this.tokenToPubKey.get(senderToken) : undefined));
        if (env.color !== undefined && env.senderPubKey) {
          // FIX 1: a `null` color is the EXE/APK reset sentinel — drop the
          // cached color. FIX 4: ignore any value that isn't a valid #rrggbb
          // hex (prevents a malformed color from crashing chalk.hex later).
          if (env.color === null) {
            this.peerColors.delete(env.senderPubKey);
          } else if (/^#[0-9a-fA-F]{6}$/.test(env.color)) {
            this.peerColors.set(env.senderPubKey, env.color);
          }
          this.onPeerColor(env.senderName ?? '?', env.color, env.senderPubKey);
        }
      }
      // Founder re-broadcasts group messages so peers without pairwise channels
      // to each other still receive every message (hub-and-spoke fan-out).
      if (this.isFounder && this.groupKey && senderToken) {
        this.reBroadcastGroupMsg(env, senderToken);
      }
    } else if (env.kind === 'presence') {
      // Presence broadcast (online/away) — dedup + deliver + founder re-broadcast
      const id = this.msgId(env);
      if (this.seenMsgIds.has(id)) return;
      if (this.seenMsgIds.size >= 200) {
        const first = this.seenMsgIds.values().next().value;
        if (first) this.seenMsgIds.delete(first);
      }
      this.seenMsgIds.add(id);
      if (env.senderName && env.state) {
        this.onPresence(env.senderName, env.state, env.senderPubKey ?? (senderToken ? this.tokenToPubKey.get(senderToken) : undefined));
      }
      if (env.color !== undefined && env.senderPubKey) {
        // FIX 1: a `null` color is the EXE/APK reset sentinel — drop the
        // cached color. FIX 4: ignore any value that isn't a valid #rrggbb
        // hex (prevents a malformed color from crashing chalk.hex later).
        if (env.color === null) {
          this.peerColors.delete(env.senderPubKey);
        } else if (/^#[0-9a-fA-F]{6}$/.test(env.color)) {
          this.peerColors.set(env.senderPubKey, env.color);
        }
        this.onPeerColor(env.senderName ?? 'peer', env.color, env.senderPubKey);
      }
      // Presence ping-pong: when we receive a presence ping from a peer, we
      // respond with our own presence broadcast — but only if we haven't sent
      // one in the last PRESENCE_PONG_MIN_MS (30s). This keeps BOTH sides'
      // lastSeenAt fresh during idle periods, preventing the sweep from
      // dropping a live-but-silent peer at 150s. Without this pong, the ping
      // is one-way: A pings B → B's lastSeenAt[A] updates, but A's
      // lastSeenAt[B] never updates from the ping → A drops B at 150s even
      // though B is alive and received the ping. The 30s throttle prevents a
      // ping-pong storm (A→B→A→B...).
      if ((env.state === 'online' || env.state === 'away') && (Date.now() - this.lastPresenceSentAt) > ChatClient.PRESENCE_PONG_MIN_MS) {
        this.broadcastPresence('online');
      }
      if (this.isFounder && this.groupKey && senderToken) {
        this.reBroadcastGroupMsg(env, senderToken);
      }
    } else if (env.kind === 'clear') {
      // Clear history broadcast — dedup + deliver + founder re-broadcast
      const id = this.msgId(env);
      if (this.seenMsgIds.has(id)) return;
      if (this.seenMsgIds.size >= 200) {
        const first = this.seenMsgIds.values().next().value;
        if (first) this.seenMsgIds.delete(first);
      }
      this.seenMsgIds.add(id);
      this.onClear(env.senderPubKey ?? (senderToken ? this.tokenToPubKey.get(senderToken) : undefined));
      if (this.isFounder && this.groupKey && senderToken) {
        this.reBroadcastGroupMsg(env, senderToken);
      }
    } else if (env.kind === 'read') {
      // Read receipt broadcast — dedup + deliver + founder re-broadcast (same pattern as presence/clear)
      const id = this.msgId(env);
      if (this.seenMsgIds.has(id)) return;
      if (this.seenMsgIds.size >= 200) {
        const first = this.seenMsgIds.values().next().value;
        if (first) this.seenMsgIds.delete(first);
      }
      this.seenMsgIds.add(id);
      // Record the reader's cursor for messages originally sent by readOfSender
      if (env.readOfSender && env.readUpToTs && env.readUpToNonce && env.senderPubKey) {
        const prev = this.peerReadCursors.get(env.senderPubKey);
        // Advance the cursor to the LATEST read position. Use >= so a receipt at
        // the same ts (different nonce) still updates the stored nonce; this
        // keeps the cursor as "most recent read" without ever moving backward.
	if (!prev || env.readUpToTs >= prev.ts) {
          this.peerReadCursors.set(env.senderPubKey, { ts: env.readUpToTs, msgNonce: env.readUpToNonce });
        }
      }
      if (env.senderName && env.readOfSender && env.readUpToTs && env.readUpToNonce) {
        this.onReadReceipt(env.senderName, env.readOfSender, env.readUpToTs, env.readUpToNonce, env.senderPubKey);
      }
      if (this.isFounder && this.groupKey && senderToken) {
        this.reBroadcastGroupMsg(env, senderToken);
      }
    } else if (env.kind === 'revoke') {
      // Peer is signaling that THEY are rotating their own token and the
      // senderToken they put in this envelope is being burned. Drop our
      // per-peer state for it so we don't try to reply through a token the
      // relay now rejects. No re-broadcast — revoke is per-destination only,
      // and the host/broadcaster will send its own revoke to its peers when
      // it rotates.
      if (!senderToken) return;
      this.peerSharedKeys.delete(senderToken);
      this.peerNames.delete(senderToken);
      this.tokenToPubKey.delete(senderToken);
      this.handshaked.delete(senderToken);
      this.onLog('peer rotated their token — they will re-join with a fresh invite.');
    }
  }

  /**
   * Reassemble an inbound chunked file transfer (Bug C2 receive side).
   *
   * The sender splits the base64 file into ~512KB chunks and sends each as a
   * separate 'file-chunk' envelope. We accumulate them keyed by
   * (senderPubKey:fileName:ts:msgNonce) and, once totalChunks have arrived,
   * concatenate in chunk-index order and fire onFileReceived exactly once.
   *
   * Robustness:
   *   - Duplicate / late-arriving chunks are ignored (Map.set is idempotent).
   *   - If the sender's pubkey is unknown we fall back to the senderToken's
   *     known pubkey (or undefined) so the UI still gets a colorKey.
   *   - The buffer is capped implicitly: a half-assembled transfer whose
   *     remaining chunks never arrive is garbage-collected when a NEW transfer
   *     with the same id arrives (overwrites the entry) — and we also cap the
   *     map to 8 concurrent transfers to bound memory.
   */
  private handleFileChunk(senderToken: string | undefined, env: Envelope): void {
    if (env.chunkIndex === undefined || env.totalChunks === undefined || env.chunkData === undefined || !env.fileName) {
      return;
    }
    // FIX 3: cap totalChunks to bound the transfer size. A chunk is at most
    // 512 KiB of base64 payload, so this is the maximum number of chunks that
    // could fit under MAX_FILE_BYTES, plus slack for the final (shorter) chunk.
    const MAX_CHUNKS = Math.ceil(MAX_FILE_BYTES / (512 * 1024)) + 16;
    if (env.totalChunks > MAX_CHUNKS) {
      this.onLog(`rejected file transfer ${env.fileName}: too many chunks (${env.totalChunks} > ${MAX_CHUNKS})`);
      return;
    }
    const senderPubKey = env.senderPubKey ?? (senderToken ? this.tokenToPubKey.get(senderToken) : undefined);
    const transferId = `${senderPubKey ?? ''}:${env.fileName}:${env.ts ?? 0}:${env.msgNonce ?? ''}`;
    let buf = this.fileChunkBuffers.get(transferId);
    if (!buf) {
      // Cap concurrent inbound transfers to 8 to bound memory. Evict the
      // oldest insertion (FIFO) before adding a new one.
      if (this.fileChunkBuffers.size >= 8) {
        const firstKey = this.fileChunkBuffers.keys().next().value;
        if (firstKey) this.fileChunkBuffers.delete(firstKey);
      }
      buf = {
        chunks: new Map<number, string>(),
        total: env.totalChunks,
        fileName: env.fileName,
        fileSize: env.fileSize ?? 0,
        senderName: env.name ?? (senderToken ? this.peerNames.get(senderToken) : undefined),
        senderPubKey,
      };
      this.fileChunkBuffers.set(transferId, buf);
    }
    // FIX 3: enforce the inbound file size budget. Compute cumulative received
    // base64 bytes (existing chunks + this one) and abort if it exceeds the cap.
    let receivedBytes = env.chunkData.length;
    for (const c of buf.chunks.values()) receivedBytes += c.length;
    if (receivedBytes > MAX_FILE_BYTES) {
      this.onLog(`rejected file transfer ${env.fileName}: exceeds max size (${(receivedBytes / 1024 / 1024).toFixed(1)} MB > ${MAX_FILE_BYTES / 1024 / 1024} MB)`);
      this.fileChunkBuffers.delete(transferId);
      return;
    }
    // totalChunks could differ if the sender's view changed mid-transfer; trust
    // the value on the FIRST chunk we saw (the buf.total we just initialized).
    buf.chunks.set(env.chunkIndex, env.chunkData);

    if (buf.chunks.size < buf.total) return;

    // All chunks arrived — concatenate in index order.
    let fileData = '';
    for (let i = 0; i < buf.total; i++) {
      const c = buf.chunks.get(i);
      if (c === undefined) {
        // Missing chunk — shouldn't happen since size === total, but guard.
        this.onLog(`file transfer ${transferId} incomplete (missing chunk ${i}); discarding`);
        this.fileChunkBuffers.delete(transferId);
        return;
      }
      fileData += c;
    }
    const name = buf.senderName ?? (senderToken ? this.peerNames.get(senderToken) : undefined) ?? 'peer';
    this.fileChunkBuffers.delete(transferId);
    this.onFileReceived(name, buf.fileName, buf.fileSize, fileData, buf.senderPubKey);
  }

  /**
   * Stable per-message id for group-msg dedup. Combines the sender's identity
   * pubkey, the millisecond timestamp, and the per-message random nonce so two
   * messages sent in the same millisecond still get distinct ids.
   */
  private msgId(env: Envelope): string {
    return `${env.senderPubKey ?? ''}:${env.ts ?? 0}:${env.msgNonce ?? ''}`;
  }

  /**
   * Re-wrap a received group message with our group key and fan it out to every
   * peer EXCEPT the original sender. Only the founder does this, so non-founder
   * peers don't need direct pairwise channels to each other.
   */
  private reBroadcastGroupMsg(env: Envelope, fromToken: string): void {
    if (!this.groupKey) return;
    const payload = this.wrap(env, this.groupKey);
    for (const theirToken of this.peerSharedKeys.keys()) {
      if (theirToken === fromToken) continue;
      this.send({ type: 'relay', token: theirToken, payload });
    }
  }

  /**
   * A joiner introduces itself in CLEARTEXT with its identity pubkey (pubkeys
   * are not secret). As the host (or any peer), learn their pubkey so we can
   * derive the E2E shared key for all subsequent encrypted traffic.
   */
  private handleIntro(senderToken: string, env: Envelope): void {
    if (!env.pubKey) return;
    // Record this peer's identity pubkey and derive the shared key.
    this.tokenToPubKey.set(senderToken, env.pubKey);
    this.pubKeyToToken.set(env.pubKey, senderToken);
    // Only populate the legacy single-peer slots when NOT in a group room. In a
    // multi-peer group, an inbound intro from peer B must NOT clobber the slots
    // that point at peer A — group routing is handled by the peerSharedKeys /
    // peerNames maps, and pairwise sendMessage/safety() would otherwise target
    // the wrong peer.
    if (!this.groupKey) {
      this.peerToken = senderToken;
      this.peerPubKey = env.pubKey;
    }
    const shared = deriveSharedKey(this.identity.privateKey, env.pubKey);
    this.peerSharedKeys.set(senderToken, shared);
    // Reply with our own cleartext intro so the joiner learns our pubkey too,
    // then send an encrypted handshake (name + token) now that we share a key.
    if (!this.handshaked.has(senderToken)) {
      this.sendIntro(senderToken);
      this.sendHandshake(senderToken);
    }
  }

  private handleHandshake(senderToken: string, env: Envelope): void {
    // We need their identity public key to derive the shared key. If we already
    // have a shared key for this peer (from our own outgoing handshake), reuse
    // it; otherwise derive from their identity pubkey (must be known).
    let shared = this.peerSharedKeys.get(senderToken);
    if (!shared) {
      if (!this.peerPubKey) {
        this.onLog('received handshake but we have no peer public key; run /join');
        return;
      }
      shared = deriveSharedKey(this.identity.privateKey, this.peerPubKey);
      this.peerSharedKeys.set(senderToken, shared);
    }

    // The handshake envelope carries the sender's identity pubkey (added when
    // we changed the route-migration model) so we can keep our reverse lookup
    // in sync even if this is the first envelope we received from this peer.
    if (env.senderPubKey) {
      this.pubKeyToToken.set(env.senderPubKey, senderToken);
      this.tokenToPubKey.set(senderToken, env.senderPubKey);
    }
    if (env.name) this.peerNames.set(senderToken, env.name);
    if (env.color !== undefined && env.senderPubKey) {
      // FIX 1: a `null` color is the EXE/APK reset sentinel — drop the
      // cached color. FIX 4: ignore any value that isn't a valid #rrggbb
      // hex (prevents a malformed color from crashing chalk.hex later).
      if (env.color === null) {
        this.peerColors.delete(env.senderPubKey);
      } else if (/^#[0-9a-fA-F]{6}$/.test(env.color)) {
        this.peerColors.set(env.senderPubKey, env.color);
      }
      this.onPeerColor(env.name ?? 'peer', env.color, env.senderPubKey);
    }
    this.onPeerConnected(env.name ?? 'peer', senderToken);
    // Bug#4 fix: a peer completed a handshake — cancel the "no peer yet" timer.
    this.clearHandshakeTimer();

    // Show safety number for out-of-band MITM verification.
    if (this.peerPubKey) {
      this.onLog(
        `safety number (verify out-of-band): ${safetyNumber(
          this.identity.publicKey,
          this.peerPubKey,
        )}`,
      );
    }

    // Reply with our own handshake if we haven't completed one with this peer.
    if (!this.handshaked.has(senderToken)) {
      this.sendHandshake(senderToken);
    }

    // If we are the group founder and have a group key, distribute it to this
    // newly-handshaked peer over the pairwise channel so they can read group
    // messages. (If we are a non-founder peer who already holds a group key, we
    // may also bootstrap a late-joiner — distributing the key is allowed.)
    if (this.isFounder && this.groupKey) {
      this.distributeKeyToPeer(senderToken);
    }
  }

  /**
   * (Founder) Mint a fresh group key + start epoch 1. Called by the host on
   * connect(). After this, every peer that completes a handshake gets the key.
   */
  founderMint(): void {
    this.groupKey = randomGroupKey();
    this.groupEpoch = 1;
    this.isFounder = true;
  }

  /**
   * Send the group key to a peer over their pairwise channel. The envelope rides
   * inside the pairwise-encrypted payload, so the relay only sees opaque bytes.
   */
  distributeKeyToPeer(theirToken: string): void {
    const shared = this.peerSharedKeys.get(theirToken);
    if (!shared || !this.groupKey) return;
    const env: Envelope = {
      kind: 'group-key',
      epoch: this.groupEpoch,
      groupKey: this.groupKey,
      founderPubKey: this.identity.publicKey,
      token: this.myToken ?? undefined,
    };
    this.send({ type: 'relay', token: theirToken, payload: this.wrap(env, shared) });
  }

  /**
   * Receive a group key (or rekey) from a peer. Store it so we can decrypt
   * group messages and broadcast to the room.
   */
  private handleGroupKey(env: Envelope): void {
    if (!env.groupKey || typeof env.epoch !== 'number') return;
    this.groupKey = env.groupKey;
    this.groupEpoch = env.epoch;
    this.isFounder = false; // we received (did not mint) the key
    if (env.founderPubKey) this.founderPubKey = env.founderPubKey;
    if (env.founderPubKey) {
      this.onLog(
        `joined group room (epoch ${env.epoch}); safety vs founder: ${safetyNumber(
          this.identity.publicKey,
          env.founderPubKey,
        )}`,
      );
    } else {
      this.onLog(`joined group room (epoch ${env.epoch})`);
    }
  }

  /**
   * Register the peer's identity public key (from the out-of-band bundle) and
   * routing token. Triggers an initial handshake.
   */
  setPeer(token: string, pubKey: string): void {
    this.peerToken = token;
    this.peerPubKey = pubKey;
    this.tokenToPubKey.set(token, pubKey);
    this.pubKeyToToken.set(pubKey, token);
    const shared = deriveSharedKey(this.identity.privateKey, pubKey);
    this.peerSharedKeys.set(token, shared);
    if (this.connected) {
      // Send our pubkey in CLEARTEXT so the peer can learn it (pubkeys are not
      // secret), then send the encrypted handshake carrying our name.
      this.sendIntro(token);
      this.sendHandshake(token);
    }
  }

  /**
   * Send a CLEARTEXT intro envelope to a peer token carrying our identity
   * public key. Pubkeys are not secret; this lets a host learn a joiner's key
   * without any out-of-band step. Sent as a normal relay payload (the relay
   * forwards opaque bytes; whether we encrypt is our choice).
   */
  sendIntro(theirToken: string): void {
    const env: Envelope = {
      kind: 'intro',
      pubKey: this.identity.publicKey,
      token: this.myToken ?? undefined,
    };
    this.send({ type: 'relay', token: theirToken, payload: JSON.stringify(env) });
  }

  /**
   * Send a handshake envelope to a peer token. Carries our display name (inside
   * the ciphertext) and our routing token so the peer can index us.
   */
  sendHandshake(theirToken: string): void {
    this.handshaked.add(theirToken);
    const shared = this.peerSharedKeys.get(theirToken);
    if (!shared) {
      this.onLog('no shared key for peer; run /join first');
      return;
    }
    const env: Envelope = {
      kind: 'handshake',
      name: this.identity.name,
      token: this.myToken ?? undefined,
      // Include our identity pubkey so a receiver that has PRIOR state under
      // an OLD route token (e.g. joiner pointing at a rotated-away host OTP)
      // can migrate the per-peer slot forward to this NEW myToken. Without
      // this field the receiver has no stable identifier to detect "same peer,
      // new route" and would reject the envelope as from an unknown stranger.
      senderPubKey: this.identity.publicKey,
      color: this.selfColor === null ? null : this.selfColor ?? undefined,
    };
    this.send({ type: 'relay', token: theirToken, payload: this.wrap(env, shared) });
  }

  /**
   * Send a chat message. If we hold a group key, broadcast to every known peer
   * token (group room); otherwise fall back to a single pairwise message.
   *
   * Returns `{ ts, msgNonce } | null`:
   *   - null  = failed (no peers / no shared key / no group key)
   *   - {ts, msgNonce} = sent. For the GROUP path these are the real envelope
   *     ts + per-message nonce the UI needs to later call markRead(...) and to
   *     render ✓/✓✓. For the PAIRWISE path we return a dummy nonce ('') since
   *     read receipts are group-only — the UI ignores the pairwise return value.
   *
   * (Phase 8 / read receipts: previously returned boolean. The 3 UI call sites
   * used `if (ok) ...` which still works — an object is truthy, null falsy —
   * so the boolean→object change is backwards-compatible at the call sites.)
   */
  sendMessage(theirToken: string, text: string): { ts: number; msgNonce: string } | null {
    if (this.groupKey) {
      return this.broadcastGroupMsg(text);
    }
    const shared = this.peerSharedKeys.get(theirToken);
    if (!shared) {
      this.onLog('no shared key for peer; run /join first');
      return null;
    }
    const env: Envelope = {
      kind: 'msg',
      name: this.identity.name,
      text,
      token: this.myToken ?? undefined,
    };
    this.send({ type: 'relay', token: theirToken, payload: this.wrap(env, shared) });
    return { ts: Date.now(), msgNonce: '' };
  }

  /**
   * Send a file to peers. The file contents are base64-encoded, split into
   * ~512KB chunks, and each chunk is carried in a separate encrypted
   * `file-chunk` envelope. This avoids the C2 bug where a single synchronous
   * encrypt() over a multi-MB plaintext blocked the Node event loop long
   * enough for the relay's WebSocket keepalive to time out and drop the
   * socket ("connecting 1/5 2/5 then nothing").
   *
   * Bug C1 fix: in a group room (the default host mode) we wrap with the
   * shared group key and fan out to ALL peers in peerSharedKeys — NOT just
   * getPeerToken() (which returns the most-recent joiner and would send to
   * the WRONG peer in multi-peer rooms). Without a group key we fall back to
   * per-peer pairwise wrapping, still fanned out to every peer.
   *
   * Bug C3 fix: returns false if no peers / no key / the transport refused
   * the bytes (socket not OPEN or send buffer overflow). The signature is
   * `Promise<boolean>` because we yield to the event loop (setImmediate)
   * between chunks so heartbeats are serviced.
   *
   * The `theirToken` param is kept for API compatibility but ignored — we
   * always fan out to every connected peer (group semantics).
   */
  async sendFile(theirToken: string, fileName: string, fileDataB64: string, fileSize: number): Promise<boolean> {
    void theirToken; // group fan-out — we don't target a single peer
    // Reject outbound files the receiver would always refuse, keeping sender
    // and receiver symmetric on the same MAX_FILE_BYTES cap.
    if (fileDataB64.length > MAX_FILE_BYTES) {
      this.onLog(`rejected file transfer ${fileName}: exceeds max size (${(fileDataB64.length / 1024 / 1024).toFixed(1)} MB > ${MAX_FILE_BYTES / 1024 / 1024} MB)`);
      return false;
    }
    const tokens = Array.from(this.peerSharedKeys.keys());
    if (tokens.length === 0) {
      this.onLog('no peers connected; cannot send file');
      return false;
    }
    // Choose the wrapping key. Group key (one ciphertext, fan out) is preferred
    // when available; otherwise we wrap per-peer with each pairwise key.
    const wrapKey = (token: string): string => {
      if (this.groupKey) return this.groupKey;
      const sk = this.peerSharedKeys.get(token);
      if (!sk) throw new Error('no shared key for peer ' + token);
      return sk;
    };

    // --- chunk the base64 payload to keep each encrypt() < ~50ms ---
    // 512KB base64 chars = ~384KB binary plaintext → secretbox on 384KB is
    // well under 50ms on any modern CPU. Yields between chunks via setImmediate
    // so the ws keepalive ping frames are serviced.
    const CHUNK_SIZE = 512 * 1024; // base64 chars per chunk
    const totalChunks = Math.max(1, Math.ceil(fileDataB64.length / CHUNK_SIZE));
    const ts = Date.now();
    // Per-transfer nonce so the receiver groups chunks of THIS file together.
    // Multiple files with the same name from the same sender are distinguished
    // by (ts, msgNonce).
    const transferNonce = Math.random().toString(36).slice(2, 10);
    const senderPubKey = this.identity.publicKey;
    const senderName = this.identity.name;
    const myToken = this.myToken ?? undefined;

    let allQueued = true;
    for (let i = 0; i < totalChunks; i++) {
      const chunkData = fileDataB64.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
      const env: Envelope = {
        kind: 'file-chunk',
        name: senderName,
        fileName,
        fileSize,
        chunkIndex: i,
        totalChunks,
        chunkData,
        ts,
        msgNonce: transferNonce,
        token: myToken,
        senderPubKey,
      };
      // Wrap once per destination token. Group key → one ciphertext reused;
      // pairwise → per-token ciphertext. Send returns false if the transport
      // dropped the bytes (socket closed / buffer overflow).
      for (const token of tokens) {
        if (!this.peerSharedKeys.has(token)) continue;
        let payload: string;
        try {
          payload = this.wrap(env, wrapKey(token));
        } catch (e) {
          this.onLog(`file-chunk wrap failed: ${(e as Error).message}`);
          allQueued = false;
          continue;
        }
        const ok = this.send({ type: 'relay', token, payload });
        if (!ok) allQueued = false;
      }
      // Yield to the event loop between chunks so the ws transport can service
      // relay ping/pong frames. Without this, a multi-MB file's worth of
      // synchronous encrypt()+send() calls would block the loop for hundreds
      // of ms → keepalive timeout → socket close → reconnect storm.
      if (i < totalChunks - 1) {
        await new Promise<void>((r) => setImmediate(r));
      }
    }
    return allQueued;
  }

  /**
   * Broadcast a group message to every peer we have a pairwise channel with.
   * The message is encrypted once with the shared group key and sent to each
   * peer's routing token (client-side fan-out; the relay stays maximally blind).
   *
   * Returns `{ ts, msgNonce } | null`. The (ts, msgNonce) are the EXACT values
   * stamped into the outgoing envelope — the UI captures them so it can later
   * call markRead(...) and render ✓/✓✓ on the self-sent line. Returns null if
   * there is no group key or no peers connected.
   */
  private broadcastGroupMsg(text: string): { ts: number; msgNonce: string } | null {
    if (!this.groupKey) {
      this.onLog('no group key; cannot broadcast');
      return null;
    }
    const ts = Date.now();
    const msgNonce = Math.random().toString(36).slice(2, 10);
    const env: Envelope = {
      kind: 'group-msg',
      epoch: this.groupEpoch,
      senderPubKey: this.identity.publicKey,
      senderName: this.identity.name,
      text,
      token: this.myToken ?? undefined,
      ts,
      msgNonce,
    };
    const payload = this.wrap(env, this.groupKey);
	const tokens = Array.from(this.peerSharedKeys.keys());
	if (tokens.length === 0) {
		this.onLog('no peers connected; nothing to broadcast to');
		return null;
	}
	let ok = false;
	for (const theirToken of tokens) {
		ok = ok || this.send({ type: 'relay', token: theirToken, payload });
	}
	return ok ? { ts, msgNonce } : null;
  }

  /**
   * Broadcast a rename notice to the whole room over the group key. Peers
   * (and the founder) render it as a dim system line `prevName → newName` and
   * update their peerNames / tokenToPubKey maps so future messages are colored
   * and labelled with the new name. Falls back to a no-op if there is no group
   * key yet (the name change is still applied locally + persisted by the caller).
   */
  broadcastRename(prevName: string, newName: string): boolean {
    if (!this.groupKey) {
      // No group room yet — nothing to broadcast. The next handshake will
      // carry the new name to anyone who joins later.
      return false;
    }
	const env: Envelope = {
		kind: 'rename',
		epoch: this.groupEpoch,
		senderPubKey: this.identity.publicKey,
		prevName,
		senderName: newName,
		token: this.myToken ?? undefined,
		ts: Date.now(),
		msgNonce: Math.random().toString(36).slice(2, 10),
	};
	const payload = this.wrap(env, this.groupKey);
	const tokens = Array.from(this.peerSharedKeys.keys());
	let ok = false;
	for (const theirToken of tokens) {
		ok = ok || this.send({ type: 'relay', token: theirToken, payload });
	}
	return ok;
  }

  hasGroupKey(): boolean {
    return this.groupKey !== null;
  }

  /**
   * Broadcast a presence state change ('online' or 'away') to all peers.
   * Uses the shared group key if we hold one (covers the group-room case so
   * the relay never sees the state, and the founder can re-broadcast it to
   * peers we have no direct pairwise channel with). Otherwise falls back to a
   * pairwise-encrypted presence envelope per peer so a non-founder device
   * without a group key (e.g. a phone that only ever handshooked with the
   * host) can still announce ONLINE/OFFLINE.
   */
  broadcastPresence(state: 'online' | 'away'): boolean {
    const env: Envelope = {
      kind: 'presence',
      epoch: this.groupEpoch,
      state,
      senderPubKey: this.identity.publicKey,
      senderName: this.identity.name,
      token: this.myToken ?? undefined,
      ts: Date.now(),
      msgNonce: Math.random().toString(36).slice(2, 10),
      color: this.selfColor === null ? null : this.selfColor ?? undefined,
    };
	const tokens = Array.from(this.peerSharedKeys.keys());
	if (tokens.length === 0) return false;
	let ok = false;
	if (this.groupKey) {
		// Group room: one ciphertext, fan out to every peer token.
		const payload = this.wrap(env, this.groupKey);
		for (const theirToken of tokens) {
			ok = ok || this.send({ type: 'relay', token: theirToken, payload });
		}
	} else {
		// No group key yet (typical for a phone peer that only handshooked
		// pairwise with the host). Wrap individually with each peer's shared
		// key so the envelope is still end-to-end encrypted.
		for (const theirToken of tokens) {
			const shared = this.peerSharedKeys.get(theirToken);
			if (!shared) continue;
			ok = ok || this.send({ type: 'relay', token: theirToken, payload: this.wrap(env, shared) });
		}
	}
	if (ok) this.lastPresenceSentAt = Date.now();
	return ok;
  }

  /**
   * Broadcast a "clear history" command to all peers in the group room.
   * Everyone who receives it wipes their local transcript.
   */
  broadcastClear(): boolean {
    const env: Envelope = {
      kind: 'clear',
      epoch: this.groupEpoch,
      senderPubKey: this.identity.publicKey,
      senderName: this.identity.name,
      token: this.myToken ?? undefined,
      ts: Date.now(),
      msgNonce: Math.random().toString(36).slice(2, 10),
    };
	const tokens = Array.from(this.peerSharedKeys.keys());
	if (tokens.length === 0) return false;
	let ok = false;
	if (this.groupKey) {
		// Group room: one ciphertext, fan out to every peer token.
		const payload = this.wrap(env, this.groupKey);
		for (const theirToken of tokens) {
			ok = ok || this.send({ type: 'relay', token: theirToken, payload });
		}
	} else {
		// No group key yet (typical for a phone peer that only handshooked
		// pairwise with the host). Wrap individually per peer so the clear
		// envelope is still end-to-end encrypted and reaches every peer we
		// have a shared key with.
		for (const theirToken of tokens) {
			const shared = this.peerSharedKeys.get(theirToken);
			if (!shared) continue;
			ok = ok || this.send({ type: 'relay', token: theirToken, payload: this.wrap(env, shared) });
		}
	}
	return ok;
  }

  getPeerToken(): string | null {
    return this.peerToken;
  }

  getPeerName(): string | null {
    return this.peerToken ? this.peerNames.get(this.peerToken) ?? null : null;
  }

  // --- color propagation ---
  setSelfColor(color: string | null): void {
    this.selfColor = color;
  }

  getPeerColor(senderPubKey?: string): string | null {
    if (!senderPubKey) return null;
    return this.peerColors.get(senderPubKey) ?? null;
  }

  // --- read receipts (Phase 8) ---
  /**
   * Record that WE have read up to (ts, msgNonce) of a message originally sent
   * by originalSenderPubKey, and broadcast a 'read' envelope to the group so
   * peers can update their ✓/✓✓ markers on their own self-sent lines. Returns
   * true if the receipt was broadcast to at least one peer, false otherwise
   * (no group key / no peers).
   */
  markRead(originalSenderPubKey: string, ts: number, msgNonce: string): boolean {
    if (!this.groupKey) return false;
    const env: Envelope = {
      kind: 'read',
      epoch: this.groupEpoch,
      senderPubKey: this.identity.publicKey,
      senderName: this.identity.name,
      readOfSender: originalSenderPubKey,
      readUpToTs: ts,
      readUpToNonce: msgNonce,
      token: this.myToken ?? undefined,
      ts: Date.now(),
      msgNonce: Math.random().toString(36).slice(2, 10),
    };
	const payload = this.wrap(env, this.groupKey);
	const tokens = Array.from(this.peerSharedKeys.keys());
	let ok = false;
	for (const theirToken of tokens) {
		ok = ok || this.send({ type: 'relay', token: theirToken, payload });
	}
	return ok;
  }

  /**
   * Returns the highest {ts, msgNonce} a given peer (by their identity pubkey)
   * has read of OUR messages. Undefined if they haven't sent a read receipt.
   */
  getPeerReadCursor(peerPubKey: string): { ts: number; msgNonce: string } | undefined {
    return this.peerReadCursors.get(peerPubKey);
  }

  /**
   * Returns true if every known peer (excluding the original sender themselves)
   * has a read cursor at or past (ts, msgNonce). Used by UI to render ✓✓ on
   * self-sent lines. If there are no known peers, returns false (just ✓).
   *
   * "At or past" means: cursor.ts >= ts. A peer whose cursor ts is at or
   * "Read" means the peer's cursor is strictly past this message's ts, OR at
   * the same ts with a matching msgNonce. Two messages sent in the same ms with
   * different nonces are NOT conflated: reading A but not B leaves B as ✓ (not
   * ✓✓), because B's exact (ts, msgNonce) is not in the peer's cursor.
   */
  isReadByAllPeers(originalSenderPubKey: string, ts: number, msgNonce: string): boolean {
    const knownPeerPubKeys = new Set<string>();
    for (const pk of this.tokenToPubKey.values()) {
      if (pk !== originalSenderPubKey) knownPeerPubKeys.add(pk);
    }
    if (knownPeerPubKeys.size === 0) return false;
    for (const pk of knownPeerPubKeys) {
      const cur = this.peerReadCursors.get(pk);
      if (!cur) return false;
      // Peer has read this exact message iff their cursor passed it: a later ts,
      // or the same ts with the matching nonce.
      const read = cur.ts > ts || (cur.ts === ts && cur.msgNonce === msgNonce);
      if (!read) return false;
    }
    return true;
  }

  /**
   * List all known routing tokens: ALL of my own tokens + every peer token we
   * have a shared key or display name for. Returns [token, role, name?].
   */
  listTokens(): Array<{ token: string; role: 'self' | 'peer'; name?: string }> {
    const out: Array<{ token: string; role: 'self' | 'peer'; name?: string }> = [];
    const mine = new Set<string>(this.myTokens);
    if (this.myToken) mine.add(this.myToken);
    for (const token of mine) {
      out.push({ token, role: 'self', name: this.identity.name });
    }
    for (const [token, name] of this.peerNames) {
      if (mine.has(token)) continue;
      out.push({ token, role: 'peer', name });
    }
    for (const token of this.peerSharedKeys.keys()) {
      if (mine.has(token) || this.peerNames.has(token)) continue;
      out.push({ token, role: 'peer' });
    }
    return out;
  }

  /**
   * Compact list of connected peers for the host status bar / multi-peer UI.
   * Returns [{ name, token, pub }] for every peer we have a shared key + name
   * for. The name is what the bar shows; the pub is the color-key; the token
   * lets the UI to dedupe / surface per-peer state. Sorted by name for stable
   * ordering.
   */
  getPeers(): Array<{ name: string; token: string; pub?: string }> {
    const out: Array<{ name: string; token: string; pub?: string }> = [];
    for (const [token, name] of this.peerNames) {
      const pub = this.tokenToPubKey.get(token);
      out.push({ name, token, pub });
    }
    out.sort((a, b) => a.name.localeCompare(b.name));
    return out;
  }

  safety(): string | null {
    if (!this.peerPubKey) return null;
    return safetyNumber(this.identity.publicKey, this.peerPubKey);
  }

  /**
   * Safety number for the GROUP ROOM: us vs the room's founder. Returns null if
   * we don't yet know the founder's pubkey (we haven't received a group-key) or
   * if our own identity isn't loaded.
   */
  groupSafety(): string | null {
    if (!this.founderPubKey || !this.identity.publicKey) return null;
    return safetyNumber(this.identity.publicKey, this.founderPubKey);
  }

  /**
   * Wipe ALL session secrets and connection state, then close the socket.
   * Called on quit so keys/transcripts don't linger in memory after exit.
   */
  wipe(): void {
    this.destroyed = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.myToken = null;
    this.groupKey = null;
    this.groupEpoch = 0;
    this.isFounder = false;
    this.founderPubKey = null;
    this.peerSharedKeys.clear();
    this.peerNames.clear();
    this.tokenToPubKey.clear();
    this.handshaked.clear();
    this.pubKeyToToken.clear();
    this.peerToken = null;
    this.peerPubKey = null;
	this.myTokens.clear();
	this.seenMsgIds.clear();
	this.peerReadCursors.clear();
	this.peerColors.clear();
	this.fileChunkBuffers.clear();
	this.tokenResolvers.clear();
    this.close();
  }

  close(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    // Bug#4 fix: cancel the "no peer yet" timer on teardown so it can't fire
    // after the socket is gone.
    this.clearHandshakeTimer();
    // Stop the liveness sweep so the 30s tick doesn't try to send presence
    // envelopes on a torn-down transport (which is a no-op + log spam risk).
    this.stopPresenceSweep();
    if (this.transport) {
      try {
        this.transport.close();
      } catch {}
      this.transport = null;
    }
    this.connected = false;
  }
}
